

fun <T>last (n:Int,list: List<T>): T= list.elementAt(n)



fun main(){


    println(last(5,listOf(1,2,3,4,2,24,3)))
}