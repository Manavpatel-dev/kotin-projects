package com.example
import com.example.db.datasource
import io.ktor.application.*

import com.example.route.registerUserRoutes
import com.example.route.registerAddressRoutes

import io.ktor.features.*
import io.ktor.serialization.*
import org.jetbrains.exposed.sql.Database

fun main(args: Array<String>): Unit = io.ktor.server.netty.EngineMain.main(args)
fun Application.module(testing: Boolean = false) {
    install(ContentNegotiation) {
        json()
    }
    install(Compression) {
        gzip()
    }
    Database.connect(datasource)
    registerUserRoutes()
    registerAddressRoutes()
}