package com.example.db


import com.example.user.AddressTable
import com.example.user.UserTable
import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction



val datasource = HikariDataSource(
    HikariConfig().apply {
        jdbcUrl = "jdbc:mysql://127.0.0.1:3306/ADDRESS"
        username = "newuser"
        password = "password"
    }
)


