package com.example.user

import org.jetbrains.exposed.sql.transactions.transaction
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
class UserController {
    fun getAll(): ArrayList<User> {
        val users: ArrayList<User> = arrayListOf()
        transaction {
            UserTable.selectAll().map {
                users.add(
                    User(
                        id = it[UserTable.id].toString().toInt(),
                        firstName = it[UserTable.fname]
                    )
                )
            }
        }
        return users
    }

    fun getUser(id: Int):User{
        val user: MutableList<User> = mutableListOf()
        transaction {
            user.addAll(AddressTable.join(UserTable, JoinType.INNER).select(UserTable.id eq id).map { User(it[UserTable.id].toString().toInt() , it[UserTable.fname]) })

        }
        return user.first()
    }

    fun insert(user: UserDTO): Int {
        var userId= 0

        transaction {
            val getUser = UserTable.select(UserTable.fname eq user.firstName).map {User(it[UserTable.id].toString().toInt(),it[UserTable.fname]) }

            if(getUser.isEmpty()) {
                val userI = UserTable.insert {
                    it[fname] = user.firstName
                } get UserTable.id
                userId = userI.toString().toInt()
            }else{
                userId = getUser.first().id
            }

        }
        return userId
    }

    fun update(id: Int , user: UserDTO) {
        transaction {
            UserTable.update({UserTable.id eq id}) {
                it[fname] = user.firstName
            }
        }
    }
    fun delete(id: Int){
        transaction {
            AddressTable.deleteWhere{AddressTable.uid eq id}
            UserTable.deleteWhere { UserTable.id eq id }
        }
    }
}