package com.example.route

import com.example.user.AddressController
import com.example.user.AddressDTO
import io.ktor.application.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.*

val addressController= AddressController()

fun Route.addressRouting() {
    route("/address") {
        get {
            call.respond(addressController.getAll())
        }
        get("/{id}") {
            val aid = call.parameters["id"]
            if (aid != null) {
                val add = addressController.getAddress(aid.toInt())
                call.respond(add)
            }
        }
    }


    post {
        val parameters = call.receiveParameters()
        val uid = parameters["uid"]?.toInt()
        val add = addressController.addAddress(uid!! ,parameters)
        call.respondText("Address id is: $add")
    }
    put("/{id}"){
        val aid = call.parameters["id"]
        if(aid != null){
            val addressDto = call.receive<AddressDTO>()
            call.respond(addressController.update(aid.toInt(), addressDto))
        }
    }
    delete ( "/{id}" ){
        val aid = call.parameters["id"]
        if(aid != null){
            call.respond(addressController.delete(aid.toInt()))
        }
    }
}

fun Application.registerAddressRoutes() {
    routing {
        addressRouting()
    }
}



