package com.example.route

import com.example.user.UserController
import com.example.user.UserDTO
import io.ktor.application.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.*
val userController = UserController()
fun Route.userRouting() {
    route("/user") {
        get {
            call.respond(userController.getAll())
        }
        get("/{id}"){
            val uid = call.parameters["id"]
            if (uid != null) {
                val ruser = userController.getUser(uid.toInt())
                println(ruser)
                call.respond(ruser)
            }
        }
        post {
            val userDto = call.receive<UserDTO>()
            println(userController.insert(userDto))
            call.respond(HttpStatusCode.Created)
        }
        get("/{id}/address"){
            val uid = call.parameters["id"]
            if (uid != null) {
                call.respond(addressController.getAddressByUserId(uid.toInt()))
            }
        }
        put("/{id}"){
            val uid = call.parameters["id"]
            if(uid != null){
                val userDto = call.receive<UserDTO>()
                call.respond(userController.update(uid.toInt(),userDto))
            }
        }
        delete ( "/{id}" ){
            val uid = call.parameters["id"]
            if(uid != null){
                call.respond(userController.delete(uid.toInt()))
            }
        }
    }
}
fun Application.registerUserRoutes() {
    routing {
        userRouting()
    }
}