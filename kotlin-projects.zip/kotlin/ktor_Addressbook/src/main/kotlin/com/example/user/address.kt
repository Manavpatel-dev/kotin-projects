package com.example.user

import kotlinx.serialization.Serializable
import org.jetbrains.exposed.sql.Table
@Serializable
data class Address(
    val type: String,
    val street1: String,
    val street2: String,
    val city: String,
    val zipcode: String,
    val state: String,
    val country: String
)
@Serializable
data class AddressDTO(
    val street1: String,
    val street2: String,
    val city: String,
    val zipcode: String,


)

object AddressTable: Table("address_table"){

    val id = integer("id").autoIncrement().primaryKey() // Column<Int>
    val city = varchar("city",25)
    val state = varchar("state",25)
    val zipcode = varchar("zipcode",25)
    val country = varchar("country",25)
    val street1 = varchar("street1",30)
    val street2 = varchar("street2",30).nullable()
    val uid = (integer("user_id").references(UserTable.id)).nullable()
    val type = varchar("type",25)
}