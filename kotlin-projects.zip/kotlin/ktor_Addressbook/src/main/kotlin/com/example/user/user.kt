package com.example.user

import kotlinx.serialization.Serializable
import org.jetbrains.exposed.dao.IntIdTable
import org.jetbrains.exposed.sql.Column

@Serializable
data class User(
    val id: Int,
    val firstName: String,
)
@Serializable
 data class UserDTO(
     val firstName: String
 )
@Serializable
data class  UserAddressDTO(
    val user: User,
    val address: Address
)


object UserTable: IntIdTable("my_contacts" ) {
    val fname: Column<String> = varchar("first_name", 25).uniqueIndex()
}