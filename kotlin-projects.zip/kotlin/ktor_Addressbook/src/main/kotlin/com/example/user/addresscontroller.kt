package com.example.user

import io.ktor.http.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction


enum class CityEnum(val state:String) {
    SURAT("GUJARAT"),
    VADODARA("GUJARAT"),
    AHMEDABAD("GUJARAT"),
    BANGALORE("KARNATAKA"),
    ANAND("GUJARAT"),
    MAHUVA("GUJARAT"),
    MUMBAI("MAHARSHTRA"),
    LA("CALIFORNIA")
}
enum class StateEnum(val country:String) {
    GUJARAT("INDIA"),
    KARNATAKA("INDIA"),
    MAHARASHTRA("INDIA"),
    CALIFORNIA("USA")
}
class AddressController {
    fun getAll(): ArrayList<Triple<Int, Address, User>> {
        val addresses: ArrayList<Triple<Int, Address, User>> = arrayListOf()
        transaction {
            AddressTable.innerJoin(UserTable).selectAll().map {
                addresses.add(
                    Triple(
                        it[AddressTable.id].toString().toInt(),
                        Address(
                            type = it[AddressTable.type],
                            street1 = it[AddressTable.street1],
                            street2 = it[AddressTable.street2]!!,
                            city = it[AddressTable.city],
                            zipcode = it[AddressTable.zipcode],
                            state = it[AddressTable.state],
                            country = it[AddressTable.country],
                        ), User(id = it[UserTable.id].toString().toInt(), firstName = it[UserTable.fname])
                    )
                )
            }
        }

        println(addresses)
        return addresses
    }


    fun getAddress(id: Int): List<UserAddressDTO> {
        val query = transaction {
            AddressTable.innerJoin(UserTable).select(AddressTable.id eq id).map {
                UserAddressDTO(
                    User(id = it[UserTable.id].toString().toInt(), firstName = it[UserTable.fname]),
                    Address(
                        type = it[AddressTable.type],
                        street1 = it[AddressTable.street1],
                        street2 = it[AddressTable.street2]!!,
                        city = it[AddressTable.city],
                        zipcode = it[AddressTable.zipcode],
                        state = it[AddressTable.state],
                        country = it[AddressTable.country],
                    )
                )
            }
        }
        return query
    }

    fun addAddress(user: Int, parameters: Parameters) {
        transaction {
            val getUserId = UserTable.select(UserTable.id eq user)
                .map { User(it[UserTable.id].toString().toInt(), it[UserTable.fname]) }.first().id

            AddressTable.insert {
                it[uid] = getUserId
                it[type] = parameters["type"].toString()
                it[street1] = parameters["street1"].toString()
                it[street2] = parameters["street2"].toString()
                it[city] = parameters["city"].toString()
                it[zipcode] = parameters["zipcode"]!!.toString()
                it[state] = CityEnum.valueOf(parameters["city"].toString().uppercase()).state
                it[country] = StateEnum.valueOf(
                    CityEnum.valueOf(
                        parameters["city"].toString().uppercase()
                    ).state.uppercase()
                ).country

            }
        }
    }

    fun getAddressByUserId(uid: Int): List<Pair<User, Address>> {
        val query = transaction {
            AddressTable.innerJoin(UserTable).select(UserTable.id eq uid).map {
                Pair(
                    User(id = it[UserTable.id].toString().toInt(), firstName = it[UserTable.fname]),
                    Address(
                        type = it[AddressTable.type],
                        street1 = it[AddressTable.street1],
                        street2 = it[AddressTable.street2]!!,
                        city = it[AddressTable.city],
                        zipcode = it[AddressTable.zipcode],
                        state = it[AddressTable.state],
                        country = it[AddressTable.country],
                    )
                )
            }
        }
        return query
    }

    fun update(aid: Int, entity: AddressDTO) {
        transaction {
            AddressTable.update({ AddressTable.id eq aid }) {
                it[city] = entity.city
                it[zipcode] = entity.zipcode
                it[street1] = entity.street1
                it[street2] = entity.street2
                it[state] = CityEnum.valueOf(entity.city.uppercase()).state
                it[country] = StateEnum.valueOf(CityEnum.valueOf(entity.city.uppercase()).state.uppercase()).country
            }
        }
    }

    fun delete(aid: Int) {
        transaction {
            AddressTable.deleteWhere { AddressTable.id eq aid }
        }
    }
}













