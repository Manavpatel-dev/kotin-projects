package com.registration

import java.util.*


enum class Type()
{
    Seller,
    BUYER,
    FINANCER,
    INSUERS,
    OTHERPARTNER,
}

data class registration(

    val applicantName : String,
    val mobileNumber: String,
    val applicantEmail: String,
    val applicantRole: Type
    )












