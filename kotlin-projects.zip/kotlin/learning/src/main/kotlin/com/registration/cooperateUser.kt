package com.registration

import java.util.*





data class  Coorporateregistration(
    val CIN : String, // api must be called so that to validate if company exist or not
    val Website : String,
    val BusinessNature : String,
    val ActivityNature : String,
    val IEC : String,
    val DateOfCommencement : Date,
    val LEI :String
)