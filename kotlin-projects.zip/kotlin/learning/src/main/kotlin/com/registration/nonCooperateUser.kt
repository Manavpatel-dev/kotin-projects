package com.registration

import java.util.*

data class  NonCorporateregistration(

    val RegistrationNumber: String,
    val DateOfIncorpotion: Date,
    val PlaceofRegistration : String,
    val IEC : String, // api must be called so that to validate if company exist or not
    val Website : String,
    val BusinessNature : String,
    val ActivityNature : String,
    val DateOfCommencement : Date,
    val LEI :String
)


