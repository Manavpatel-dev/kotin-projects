package org.mnp_address_book
import arrow.core.andThen

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import org.mnp_address_book.org.mnp_address_book.AddressTable

import org.mnp_address_book.org.mnp_address_book.UserTable


val datasource = HikariDataSource(
    HikariConfig().apply {
        jdbcUrl = "jdbc:mysql://127.0.0.1:3306/ADDRESS"
        username = "newuser"
        password = "password"
    }
)

val database = Database.connect(datasource)

fun createTable() {
    transaction {
        addLogger(StdOutSqlLogger)
        SchemaUtils.create(UserTable)
        SchemaUtils.create(AddressTable)
    }
}

fun dropTable(){
    transaction {
        SchemaUtils.drop(AddressTable, UserTable)
    }
}
val throwsSomeStuff: (Int) -> Double = {x -> x.toDouble()}
val throwsOtherThings: (Double) -> String = {x -> x.toString()}
val moreThrowing: (String) -> List<String> = {x -> listOf(x)}
val magic = throwsSomeStuff.andThen(throwsOtherThings).andThen(moreThrowing)
//sampleEnd

    //sampleEnd
    fun main() {
        println ("magic = $magic")
    }




//        transaction {
//            addLogger(StdOutSqlLogger)
//
//
//        }
