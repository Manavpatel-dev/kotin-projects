package org.mnp_address_book.org.mnp_address_book
import org.jetbrains.exposed.dao.EntityID
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import org.mnp_address_book.createTable

enum class CityEnum(val state:String) {
    SURAT("GUJARAT"),
    VADODARA("GUJARAT"),
    AHMEDABAD("GUJARAT"),
    BANGALORE("KARNATAKA"),
    ANAND("GUJARAT"),
    MAHUVA("GUJARAT"),
    MUMBAI("MAHARSHTRA"),
    LA("CALIFORNIA")
}
enum class StateEnum(val country:String) {
    GUJARAT("INDIA"),
    KARNATAKA("INDIA"),
    MAHARASHTRA("INDIA"),
    CALIFORNIA("USA")
}
class AddressBook {
    fun addAddress(name: String, entity: Address) {
        transaction {
            val query = AddressTable.join(UserTable, JoinType.INNER)
                .select(UserTable.fname eq name and (AddressTable.type eq entity.type)).map { UserTable.id }.isEmpty()
            if (query) {
                val getUserId = UserTable.select(UserTable.fname eq name).map {User(it[UserTable.id],it[UserTable.fname]) }
                val userId : EntityID<Int>
                if(getUserId.isEmpty()) {
                    userId = UserTable.insert {
                        it[fname] = name
                    } get UserTable.id
                }else{
                    userId = getUserId.first().id
                }
                AddressTable.insert {
                    it[city] = entity.city
                    it[state] = entity.state
                    it[zipcode] = entity.zipcode
                    it[country] = entity.country
                    it[street1] = entity.street1
                    it[street2] = entity.street2
                    it[uid] = userId.toString().toInt()
                    it[type] = entity.type
                } get AddressTable.id
            } else {
                println("Already exists!")
            }
        }
    }
    fun getAllAddress() {
        transaction {
            val ua = AddressTable.selectAll()
            for (i in ua) {
                println(
                    "${i[AddressTable.id]} of ${
                        UserTable.select(UserTable.id.eq(i[AddressTable.uid])).map { User(it[UserTable.id],it[UserTable.fname]) }
                    } : ${i[AddressTable.street1]} ${i[AddressTable.street2]} ${i[AddressTable.city]} ${i[AddressTable.state]} ${i[AddressTable.zipcode]} ${i[AddressTable.country]} "
                )
            }
        }
    }
    fun getAddressfromName(name: String) {
        transaction {
            addLogger(StdOutSqlLogger)
            val query = AddressTable.join(UserTable, JoinType.INNER).select(UserTable.fname eq name)
            query.forEach {
                println("${it[AddressTable.id]} of ${it[UserTable.fname]} ( ${it[AddressTable.type]} ): ${it[AddressTable.street1]} ${it[AddressTable.street2]} ${it[AddressTable.city]} ${it[AddressTable.state]} ${it[AddressTable.zipcode]} ${it[AddressTable.country]} ")
            }
        }
    }
    fun deleteAddress(name: String, type: String) {
        transaction {
            addLogger(StdOutSqlLogger)
            val query = AddressTable.join(UserTable, JoinType.INNER).slice(AddressTable.id)
                .select(UserTable.fname eq name and (AddressTable.type eq type))
            query.forEach {
                AddressTable.deleteWhere { AddressTable.id eq it[AddressTable.id] }
                println("Deleted address!")
            }
            val uti = Utility()
            uti.userwithnoaddress()
        }
    }
    fun updateAddress(name: String, type: String) {
        transaction {
            addLogger(StdOutSqlLogger)
            val query = AddressTable.join(UserTable, JoinType.INNER).slice(AddressTable.id)
                .select(UserTable.fname eq name and (AddressTable.type eq type))
            if (query.map{it[AddressTable.id]}.isEmpty()){
                println("No data found!")
            }else {
                val uti = Utility()
                println("Please give necessary details ")
                val entity = uti.inputAddress()
                query.forEach {
                    AddressTable.update({ AddressTable.id eq it[AddressTable.id]}) {
                        it[city] = entity.city
                        it[state] = entity.state
                        it[zipcode] = entity.zipcode
                        it[country] = entity.country
                        it[street1] = entity.street1
                        it[street2] = entity.street2
                    }
                    println("Address updated!")
                }
            }
        }
    }
}
class Menucli {
    fun menu() {
        println(".....MENU.....")
        println("1) Add Address")
        println("2) Update Address")
        println("3) Delete Address")
        println("4) Display Address")
        println("5) Search User Address")
        println("0) Exit")
        val addObj = AddressBook()
        val uti = Utility()
        when (readln().toInt()) {
            1 -> {
                println("Give necessary fields")
                var name:String
                do {
                    println("Enter name : ")
                    name = readln()
                } while (!uti.validateOnlyString(name))
                val ad = uti.inputAddress()
                addObj.addAddress(name, ad)
            }
            2 -> {
                println("Give necessary fields")
                val nt = uti.inputNameType()
                addObj.updateAddress(nt.first, nt.second)
            }
            3 -> {
                println("Give necessary fields")
                val nt = uti.inputNameType()
                addObj.deleteAddress(nt.first, nt.second)
            }
            4 -> {
                addObj.getAllAddress()
            }
            5 -> {
                println("Give necessary fields")
                var name: String
                do {
                    println("Enter name : ")
                    name = readln()
                } while (!uti.validateOnlyString(name))
                addObj.getAddressfromName(name)
            }
            else -> println("Please provide valid input")
        }
    }
}
class Utility{
    fun validateOnlyString(str : String) : Boolean {
        return str.none { it !in 'A'..'Z' && it !in 'a'..'z' }
    }
    private fun validateAplhpanum(str : String) : Boolean = !str.none { it !in 'A'..'Z' && it !in 'a'..'z' }
    fun inputNameType() : Pair<String,String>{
        var name: String
        var type: String
        do {
            println("Enter name : ")
            name = readln()
        } while (!validateOnlyString(name))
        do {
            println("Enter type : ")
            type = readln()
        } while (!validateOnlyString(type))
        return Pair(name,type)
    }
    fun inputAddress(): Address {
        var type: String
        var city: String
        var zipcode: String
        val country: String
        do {
            println("Enter type : ")
            type = readln()
        } while (!validateOnlyString(type))
        println("Enter street 1 : ")
        val street1: String = readln()
        println("Enter street 2 : ")
        val street2: String = readln()
        do {
            println("Enter city : ")
            city = readln().uppercase()
        } while (!enumContains<CityEnum>(city))
        do {
            println("Enter zipcode : ")
            zipcode = readln()
        } while (!validateAplhpanum(zipcode))
        val state: String = CityEnum.valueOf(city.uppercase()).state
        println("State : $state")
        country = StateEnum.valueOf(state.uppercase()).country
        println("Country : $country")
        return Address(type, street1, street2, city, zipcode, state, country)
    }
    inline fun <reified T : Enum<T>> enumContains(name: String): Boolean {
        return enumValues<T>().any { it.name == name.lowercase()} || enumValues<T>().any { it.name == name.uppercase()}
    }
    fun userwithnoaddress(){
        transaction {
            addLogger(StdOutSqlLogger)
            val getUserWithNoAddress =UserTable.join(AddressTable, JoinType.LEFT).slice(UserTable.id).select(AddressTable.uid eq null)
            getUserWithNoAddress.forEach{
                println(it[UserTable.id])
                println("User with id : ${it[UserTable.id]} is being deleted for having no address.")
                UserTable.deleteWhere { UserTable.id eq it[UserTable.id] }
                println("User deleted for having no address.")
            }
        }
    }
}
fun main(){
    createTable()
    var exitcode: Int
    val mnobj = Menucli()
    do{
        mnobj.menu()
        println("press 0 to continue and 1 to exit")
        exitcode = readln().toInt()
    }while (exitcode == 0)
}


/**
 * create table contacts (
 *  id bigint auto increment,
 *  firstname varchar(25) not null,
 *  lastname varchar(25) not null
 *  )
 *
 *  create table phonenumbers (
 *      id bigint auto increment,
 *      belongsto bigint --fk to contacts.id
 *      phone char(20),
 *      type char(10)
 *      )
 *
 *  create table addresses(
 *      id bigint auto increment,
 *      of bigint, --fk to contacts.id
 *      city varchar(50) not null,
 *      state varchar(50) not null,
 *      country varchar(50) not null,
 *      zipcode varchar(50) not null
 *    )
 */