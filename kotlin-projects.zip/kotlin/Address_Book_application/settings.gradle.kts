
rootProject.name = "Address_Book_application"

