package org.address_book_app

import java.util.*


interface Command {
    fun execute(): Unit
}

data class Address(
    val type: String,
    val street1: String,
    val street2: String,
    val city: String,
    val zipcode: String,
    val state: String,
    val country: String
)
data class AddressKey(val name: String, val type: String)

val addresses = mutableMapOf<AddressKey, Address>()

class CreateAddressCmd(val name: String,val useraddress: Address): Command {
    override fun execute() {
        addresses[AddressKey(name,useraddress.type)] = useraddress
    }
}

class updateAddressCmd(val name: String,val useraddress: Address): Command {
    override fun execute() {
        val x =addresses.keys

        if(x.contains(AddressKey(name, useraddress.type)))
        {
            addresses[AddressKey(name,useraddress.type)] = useraddress

        }
        else
            println("No Such User Found!")







    }
}
class deleteAddressCmd(val name: String,val useraddress: Address): Command {
    override fun execute() {
        addresses.remove(AddressKey(name,useraddress.type))
    }
}
class displayAddressCmd(): Command {
    override fun execute() {
        println("$addresses\n")

    }
}






fun cmdExecutor(cmd: Command) = cmd.execute()

fun main() {


    var x=0
    while(x==0) {
        println("Welcome to Address Book")
        println("Press 1 to add address\n"+"Press 2 to update address\n"+"Press 3 to Delete address\n"+"Press 4 to Display address\n"+"Press 5 to Terminate\n")
        var number1 = Scanner(System.`in`)
        print("Enter your choice: ")
        var n:Int = number1.nextInt()

        when (n) {

            1 -> {

                val address = user_details()
                val c1 = CreateAddressCmd(user(), address)
                cmdExecutor(c1)
            }

            2 -> {
                println("enter a existing record")
                val address = user_details()
                val c1 = updateAddressCmd(user(), address)
                cmdExecutor(c1)
            }
            3 -> {
                println("enter a existing recordwhich you want to del")
                val address = user_details()
                val c1 = deleteAddressCmd(user(), address)
                cmdExecutor(c1)
            }
            4 -> {
                val c3 = displayAddressCmd()
                cmdExecutor(c3)
            }
            else -> x = 1


        }
    }







}

fun user():String
{
    print("enter name")
    var name= readLine()!!
    return name
}
fun type(): String
{
    print("enter type")
    var type= readLine()!!
    return type
}

fun user_details():Address {

    print("enter name")
    var name= readLine()!!
    print("enter type")
    var type= readLine()!!
    print("enter street1")
    var street1= readLine()!!
    print("enter street2")
    var street2= readLine()!!
    print("enter city")
    var city= readLine()!!
    print("enter zipcode")
    var zipcode= readLine()!!
    print("enter state")
    var state= readLine()!!
    print("enter country")
    var country= readLine()!!
    val c1 = Address(type, street1, street2, city, zipcode, state, country)
    return c1
}
