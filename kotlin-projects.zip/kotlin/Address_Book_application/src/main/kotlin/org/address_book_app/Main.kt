import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import java.sql.Connection
import java.sql.SQLException

class DataSource{
    init {
        config.setJdbcUrl( "jdbc:mysql://127.0.0.1:3306/ADDRESS")
        config.setUsername( "newuser" );
        config.setPassword( "password" );
        config.addDataSourceProperty( "cachePrepStmts" , "true" );
        config.addDataSourceProperty( "prepStmtCacheSize" , "250" );
        config.addDataSourceProperty( "prepStmtCacheSqlLimit" , "2048" );
        dataSource = HikariDataSource( config );
    }
    companion object {
        val config = HikariConfig()
        var dataSource: HikariDataSource ?=null
        @Throws(SQLException::class)
        fun getConnection(): Connection? {
            return dataSource!!.getConnection()
        }

    }



}
@Throws(SQLException::class)
fun addData()
{
    DataSource()
//    val createDb="create database AddressBook"
    val createUserTable="create table User(uid INTEGER PRIMARY KEY AUTO_INCREMENT,firstname VARCHAR(20),lastname VARCHAR(20));"
    val createAddressTable="create table Address( name VARCHAR(20) NOT NULL, type VARCHAR(10) NOT NULL, street1 VARCHAR(50), street2 VARCHAR(50), city VARCHAR(20), state VARCHAR(15), country VARCHAR(15), pincode INT);"
    val createCityTable="CREATE TABLE City(city VARCHAR(20) PRIMARY KEY,state VARCHAR(20), FOREIGN KEY (state) REFERENCES State(state));"
    val createStateTable="CREATE TABLE State(state VARCHAR(20) PRIMARY KEY,country VARCHAR(20));"


    try{
        val con= DataSource.getConnection()
        //val  preparedStatement= con!!.prepareStatement(createStateTable)
        val  preparedStatement= con!!.prepareStatement(createAddressTable)

        val resultSet=preparedStatement.execute()

    }
    catch (e:SQLException) {
        print(e)
    }
}
fun main(args: Array<String>) {
    addData()
}