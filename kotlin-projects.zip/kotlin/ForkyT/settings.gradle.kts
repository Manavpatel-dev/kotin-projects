rootProject.name = "ForkyT"
include("forky-core")
include("forky-core")
include("forky-apis")
include("forky-apis")
include("forky-apis")
