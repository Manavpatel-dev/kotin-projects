import org.jetbrains.kotlin.gradle.tasks.KotlinCompile
import java.net.URI

plugins {
    kotlin("jvm") version "1.4.32"
//    kotlin("kapt") version "1.4.32"
    java
    `maven-publish`
    idea
}

group = "com.vayana.vnet"
version = "0.2.3"

allprojects {
    val vayanaMavenUsername: String by project
    val vayanaMavenPassword: String by project
    val arrowKtVersion: String by project
    val logbackVersion: String by project
    val waltVersion: String by project
    val junitVersion: String by project
    val flitVersion: String by project
    val waltCacheVersion: String by project
    val ktorVersion: String by project

    fun AuthenticationSupported.mavenVayanaCredentials() {
        credentials {
            username = vayanaMavenUsername
            password = vayanaMavenPassword
        }
    }

    fun RepositoryHandler.mavenVayana() {
        maven {
            val repo = URI("sftp://asptools.vayana.com:4044/var/lib/maven/")
            url = if (project.version.toString().toLowerCase().endsWith("-snapshot"))
                repo.resolve("snapshots")
            else
                repo.resolve("releases")
            mavenVayanaCredentials()
        }
    }

    fun RepositoryHandler.mavenVayanaReleases() {
        maven {
            url = URI("https://maven.vayana.com/releases")
            mavenVayanaCredentials()
        }
    }

    fun RepositoryHandler.mavenVayanaSnapshots() {
        maven {
            url = URI("https://maven.vayana.com/snapshots")
            mavenVayanaCredentials()
        }
    }

    repositories {
        jcenter()
        mavenCentral()
        mavenVayanaReleases()
        mavenVayanaSnapshots()
        mavenLocal()
    }

    tasks.withType<KotlinCompile>().configureEach {
        kotlinOptions.jvmTarget = "1.8"
    }

    apply(plugin = "org.jetbrains.kotlin.jvm")
    apply(plugin = "kotlin-kapt")

    dependencies {
        implementation(kotlin("stdlib"))
        implementation("org.jetbrains.kotlin", "kotlin-reflect", "1.4.32")
        implementation("org.jetbrains.kotlinx", "kotlinx-coroutines-core", "1.4.3")
        implementation("com.vayana.walt", "walt", waltVersion)
            .exclude("ch.qos.logback")
            .exclude("io.arrow-kt")
            .exclude("org.eclipse.jetty")
            .exclude("org.jetbrains.kotlin")
        implementation("io.arrow-kt", "arrow-core", arrowKtVersion)
        implementation("io.arrow-kt", "arrow-fx", arrowKtVersion)
        implementation("io.arrow-kt", "arrow-meta", arrowKtVersion)
        implementation("io.arrow-kt", "arrow-syntax", arrowKtVersion)
        implementation("com.vayana.walt", "walt-cache", waltCacheVersion)
        implementation("com.vayana.vnet", "flit", flitVersion)
//        kapt("io.arrow-kt", "arrow-meta", arrowKtVersion)
        implementation("ch.qos.logback", "logback-classic", logbackVersion)
        implementation("ch.qos.logback", "logback-access", logbackVersion)
        testImplementation("com.vayana.vnet", "flit", flitVersion, classifier = "testlib")
        testImplementation("org.apache.poi", "poi", "4.1.2")
        testImplementation("org.apache.poi", "poi-ooxml", "4.1.2")
        testImplementation("org.junit.jupiter", "junit-jupiter", junitVersion)
        testRuntimeOnly("org.junit.jupiter", "junit-jupiter-engine", junitVersion)
        implementation("io.ktor", "ktor-client-core", ktorVersion)
        implementation("io.ktor", "ktor-client-core-jvm", ktorVersion)
        implementation("io.ktor", "ktor-client-cio", ktorVersion)
        implementation("io.ktor", "ktor-client-json-jvm", ktorVersion)
        implementation("io.ktor", "ktor-client-auth-basic", ktorVersion)
        testImplementation("org.junit.jupiter", "junit-jupiter", junitVersion)
        testImplementation("io.ktor", "ktor-client-core", ktorVersion)
        testImplementation("io.ktor", "ktor-client-core-jvm", ktorVersion)
        testImplementation("io.ktor", "ktor-client-mock", ktorVersion)
        testImplementation("io.ktor", "ktor-client-mock-jvm", ktorVersion)
        testImplementation("org.apache.poi", "poi", "4.1.2")
        testImplementation("org.apache.poi", "poi-ooxml", "4.1.2")
        testImplementation("org.junit.jupiter", "junit-jupiter-api", junitVersion)
    }

    val sourcesJar by tasks.registering(Jar::class) {
        archiveClassifier.set("sources")
        from(sourceSets.main.get().allSource)
    }

    val testJar by tasks.registering(Jar::class) {
        archiveBaseName.set("${project.name}-tests")
        archiveClassifier.set("tests")
        from(sourceSets.test.get().output)
    }

    val testSourcesJar by tasks.registering(Jar::class) {
        archiveBaseName.set("${project.name}-testsrc")
        archiveClassifier.set("testsrc")
        from(sourceSets.test.get().allSource)
    }

    configurations {
        sourcesJar.get()
        testJar.get()
        testSourcesJar.get()
    }

    tasks.test {
        useJUnitPlatform()
        testLogging {
            events("passed", "skipped", "failed")
        }
    }
}


//================OLD============================//

//import org.jetbrains.kotlin.gradle.tasks.KotlinCompile
//
//plugins {
//    kotlin("jvm") version "1.6.10"
//    application
//}
//
//group = "me.harshagola"
//version = "1.0"
//
//repositories {
//    mavenCentral()
//}
//
//    dependencies {
//        testImplementation(kotlin("test"))
//        implementation("io.ktor:ktor-server-core:1.6.7")
//        implementation("io.ktor:ktor-server-netty:1.6.7")
//        implementation("ch.qos.logback:logback-classic:1.2.10")
//        implementation("io.ktor:ktor-serialization:1.6.7")
//        implementation("io.ktor:ktor-jackson:1.6.7")
//        implementation("com.zaxxer:HikariCP:5.0.1")
//        implementation("mysql:mysql-connector-java:8.0.25")
//        implementation("org.jetbrains.exposed", "exposed", "0.17.14")
//        implementation("io.arrow-kt:arrow-core:1.0.1")
//    }
//
//tasks.test {
//    useJUnitPlatform()
//}
//
//tasks.withType<KotlinCompile> {
//    kotlinOptions.jvmTarget = "1.8"
//}
//
//application {
//    mainClass.set("MainKt")
//}