plugins {
    kotlin("jvm")
}

group = "me.harshagola"
version = "1.0"

repositories {
    mavenCentral()
}
val jacksonVersion: String by project
val tipoVersion: String by project
val exposedVersion: String by project
val hikariVersion: String by project
dependencies {
    api("com.vayana.walt", "tipo", tipoVersion)
    api("org.jetbrains.exposed", "exposed-core", exposedVersion)
    api("org.jetbrains.exposed", "exposed-jdbc", exposedVersion)
    api("org.jetbrains.exposed", "exposed-java-time", exposedVersion)
    api("com.zaxxer", "HikariCP", hikariVersion)
    api("com.fasterxml.jackson.datatype", "jackson-datatype-jsr310", jacksonVersion)
}
tasks.test {
    useJUnitPlatform()
}

