
import com.vayana.vnet.forky.spikes.core.db.ApplicantTable
import com.vayana.vnet.forky.spikes.core.models.Applicant
import com.vayana.vnet.forky.spikes.core.processing.ApplicationContext
import com.vayana.vnet.forky.spikes.core.processing.Services
import com.vayana.vnet.forky.spikes.core.processing.createApplicant
import com.vayana.vnet.forky.spikes.core.processing.fetchApplicantbyId

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction

val datasource = HikariDataSource(
    HikariConfig().apply {
        jdbcUrl = "jdbc:mysql://127.0.0.1:3306/Forky"
        username = "Test123"
        password = "test123"
    }
)

val database = Database.connect(datasource)

fun createTable(){
    transaction {
        SchemaUtils.drop(ApplicantTable)
        SchemaUtils.create(ApplicantTable)
    }
}

suspend fun main() {
    createTable()
      val ac = ApplicationContext(Services(database))
      val appPayLoad = Applicant("Manav","mnpatel67@gml.com","6355087110")
      createApplicant(ac,appPayLoad)
    val x = fetchApplicantbyId(ac,1)
    println(x)
    println("Done!!!")


}