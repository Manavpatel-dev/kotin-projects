package com.vayana.vnet.forky.spikes.core.processing

fun ApplicationContext.toCommandContext(): CommandContext =
    CommandContext(this.services.db)
