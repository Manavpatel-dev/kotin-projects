package com.vayana.vnet.forky.spikes.core.processing

import arrow.core.Either
import arrow.core.computations.either
import com.vayana.vnet.forky.spikes.core.common.ForkyError
import com.vayana.vnet.forky.spikes.core.db.ApplicantRecord
import com.vayana.vnet.forky.spikes.core.models.Applicant
import org.jetbrains.exposed.sql.Database


data class ApplicationContext(
    val services: Services
)

data class Services(
    val db: Database
)

suspend fun fetchApplicantbyId(
    ac: ApplicationContext,
    applicantId: Long,
): Either<ForkyError, List<ApplicantRecord>> =
either {
    val cmdCtx = ac.toCommandContext()
    val cmd = FetchApplicantById(applicantId)
    handleCommand(cmd, cmdCtx, ::handleFetchApplicantByIdCmd).bind()
}

suspend fun createApplicant(
    ac: ApplicationContext,
//    cc: CallContext,
//    userOrg: UUID,
    applicantPayload: Applicant
): Either<ForkyError, ApplicantRecord> =
    either {
        val cmdCtx = ac.toCommandContext()
        val cmd = CreateApplicant(applicantPayload)
        handleCommand(cmd, cmdCtx, ::handleCreateApplicantCmd).bind()
    }