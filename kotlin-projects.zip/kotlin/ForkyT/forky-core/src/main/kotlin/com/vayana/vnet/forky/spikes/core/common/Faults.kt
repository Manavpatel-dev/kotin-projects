package com.vayana.vnet.forky.spikes.core.common


import arrow.core.Either
import com.vayana.tipo.DatabaseError
import com.vayana.vnet.flit.cache.FlitError
import com.vayana.walt.errors.Fault

enum class ForkyFaultType {
    ClientError,
    AuthorisationError,
    RuntimeError,
    ConfigurationError,
    ValidationError,
    CacheError,
    DbError,
    MissingConfigError
}

typealias ForkyError = Fault<ForkyFaultType>

fun DatabaseError.toForkyError(ft: ForkyFaultType, msg: String, args: Map<String, Any?> = mapOf()): ForkyError =
    Fault(ft, msg, (args + mapOf("db-err" to message, "err-type" to type)), cause)

fun <T> Either<DatabaseError, T>.toForkyError(
    ft: ForkyFaultType,
    msg: String,
    args: Map<String, Any?> = mapOf()
): Either<ForkyError, T> =
    mapLeft { it.toForkyError(ft, msg, args) }

fun FlitError.toForkyError(): Fault<ForkyFaultType> =
    Fault(ForkyFaultType.ConfigurationError, message, args, cause)

fun <T> Either<FlitError, T>.toForkyError(): Either<ForkyError,T> =
    this.mapLeft { it.toForkyError() }