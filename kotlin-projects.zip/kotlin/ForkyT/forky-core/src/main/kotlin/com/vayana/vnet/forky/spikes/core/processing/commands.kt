package com.vayana.vnet.forky.spikes.core.processing

import arrow.core.Either
import arrow.core.computations.either
import com.vayana.vnet.forky.spikes.core.common.ForkyError
import com.vayana.vnet.forky.spikes.core.db.ApplicantRecord
import com.vayana.vnet.forky.spikes.core.models.Applicant
import org.jetbrains.exposed.sql.Database
import java.time.LocalDateTime
import java.util.*

data class CommandContext(
//    val vayanaId: UUID,
    val db: Database,
)

typealias CommandResult<T> = Either<ForkyError, T>
typealias CommandHandler<CMD, RES> = suspend (CMD, CommandContext) -> CommandResult<RES>

suspend fun <C : Command, R> handleCommand(
    cmd: C,
    ctx: CommandContext,
    handler: CommandHandler<C, R>,
//    auditCmd: Audit? = null,
//    lookupOrg: Boolean = true,
//    lookupUser: Boolean = true
): CommandResult<R> =
    either {
        handler(cmd, ctx).bind()
    }

sealed class Command(
//    open val user: UserId,
//    open val entity: OrgId,
    open val actionPerformedAt: LocalDateTime = LocalDateTime.now()
)

data class FetchApplicantById(
    val applicantId : Long
):Command()

data class CreateApplicant(
    val applicant : Applicant
):Command()
