package com.vayana.vnet.forky.spikes.core.db

import arrow.core.Either
import arrow.core.computations.either
import com.vayana.tipo.BaseSerialiser
import com.vayana.tipo.DatabaseError
import com.vayana.tipo.TipoFaultType
import com.vayana.tipo.table.VersionableBaseTable
import com.vayana.vnet.forky.spikes.core.common.ForkyVersionedRecord
import com.vayana.walt.utils.catchE
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.`java-time`.datetime
import org.jetbrains.exposed.sql.statements.UpdateBuilder
import java.time.LocalDateTime

data class ApplicantRecord(
    override val id: Long,
    val name: String,
    val mobileNumber: String,
    val email: String,
    override val version: Int,
    override val createdOn: LocalDateTime
): ForkyVersionedRecord<Long>{

}

class ApplicantSerializer : BaseSerialiser<Long, ApplicantRecord>(){
    override fun recordToRow(s: UpdateBuilder<Number>, r: ApplicantRecord) {
//        s[ApplicantTable.id] = r.id
        s[ApplicantTable.name] = r.name
        s[ApplicantTable.mobileNumber] = r.mobileNumber
        s[ApplicantTable.email] = r.email
        s[ApplicantTable.createdOn] = r.createdOn
        s[ApplicantTable.version] = r.version
    }

    override fun rowToRecord(r: ResultRow): Either<DatabaseError, ApplicantRecord> =
        catchE(TipoFaultType.SerializationError, "err-failed-to-serialize-row-to-record"){
            either.eager<DatabaseError,ApplicantRecord >{
                ApplicantRecord(
                    r[ApplicantTable.id].value,
                    r[ApplicantTable.name],
                    r[ApplicantTable.mobileNumber],
                    r[ApplicantTable.email],
                    r[ApplicantTable.version],
                    r[ApplicantTable.createdOn]
                )
            }
        }
}

object ApplicantTable : VersionableBaseTable<Long, ApplicantRecord , ApplicantSerializer >("applicant"){
    override val defaultSerializer: ApplicantSerializer= ApplicantSerializer()
    override val id: Column<EntityID<Long>> = long("id").autoIncrement().entityId()
    override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }
    val name = varchar("name",20)
    val email= varchar("email" , 20)
    val mobileNumber = varchar("phone" , 13)
    val createdOn = datetime("created_on").clientDefault { LocalDateTime.now() }
}

