package com.vayana.vnet.forky.spikes.core.db.repos

import arrow.core.Either
import arrow.core.computations.either
import com.vayana.vnet.forky.spikes.core.common.ForkyError
import com.vayana.vnet.forky.spikes.core.common.ForkyFaultType
import com.vayana.vnet.forky.spikes.core.common.toForkyError
import com.vayana.vnet.forky.spikes.core.db.ApplicantRecord
import com.vayana.vnet.forky.spikes.core.db.ApplicantTable
import org.jetbrains.exposed.sql.insert

object ApplicantRepo {

    fun saveApplicant(applicantRecord: ApplicantRecord):Either<ForkyError,Unit> =
    either.eager{
        val r = ApplicantTable.insert {
            defaultSerializer.recordToRow(it,applicantRecord)
        }
    }

    fun getApplicantById(aid: Long): Either<ForkyError, List<ApplicantRecord>> =
        ApplicantTable.findByOperation({
            ApplicantTable.id eq aid
        }).toForkyError(ForkyFaultType.DbError,"err-applicant-id-not-found")
}
