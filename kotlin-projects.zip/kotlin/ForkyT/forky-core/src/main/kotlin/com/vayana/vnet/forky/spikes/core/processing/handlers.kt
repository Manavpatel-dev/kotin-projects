package com.vayana.vnet.forky.spikes.core.processing

import arrow.core.*
import arrow.core.computations.either
import com.vayana.tipo.transactionE
import com.vayana.vnet.flit.util.xTransactionE
import com.vayana.vnet.forky.spikes.core.common.ForkyError
import com.vayana.vnet.forky.spikes.core.common.ForkyFaultType
import com.vayana.vnet.forky.spikes.core.common.toForkyError
import com.vayana.vnet.forky.spikes.core.common.toRecord
import com.vayana.vnet.forky.spikes.core.db.ApplicantRecord
import com.vayana.vnet.forky.spikes.core.db.repos.ApplicantRepo
import com.vayana.walt.errors.Fault

suspend fun handleFetchApplicantByIdCmd(
    cmd: FetchApplicantById,
    cmdCtx: CommandContext
): Either<Fault<ForkyFaultType>, List<ApplicantRecord>> =
    xTransactionE {
        either{
            val applicant = ApplicantRepo.getApplicantById(cmd.applicantId).bind()
            applicant
        }
    }

suspend fun handleCreateApplicantCmd(
    cmd: CreateApplicant,
    cmdCtx: CommandContext,
//    handleAuditFor: auditRecordsFn? = null
): Either<ForkyError, ApplicantRecord> =
    transactionE {
        either.eager<ForkyError, ApplicantRecord> {
            val applicantRecord=
                cmd.applicant.toRecord(-1).bind()

            ApplicantRepo.saveApplicant(applicantRecord).bind()
            applicantRecord
            }}
