package com.vayana.vnet.forky.spikes.core.models

import java.time.LocalDate
import java.util.*

data class Applicant(
    val name: String,
    val mobileNumber: String,
    val email: String
)

enum class TaxIdentifierType {
    GSTIN,
    PAN,
    OTHERS
}

enum class ConstitutionType {
    SoleProprietorShip,
    Partnership,
    LLP,
    LLC,
    Pvt,
    Ltd
}

enum class CompanyRole {
    Seller,
    Buyer,
    Financier,
    Insurer,
    Other
}

enum class NatureOfBusiness{
    Manufacturing,
    Service,
    Trading
}
enum class IndustryType{

}

enum class Currencies{
    USD,
    INR,
    EUR,
    JPY,
    GBP,
    CAD
}

interface TaxInformation {
    val taxIdentifier: String
    val taxIdentifierType: TaxIdentifierType
}

data class IndianCompanyTaxInformation(
    override val taxIdentifier: String,
    override val taxIdentifierType: TaxIdentifierType,
    val legalName: String,
    val address: String, //TODO: Should be Address class
    val constitutionType: ConstitutionType
) : TaxInformation

data class ForeignCompanyTaxInformation(
    override val taxIdentifier: String,
    override val taxIdentifierType: TaxIdentifierType,
    val legalName: String,
    val taxJurisdiction: String,
    val taxRegistrationBody: String,
    val taxAccountNumber: String
//    val countryOfIncorporation: String, //TODO: When is this different than the country selected earlier?
//    val dateOfIncorporation: LocalDate,
//    val dateOfCommencement: LocalDate,
//    val nature
) : TaxInformation


//API - 1 Request
data class ApplicationHeader(
    val applicant: Applicant,           //screen1
    val companyType: CompanyRole,       //screen1
    val countryOfRegistration: String,  //screen1
    val basicInfo: TaxInformation       //screen2a, screen2b
)

interface BusinessRegistrationInfo {
    val applicationId: UUID
    val websiteURL: String
    val dateofCommencement: LocalDate
    val natureOfBusiness: NatureOfBusiness
    val natureOfActivity: String
    val IECno: String
    val LegalEntityIdentifier: String

}

//API2A
data class IndianCorporateCompanyRegistrationInfo(
    override val applicationId: UUID,
    override val websiteURL: String,
    override val dateofCommencement: LocalDate,
    override val natureOfBusiness: NatureOfBusiness,
    override val natureOfActivity: String,
    override val IECno: String,
    override val LegalEntityIdentifier: String,
    val CIN: String,
    val placeOfRegistration: String,
    val dateOfRegistration: LocalDate,
    val ListedCompany: Boolean,
    val industryType: IndustryType,


    ) : BusinessRegistrationInfo

//API2B
data class IndianNonCorporateCompanyRegistrationInfo(
    override val applicationId: UUID,
    override val websiteURL: String,
    override val dateofCommencement: LocalDate,
    override val natureOfBusiness: NatureOfBusiness,
    override val natureOfActivity: String,
    override val IECno: String,
    override val LegalEntityIdentifier: String,



    ) : BusinessRegistrationInfo


//API2C
data class ForeignCompanyRegistrationInfo(
    override val applicationId: UUID,
    override val websiteURL: String,
    override val dateofCommencement: LocalDate,
    override val natureOfBusiness: NatureOfBusiness,
    override val natureOfActivity: String,
    override val IECno: String,
    override val LegalEntityIdentifier: String,
) : BusinessRegistrationInfo

data class Address(
    val addressline1: String,
    val addressLine2: String,
    val district: String,
    val city: String,
    val state: String,
    val country: String,
    val zipcode: String
)

data class AddressBlock(
    val address: Address,
    val phoneNumber: String,
    val extension: String
)

data class BusinessAddress(
    val registeredAddress: AddressBlock,
    val communicationAddress: AddressBlock
)


//data class currency(
//    val currencies: List<Currencies>
//)

/*
* Settlement Bank details:
* Correspondent Bank details:
* Common details:
*   -Bank name
*   -Bank account number
*   -IFSC/Sort code
*   -IBAN
*   -Swift code
* Settlement Bank official
* Settlement Bank Address:
* Undertaking
* */


data class Application(
    val header: ApplicationHeader,
    val registrationInfo: BusinessRegistrationInfo,
    val businessAddress: BusinessAddress
)
