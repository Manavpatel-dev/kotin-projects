package com.vayana.vnet.forky.spikes.core.common

import arrow.core.Either
import com.vayana.tipo.TipoFaultType
import com.vayana.vnet.forky.spikes.core.db.ApplicantRecord
import com.vayana.vnet.forky.spikes.core.models.Applicant
import com.vayana.walt.errors.Fault
import com.vayana.walt.utils.catchT
import java.time.LocalDateTime

fun Applicant.toRecord(oid: Long): Either<ForkyError, ApplicantRecord> =
    catchT(TipoFaultType.SerializationError, "err-serialising-request-to-record") {
        ApplicantRecord(
            oid,
            this@toRecord.name,
            this@toRecord.email,
            this@toRecord.mobileNumber,
            0,
            LocalDateTime.now()
        )
    }.toForkyError(ForkyFaultType.DbError,"")