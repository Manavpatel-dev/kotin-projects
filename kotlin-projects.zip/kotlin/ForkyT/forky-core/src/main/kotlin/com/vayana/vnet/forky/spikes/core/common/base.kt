package com.vayana.vnet.forky.spikes.core.common

import com.vayana.tipo.VersionedRecord
import java.time.LocalDateTime
import java.time.ZoneId

interface ForkyVersionedRecord<I : Comparable<I>> : VersionedRecord<I> {
    val createdOn: LocalDateTime
    fun createdOnMillis() = createdOn.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()
}
