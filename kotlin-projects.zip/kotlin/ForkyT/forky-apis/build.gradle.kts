plugins {
    kotlin("jvm")
}

group = "me.harshagola"
version = "1.0"

repositories {
    mavenCentral()
}

dependencies {
    implementation(kotlin("stdlib"))
}