rootProject.name = "com.example.ktor-sampleregistration"
include("forky-apis")
include("forky-apis")
