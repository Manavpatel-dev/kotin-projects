plugins {
    kotlin("jvm")
}

group = "com.example"
version = "0.0.1"

repositories {
    mavenCentral()
}

dependencies {
    implementation(kotlin("stdlib"))
    implementation("org.jetbrains.exposed", "exposed", "0.17.14")
    implementation("mysql:mysql-connector-java:8.0.25")
    implementation("com.zaxxer:HikariCP:3.3.0")
    implementation("io.arrow-kt:arrow-core:1.0.1")
}