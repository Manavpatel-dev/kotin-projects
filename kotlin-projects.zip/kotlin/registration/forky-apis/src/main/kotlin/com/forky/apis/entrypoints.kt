package com.forky.apis

import arrow.core.Either
import arrow.core.computations.either
import org.jetbrains.exposed.sql.transactions.transaction
import java.util.*
import

suspend fun handleCreateApplicationHeader(
    cmd: CreateApplicationHeader,
    cmdCtx: CommandContext) : CommandResult<Unit> =
    transaction {
        either.eager<Error,Unit>{
            ApplicationHeaderTable.insert {
                it[applicantName] = cmd.Applicant.name
                it[mobileNo] = cmd.Applicant.mobileNumber
                it[emailID] = cmd.Applicant.emailNumber
                it[participationRole] = cmd.ParticipationRole.toString()
                it[countryOfRegistration] = cmd.CountryOfRegistration
            }

        }
    }

suspend fun fetchApplicantheader(
    Applicant: Applicant,
    PartitionCompanyRole : CompanyRole,
    countryOfRegistration : String
): Either<Error,Unit> =
    either {

        val cmdCtx = CommandContext(database)
        val cmd = fetchApplicantheader(Applicant, PartitionCompanyRole,countryOfRegistration)
        handleCommand(cmd, cmdCtx::handleCreateApplicationHeader).bind()

    }


