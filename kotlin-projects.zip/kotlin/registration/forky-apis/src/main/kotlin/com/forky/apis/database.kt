package com.forky.apis

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import org.jetbrains.exposed.sql.Database

val datasource = HikariDataSource(
    HikariConfig().apply {
        jdbcUrl = "jdbc:mysql://127.0.0.1:3306/ADDRESS"
        username = "newuser"
        password = "password"
    }
)

val database = Database.connect(datasource)

object ApplicationHeaderTable