package com.forky.apis
import java.time.LocalDate
import java.util.*
data class Applicant(
    val name: String,
    val mobileNumber: String,
    val emailNumber: String
)
enum class TaxIdentifierType {
    GSTIN,
    PAN,
    OTHERS
}
enum class ConstitutionType {
    SoleProprietorShip,
    Partnership,
    LLP,
    LLC,
    Pvt,
    Ltd
}
enum class CompanyRole {
    Seller,
    Buyer,
    Financier,
    Insurer,
    Other
}
enum class NatureOfBusiness{
    Manufacturing,
    Service,
    Trading
}
enum class IndustryType{
}
interface TaxInformation {
    val taxIdentifier: String
    val taxIdentifierType: TaxIdentifierType
}
data class IndianCompanyTaxInformation(
    override val taxIdentifier: String,
    override val taxIdentifierType: TaxIdentifierType,
    val legalName: String,
    val address: String, //TODO: Should be Address class
    val constitutionType: ConstitutionType
) : TaxInformation
data class ForeignCompanyTaxInformation(
    override val taxIdentifier: String,
    override val taxIdentifierType: TaxIdentifierType,
    val legalName: String,
    val taxJurisdiction: String,
    val taxRegistrationBody: String,
    val taxAccountNumber: String
//    val countryOfIncorporation: String, //TODO: When is this different than the country selected earlier?
//    val dateOfIncorporation: LocalDate,
//    val dateOfCommencement: LocalDate,
//    val nature
) : TaxInformation
//API - 1 Request
data class ApplicationHeader(
    val applicant: Applicant,           //screen1
    val companyType: CompanyRole,       //screen1
    val countryOfRegistration: String,  //screen1
    val basicInfo: TaxInformation       //screen2a, screen2b
)
interface BusinessRegistrationInfo {
    val applicationId: UUID
    val websiteURL: String
    val dateofCommencement: LocalDate
    val natureOfBusiness: NatureOfBusiness
    val natureOfActivity: String
    val IECno: String
    val LegalEntityIdentifier: String
}
//API2A
data class IndianCorporateCompanyRegistrationInfo(
    override val applicationId: UUID,
    override val websiteURL: String,
    override val dateofCommencement: LocalDate,
    override val natureOfBusiness: NatureOfBusiness,
    override val natureOfActivity: String,
    override val IECno: String,
    override val LegalEntityIdentifier: String,
    val CIN: String,
    val placeOfRegistration: String,
    val dateOfRegistration: LocalDate,
    val ListedCompany: Boolean,
    val industryType: IndustryType,
) : BusinessRegistrationInfo
//API2B
data class IndianNonCorporateCompanyRegistrationInfo(
    override val applicationId: UUID,
    override val websiteURL: String,
    override val dateofCommencement: LocalDate,
    override val natureOfBusiness: NatureOfBusiness,
    override val natureOfActivity: String,
    override val IECno: String,
    override val LegalEntityIdentifier: String,
) : BusinessRegistrationInfo
//API2C
data class ForeignCompanyRegistrationInfo(
    override val applicationId: UUID,
    override val websiteURL: String,
    override val dateofCommencement: LocalDate,
    override val natureOfBusiness: NatureOfBusiness,
    override val natureOfActivity: String,
    override val IECno: String,
    override val LegalEntityIdentifier: String,
) : BusinessRegistrationInfo

 data class Address(

     val type: String,
     val AddressLine1: String,
     val AddressLine2: String,
     val city: String,
     val zipcode: String,
     val state: String,
     val country: String
     )
enum class addressType {


    GST,
    NEWADDRESS,
    REGISTER



}
data class Addressblock(
    val address: Address,
    val phonenumber: String,
    val extension: Int



)



data class BusinessAddress(

    val RegisterAddress : Address,
    val CommunicationAddress : Address




)






//data class Address(
//      val noncoperate: noncoperateAddress,
//      val coperate: coperateAddress
//)


























data class Application(
    val header: ApplicationHeader,
    val registrationInfo: BusinessRegistrationInfo
)