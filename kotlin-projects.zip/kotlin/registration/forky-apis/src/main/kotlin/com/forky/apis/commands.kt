package com.forky.apis

import arrow.core.Either
import arrow.core.computations.either
import org.jetbrains.exposed.sql.Database
import java.time.LocalDateTime


suspend fun <C : Command, R> handleCommand(
    cmd: C,
    ctx: CommandContext,
    handler: CommandHandler<C, R>
): CommandResult<R> =
    either{

            handler(cmd, ctx).bind()

        }

data class CommandContext
    (
    val db : Database
)
typealias CommandResult<T> = Either<Error, T>
typealias CommandHandler<CMD, RES> = suspend (CMD, CommandContext) -> CommandResult<RES>

sealed class Command {
    open val actionPerformedAt: LocalDateTime = LocalDateTime.now()

        }

data class CreateApplicationHeader(
    val Applicant : Applicant,
    val ParticipationRole: CompanyRole,
    val CountryOfRegistration: String
) : Command()