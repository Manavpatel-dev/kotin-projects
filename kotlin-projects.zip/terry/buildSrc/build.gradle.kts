import java.net.URI

plugins {
  `kotlin-dsl`
}

val vayanaMavenUsername: String by project
val vayanaMavenPassword: String by project
val waltVersion: String by project

fun AuthenticationSupported.mavenVayanaCredentials() {
  credentials {
    username = vayanaMavenUsername
    password = vayanaMavenPassword
  }
}

fun RepositoryHandler.mavenVayana() {
  maven {
    val repo = URI("sftp://asptools.vayana.com:4044/var/lib/maven/")
    url = if (project.version.toString().toLowerCase().endsWith("-snapshot"))
      repo.resolve("snapshots")
    else
      repo.resolve("releases")
    mavenVayanaCredentials()
  }
}

fun RepositoryHandler.mavenVayanaReleases() {
  maven {
    url = URI("https://maven.vayana.com/releases")
    mavenVayanaCredentials()
  }
}

fun RepositoryHandler.mavenVayanaSnapshots() {
  maven {
    url = URI("https://maven.vayana.com/snapshots")
    mavenVayanaCredentials()
  }
}

repositories {
  mavenVayanaReleases()
  mavenVayanaSnapshots()
  jcenter()
  mavenCentral()
  maven {
    url = uri("https://dl.bintray.com/kotlin/exposed")
  }

  mavenLocal()
}

dependencies {
  implementation(kotlin("stdlib-jdk8"))
  implementation("com.vayana.walt", "walt", "0.6.11-SNAPSHOT")
  implementation("io.arrow-kt", "arrow-core", "0.12.0")
}

tasks {
  compileKotlin {
    kotlinOptions.jvmTarget = "11"
  }
  compileTestKotlin {
    kotlinOptions.jvmTarget = "11"
  }
}
