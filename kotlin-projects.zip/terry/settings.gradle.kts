rootProject.name = "terry"

include(":terry-apis")
include(":terry-core")
include(":terry-common")

