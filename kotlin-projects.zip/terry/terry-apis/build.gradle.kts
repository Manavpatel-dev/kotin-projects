import com.bmuschko.gradle.docker.tasks.image.DockerBuildImage
import com.bmuschko.gradle.docker.tasks.image.Dockerfile
import com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar

plugins {
  kotlin("jvm")
  id("com.github.johnrengelman.shadow") version "7.0.0"
  id("com.bmuschko.docker-remote-api") version "6.7.0"
  application
}

group = "com.vayana.vnet"
version = "1.0-SNAPSHOT"

val ktorVersion: String by project
val waltVersion: String by project
val waltKtorVersion: String by project
val junitVersion: String by project
val networkNtVersion: String by project

dependencies {
  implementation(project(":terry-common"))
  implementation(project(":terry-core"))
  implementation("org.jetbrains.kotlinx:kotlinx-html-jvm:0.7.2")
  implementation("io.ktor", "ktor-server-jetty", ktorVersion)
  implementation("io.ktor", "ktor-server-core", ktorVersion)
  implementation("io.ktor", "ktor-auth-jwt", ktorVersion)
  implementation("io.ktor", "ktor-locations", ktorVersion)
  implementation("io.ktor", "ktor-metrics", ktorVersion)
  implementation("io.ktor", "ktor-server-host-common", ktorVersion)
  implementation("io.ktor", "ktor-jackson", ktorVersion)
  implementation("io.ktor", "ktor-client-cio", ktorVersion)


  implementation("com.vayana.walt", "walt-ktor", waltKtorVersion)
    .exclude("io.arrow-kt")
    .exclude("com.vayana.walt", "walt")
    .exclude("ch.qos.logback")
    .exclude("io.ktor")
    .exclude("org.jetbrains.kotlin")
    .exclude("org.jetbrains.kotlinx")
  implementation("com.vayana.vnet", "theodore-lib", "0.2.0")
  implementation("com.vayana.walt", "walt-logback-cloudwatch-appender", "0.3.0")

  testImplementation("io.ktor", "ktor-server-tests", ktorVersion)
  testImplementation(kotlin("test-junit5"))
  testImplementation("org.junit.jupiter:junit-jupiter-api:$junitVersion")
  testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:$junitVersion")
  implementation("com.networknt", "json-schema-validator", networkNtVersion)

}

tasks {
  val buildEnvVar: String? by project
  val buildEnv = buildEnvVar ?: "dev"

  project.setProperty("mainClassName", "com.vayana.vnet.terry.apis.Main")
  //Refer https://stackoverflow.com/questions/53853474/shadowjar-no-value-has-been-specified-for-property-mainclassname
  withType<ShadowJar> {
    manifest {
      attributes["Main-Class"] = "com.vayana.vnet.terry.apis.Main"
    }

    isZip64 = true
    exclude("log*.xml")
    archiveClassifier.set("")
    mergeServiceFiles()
  }

  register<Copy>("copyDeployScripts") {
    from("deploy/bin")
    include("**/*")
    into("$buildDir/docker/bin")
  }

  register<Copy>("copyLogbackConfigs") {
    from("src/main/resources")
    include("**/logback*")
    into("$buildDir/docker/config")
  }

  register<Copy>("copyShadowJar") {
    dependsOn("shadowJar")
    from("$buildDir/libs/${project.name}-${project.version}.jar")
    into("$buildDir/docker")
  }

  register<DockerBuildImage>("buildDockerImage") {
    dependsOn("createDockerfile")
    images.add("local_${project.name}_$buildEnv:latest")
  }

  register<Copy>("copyConfigs") {
    from("deploy/environments/$buildEnv") //Todo change path when schemajsons keys path change
    include("**/*json")
    include("**/*txt") // Todo change copyfile list
    into("$buildDir/docker/resources")
  }

  register<Dockerfile>("createDockerfile") {
    dependsOn("copyShadowJar", "copyDeployScripts", "copyLogbackConfigs", "copyConfigs")

    val appName = project.name
    val deployUser = "deploy"
    val deployGroup = "deploy"
    val deployHome = "/home/$deployUser"
    val deployBase = "$deployHome/apps/$appName"
    val deployArtifact = "$appName-${project.version}.jar"
    val appStartScript = "bin/start.sh"

    from("adoptopenjdk/openjdk15:alpine-slim")
    label(mapOf("maintainer" to "VNSPL 'engineering@vayana.com'"))
    environmentVariable(
      mapOf(
        "APP_DEPLOY_USER" to deployUser,
        "APP_DEPLOY_GROUP" to deployGroup,
        "APP_DEPLOY_HOME" to deployHome,
        "APP_DEPLOY_BASE_DIR" to deployBase,
        "APP_DEPLOY_ARTIFACT" to deployArtifact
      )
    )
    runCommand(
      """
      addgroup -S $deployGroup \
      && adduser -S $deployUser -G $deployGroup -h $deployHome \
      && mkdir -p $deployBase/bin $deployBase/logs $deployBase/config $deployBase/work \
      && chown -R $deployUser:$deployGroup $deployBase/bin  $deployBase/logs  $deployBase/config $deployBase/work \
      && apk add --no-cache dumb-init \
      && rm -rf /var/cache/apk/*
    """.trimIndent()
    )
    copyFile(provider {
      Dockerfile.CopyFile(deployArtifact, "$deployBase/bin/$deployArtifact")
        .withChown("$deployUser:$deployGroup") as Dockerfile.CopyFile
    })
    copyFile(provider {
      Dockerfile.CopyFile("./$appStartScript", "$deployBase/$appStartScript")
        .withChown("$deployUser:$deployGroup") as Dockerfile.CopyFile
    })
    copyFile(provider {
      Dockerfile.CopyFile("./config", "$deployBase/config/")
        .withChown("$deployUser:$deployGroup") as Dockerfile.CopyFile
    })

    copyFile(provider {
      Dockerfile.CopyFile("./resources", "$deployBase/config") //TODO change when schemajsonfiles path change
        .withChown("$deployUser:$deployGroup") as Dockerfile.CopyFile
    })


    workingDir("$deployBase")
    runCommand("chmod +x $deployBase/$appStartScript")
    volume(deployBase)
    entryPoint("dumb-init")
    user(deployUser)
    defaultCommand("/bin/sh", "-c", "$appStartScript ${project.version} $deployHome")
  }
}
