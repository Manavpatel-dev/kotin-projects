package com.vayana.vnet.terry.tests.scripts

import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test
import org.junit.platform.commons.logging.LoggerFactory
import java.nio.ByteBuffer
import java.util.*


class TestGenerateX5TValue {
  companion object {
    private val log = LoggerFactory.getLogger(TestGenerateX5TValue::class.java)
  }

  @Test
  fun generateX5THeaderFromFingerprints() {
    val shaSig = "69:28:6B:E3:6A:C3:9C:43:17:F4:E3:8D:C6:30:F4:48:74:B7:82:A6"; //SHA-1 FingerPrint
    val sigOctets = shaSig.split(":")
    val sigBuffer = ByteBuffer.allocate(sigOctets.size)
    sigOctets.forEach { value ->
      sigBuffer.put(Integer.parseInt(value, 16).toByte())
    }
    Assertions.assertEquals(27,String(Base64.getEncoder().encode(sigBuffer.array())).replace("=", "").replace("+", "-").replace("/", "_").length)
    println(String(Base64.getEncoder().encode(sigBuffer.array())).replace("=", "").replace("+", "-").replace("/", "_"))
  }
}
