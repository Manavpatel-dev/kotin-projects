package com.vayana.vnet.terry.tests.routes

import com.fasterxml.jackson.module.kotlin.convertValue
import com.vayana.vnet.terry.apis.EICORE_API
import com.vayana.vnet.terry.apis.V_ONE_OH_THREE
import com.vayana.vnet.terry.apis.mainModule
import com.vayana.vnet.terry.common.DataMapper
import com.vayana.vnet.terry.common.GenerateIrnResponse
import com.vayana.vnet.terry.common.InvoiceStatus
import com.vayana.vnet.terry.common.TerryResponse
import com.vayana.vnet.terry.tests.ApiTestBase
import com.vayana.vnet.terry.tests.utils.addHeader
import com.vayana.vnet.terry.tests.utils.generateIrnPayload
import com.vayana.vnet.terry.tests.utils.jsonContent
import com.vayana.vnet.terry.tests.utils.orgXUserAuthHeader
import com.vayana.walt.utils.SecretData
import com.vayana.walt.utils.aesDecrypt
import com.vayana.walt.utils.decode
import io.ktor.http.*
import io.ktor.server.testing.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test
import org.slf4j.LoggerFactory

@KtorExperimentalAPI
@ObsoleteCoroutinesApi
class TestGetEInvoiceDetails : ApiTestBase() {

  private val log = LoggerFactory.getLogger(TestGetEInvoiceDetails::class.java)

  @Test
  fun testGetEnvoiceFirst() {

    val request = generateIrnPayload()

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          orgXUserAuthHeader()

          addHeader(clientId, clientSecret, gstin, username, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        log.debug(content.toString())
        Assertions.assertEquals(
          content.get("Status").textValue(), "1",
          "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(content).also {
          Assertions.assertEquals(InvoiceStatus.ACTIVE, it.data!!.status)
        }
      }.let { response: TerryResponse<GenerateIrnResponse> ->
        testWithGetIrn(this, response)
      }
    }
  }

  private fun testWithGetIrn(
    testApplicationEngine: TestApplicationEngine,
    generateResponse: TerryResponse<GenerateIrnResponse>,
  ) {
    with(
      testApplicationEngine.handleRequest(
        HttpMethod.Get,
        "${EICORE_API}/${V_ONE_OH_THREE}/Invoice/irn/${generateResponse.data!!.irn}"
      ) {

        orgXUserAuthHeader()

        addHeader(clientId, clientSecret, gstin, username, token)

      }
    ) {
      log.debug("getResponseContent = ${response.content}")
      Assertions.assertEquals(HttpStatusCode.OK, response.status())
      val content = DataMapper.default.readTree(response.content)
      Assertions.assertEquals(
        content.get("Status").textValue(), "1",
        "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
      )
      val decryptedSek = "laqyxgFHnFnxmjFTnm7qt4ph3jECyEPYRyV6iq6hhkk="

      DataMapper.default.convertValue<TerryResponse<String>>(content).let {
        Assertions.assertEquals(DataMapper.default.writeValueAsString(generateResponse.data!!),
          SecretData(it.data!!).aesDecrypt(decryptedSek.decode()).fold({ "Error while getting IRN" }, { it })
        )
      }
    }
  }
}
