package com.vayana.vnet.terry.tests.routes

import com.vayana.vnet.terry.apis.EIVITAL_API
import com.vayana.vnet.terry.apis.V_ONE_OH_FOUR
import com.vayana.vnet.terry.apis.mainModule
import com.vayana.vnet.terry.tests.ApiTestBase
import io.ktor.http.*
import io.ktor.server.testing.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test


@KtorExperimentalAPI
@ObsoleteCoroutinesApi
class health : ApiTestBase() {

  @Test
  fun testHealthCheck() {
    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Get, "${EIVITAL_API}/${V_ONE_OH_FOUR}/heartbeat/ping")
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        Assertions.assertEquals("Thank you for checking up on me :)", response.content,
          "Health Checked Failed with ${response.content}}"
        )
      }
    }
  }
}
