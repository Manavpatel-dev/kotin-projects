package com.vayana.vnet.terry.tests.utils

import com.vayana.tipo.HiLoOidBlocks
import com.vayana.vnet.terry.apis.EIVITAL_API
import com.vayana.vnet.terry.apis.V_ONE_OH_FOUR
import com.vayana.vnet.terry.apis.mainModule
import com.vayana.vnet.terry.apis.utils.ApplicationContext
import com.vayana.vnet.terry.common.AuthIrnRequest
import com.vayana.vnet.terry.common.DataMapper
import com.vayana.vnet.terry.core.db.*
import com.vayana.vnet.terry.tests.ApiTestBase
import com.vayana.vnet.terry.tests.ApiTestBase.Companion.appKey
import com.vayana.vnet.terry.tests.ApiTestBase.Companion.clientId
import com.vayana.vnet.terry.tests.ApiTestBase.Companion.clientSecret
import com.vayana.vnet.terry.tests.ApiTestBase.Companion.gstin
import com.vayana.vnet.terry.tests.ApiTestBase.Companion.password
import com.vayana.vnet.terry.tests.ApiTestBase.Companion.token
import com.vayana.vnet.terry.tests.ApiTestBase.Companion.username
import io.ktor.http.*
import io.ktor.server.testing.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.jetbrains.exposed.sql.SchemaUtils
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.insert
import org.jetbrains.exposed.sql.transactions.transaction
import org.slf4j.LoggerFactory
import java.time.LocalDateTime

private val log = LoggerFactory.getLogger("com.vayana.vnet.terry.tests.utils.dbutils")

val tables: List<Table> = listOf(
  HiLoOidBlocks,
  InvoicesTable,
  AdditionalInvoicesDetailTable,
  ClientCredsTable,
  UserCredsTable,
  UserSessionsTable,
  UserSessionLogsTable
)

fun prepareApplicationDatabase() {
  transaction {
    destroySchema()
    createSchema()
    populateSchema()
  }
}

internal fun destroySchema() {
  tables.reversed().forEach {
    try {
      SchemaUtils.drop(it)
    } catch (e: Exception) {
      log.error("err-unable-to-drop-table-${it}", e)
      e.printStackTrace()
    }
  }
}

internal fun createSchema() {
  tables.forEach {
    try {
      SchemaUtils.create(it)
    } catch (e: Exception) {
      log.error("err-unable-to-create-table-${it}", e)
      e.printStackTrace()
    }
  }
}

internal fun populateSchema() {
  try {
    ClientCredsTable.insert {
      it[id] = clientId
      it[clientSecret] = Passwords.hash(ApiTestBase.clientSecret)
      it[status] = ClientCredsStatus.ACTIVE
      it[createdOn] = LocalDateTime.now()
      it[lastUpdated] = LocalDateTime.now()
      it[version] = 1
    }
    UserCredsTable.insert {
      it[id] = 1.toLong()
      it[username] = ApiTestBase.username
      it[password] = Passwords.hash(ApiTestBase.password)
      it[clientId] = ApiTestBase.clientId
      it[gstin] = ApiTestBase.gstin
      it[status] = UserCredsStatus.ACTIVE
      it[createdOn] = LocalDateTime.now()
      it[lastUpdated] = LocalDateTime.now()
      it[version] = 1
    }
  } catch (e: Exception) {
    log.error("err-unable-to-populate-master-data-in-table", e)
    e.printStackTrace()
  }
}


@KtorExperimentalAPI
@ObsoleteCoroutinesApi
internal fun authenticate(ac: ApplicationContext) {


  val request = AuthIrnRequest(
    userName = username,
    password = password,
    appKey = appKey
  )

  withTestApplication(moduleFunction = mainModule(ac)) {
    with(
      handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

        addHeader("client_id", clientId)
        addHeader("client_secret", clientSecret)
        addHeader("Gstin", gstin)

        this.jsonContent()
        setBody(
          DataMapper.default.writeValueAsString(
            request
          )
        )
      }
    ) {
      token = DataMapper.default.readTree(response.content).get("Data").get("AuthToken").textValue()
    }
  }

}
