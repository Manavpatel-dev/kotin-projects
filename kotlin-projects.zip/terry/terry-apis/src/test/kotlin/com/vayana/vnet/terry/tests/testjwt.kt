package com.vayana.vnet.terry.tests

import arrow.core.Either
import arrow.core.left
import arrow.core.right
import arrow.core.some
import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import com.vayana.vnet.terry.common.AssociatedOrg
import com.vayana.vnet.terry.common.DataMapper
import com.vayana.vnet.terry.common.AppFaults
import com.vayana.vnet.terry.tests.utils.THEODORE_PRIVATE_KEY
import com.vayana.walt.errors.Fault
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.interfaces.RSAPrivateKey
import java.security.spec.PKCS8EncodedKeySpec
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.*

private val theodorePrivateKeyAlgorithm =
  Algorithm.RSA256(null, getPrivateKey().fold({ null }, { it as RSAPrivateKey }))

fun makeToken(
  id: String = UUID.randomUUID().toString(),
  name: String,
  email: String?,
  mobile: String?,
  associatedOrgs: List<AssociatedOrg> = emptyList()

): String = JWT.create()
  .withSubject("Auth")
  .withIssuer("v-theo")
  .withClaim("uid", id)
  .withClaim("name", name)
  .withClaim("eml", email)
  .withClaim("mob", mobile)
  .withArrayClaim("orgs", associatedOrgs.map { DataMapper.default.writeValueAsString(it) }.toTypedArray())
  .withExpiresAt(getExpiration())
  .sign(theodorePrivateKeyAlgorithm)

private fun getExpiration() =
  Date.from(LocalDateTime.now().plusMinutes(3600L).atZone(ZoneId.systemDefault()).toInstant())

private fun getPrivateKey(): Either<Fault<AppFaults>, PrivateKey> =
  try {
    KeyFactory.getInstance("RSA").generatePrivate(
      PKCS8EncodedKeySpec(Base64.getDecoder().decode(THEODORE_PRIVATE_KEY))
    ).right()
  } catch (ex: Exception) {
    ex.printStackTrace()
    Fault(
      AppFaults.ConfigurationError,
      "err-get-private-key", cause = ex.some()
    ).left()
  }

val userToken = mapOf<String, String> (
  "orgxusr" to "3e193e19-0d70-4938-9698-287f8bd947fb"
  ).map { (k, v) ->
  k to makeToken("3e193e19-0d70-4938-9698-287f8bd947fb", "Naresh Khalasi", "naresh+orgxusr@vayana.com", "+91-9898989898")
}.toMap()

