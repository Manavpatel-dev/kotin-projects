package com.vayana.vnet.terry.tests.scripts

import Repo
import com.vayana.vnet.terry.core.db.ClientCredsStatus
import com.vayana.vnet.terry.core.db.ClientCredsTable
import com.vayana.vnet.terry.core.db.ClientRecord
import com.vayana.vnet.terry.tests.ApiTestBase
import org.jetbrains.exposed.sql.transactions.transaction
import org.junit.Assert
import org.junit.jupiter.api.Test
import org.slf4j.LoggerFactory
import java.time.LocalDateTime

class TestGenerateSaltedPassword : ApiTestBase() {
  companion object {
    private val log = LoggerFactory.getLogger(TestGenerateSaltedPassword::class.java)
  }

  @Test
  fun generateAndVerifySaltedPassword() {
    val clientRequest = ClientRecord(
      "acebaae7-6e87-460a-97b3-2f3b0be7a5ad", 1,"Abcd12345678!", ClientCredsStatus.ACTIVE,
      LocalDateTime.now(),
      LocalDateTime.now(),
    )

    val saltedPassword = Passwords.hash(clientRequest.clientSecret)
    val updatedClientRequest = clientRequest.copy(clientSecret = saltedPassword)
    transaction {
      Repo.saveClientRecord(updatedClientRequest)
      val clientDbDetail = ClientCredsTable.findById(clientRequest.id).fold({ null }, { it })

      Assert.assertTrue(Passwords.verify(clientRequest.clientSecret, clientDbDetail!!.clientSecret))
    }
  }
}
