package com.vayana.vnet.terry.tests.routes

import com.fasterxml.jackson.module.kotlin.convertValue
import com.vayana.vnet.terry.apis.*
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.db.PincodeRecord
import com.vayana.vnet.terry.tests.ApiTestBase
import com.vayana.vnet.terry.tests.buildTheodoreMockClient
import com.vayana.vnet.terry.tests.utils.addHeader
import com.vayana.vnet.terry.tests.utils.generateIrnPayload
import com.vayana.vnet.terry.tests.utils.jsonContent
import com.vayana.vnet.terry.tests.utils.orgXUserAuthHeader
import com.vayana.walt.utils.SecretData
import com.vayana.walt.utils.aesDecrypt
import com.vayana.walt.utils.decode
import com.vayana.walt.utils.getRandomString
import io.ktor.client.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.server.testing.*
import io.ktor.util.*
import kotlinx.coroutines.*
import org.junit.jupiter.api.*
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.time.LocalDate
import kotlin.system.measureTimeMillis

@KtorExperimentalAPI
@ObsoleteCoroutinesApi
@TestMethodOrder(MethodOrderer.MethodName::class)

class TestGenerateIrn : ApiTestBase() {

  companion object {
    private val log = LoggerFactory.getLogger(TestGenerateIrn::class.java)
    private const val clientId = "dummyClientId"
    private const val clientSecret = "dummyClientSecret"
    private const val gstin = "dummyGstin"
    private const val userName = "dummyUserName"
  }


  @Test
  fun testGenerateIrnSchemaValidationFailure() {

    val request = generateIrnPayload().let {
      it.copy(sellerDetails = it.sellerDetails.copy(pinCode = BigDecimal("999")))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()

          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(content).let {
          Assertions.assertEquals("2140", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testGenerateIrnFirst() {
    val request = generateIrnPayload()

    generateIRNSuccessully(request)
  }

  @Test
  fun testGenerateIrnMultipleToMeasureTime() {
    val request1 = generateIrnPayload("DOCTime001")
    val request2 = generateIrnPayload("DOCTime002")
    val request3 = generateIrnPayload("DOCTime003")

    generateIRNSuccessully(request1)
    Thread.sleep(1000)
    generateIRNSuccessully(request2)
    Thread.sleep(1000)
    generateIRNSuccessully(request3)
    Thread.sleep(1000)
  }



  @Test
  fun testGenerateIrnMultipleOnSandboxToMeasureTime(){
    val request1 = generateIrnPayload("Doc/${getRandomString(6)}")
    val request2 = generateIrnPayload("Doc/${getRandomString(6)}")
    val request3 = generateIrnPayload("Doc/${getRandomString(6)}")

    testGenerateIrnSandbox(request1)
    Thread.sleep(1000)
    testGenerateIrnSandbox(request2)
    Thread.sleep(1000)
    testGenerateIrnSandbox(request3)
    Thread.sleep(1000)
  }


  fun testGenerateIrnSandbox(generateIrnRequest: GenerateIrnRequest) {

    val authRequest = AuthIrnRequest(
      userName = "dummyUser",
      password = password,
      appKey = appKey
    )

    val httpClient: HttpClient = buildTheodoreMockClient()
    withTestApplication {

      val token: String
      val performanceTimeOfAuth = measureTimeMillis {
        runBlocking {
          val authResponse = httpClient.post<String>("https://sbox.irp.vayana.com$EIVITAL_API/${V_ONE_OH_FOUR}/auth") {
            val internalPrepTimeOfAuth = measureTimeMillis {
              this.header("client_id", clientId)
              this.header("client_secret", clientSecret)
              this.header("Gstin", gstin)

              contentType(ContentType.Application.Json)
              this.setAttributes {
                body = DataMapper.default.writeValueAsString(authRequest)
              }
            }
            log.debug("internal preparation time for Auth call $internalPrepTimeOfAuth")
          }
          log.debug("------authResponseContent------${authResponse}")
          val authContent = DataMapper.default.readTree(authResponse)
          Assertions.assertEquals(
            "1", authContent.get("Status").textValue(),
            "Failed with ErrorDetails = ${authContent.get("ErrorDetails")} and InfoDtls = ${authContent.get("InfoDtls)")}"
          )
          token = authContent.get("Data").get("AuthToken").textValue()
        }
      }
      log.debug("Performance Time of Auth Call ---- $performanceTimeOfAuth")

      val performanceTime = measureTimeMillis {
        runBlocking {

          val result = httpClient.post<String>("https://sbox.irp.vayana.com$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

            val internalPrepTime = measureTimeMillis {
              this.header("client_id", clientId)
              this.header("client_secret", clientSecret)
              this.header("Gstin", gstin)
              this.header("user_name", userName)
              this.header("AuthToken", token)

              contentType(ContentType.Application.Json)
              this.setAttributes {
                body = DataMapper.default.writeValueAsString(generateIrnRequest)
              }
            }
            log.debug("internal preparation time for generate call $internalPrepTime")
          }
          log.debug("------postResponseContent------${result}")
          val content = DataMapper.default.readTree(result)
          Assertions.assertEquals(
            "1", content.get("Status").textValue(),
            "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
          )
        }
      }
      log.debug("Performance Time Of Generate Call ---- $performanceTime")
    }
  }



  private fun generateIRNSuccessully(request: GenerateIrnRequest) {
    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        log.debug(content.toString())
        Assertions.assertEquals(
          content.get("Status").textValue(), "1",
          "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(content).also {
          Assertions.assertEquals(InvoiceStatus.ACTIVE, it.data!!.status)
        }
      }.let { response: TerryResponse<GenerateIrnResponse> ->
        testWithGetIrn(this, request, response, this@TestGenerateIrn)
      }
    }
  }

  private fun testWithGetIrn(
    testApplicationEngine: TestApplicationEngine,
    request: GenerateIrnRequest,
    generateResponse: TerryResponse<GenerateIrnResponse>,
    testGenerateIrn: TestGenerateIrn,
  ) {
    with(
      testApplicationEngine.handleRequest(
        HttpMethod.Get,
        "${EICORE_API}/${V_ONE_OH_THREE}/Invoice/irn/${generateResponse.data!!.irn}"
      ) {

        addHeader(clientId, clientSecret, gstin, userName, token)
      }
    ) {
      log.debug("getResponseContent = ${response.content}")
      Assertions.assertEquals(HttpStatusCode.OK, response.status())
      val content = DataMapper.default.readTree(response.content)

      Assertions.assertEquals(
        content.get("Status").textValue(), "1",
        "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
      )
       val decryptedSek = "laqyxgFHnFnxmjFTnm7qt4ph3jECyEPYRyV6iq6hhkk="

      DataMapper.default.convertValue<TerryResponse<String>>(content).let {
        Assertions.assertEquals(DataMapper.default.writeValueAsString(generateResponse.data!!),
          SecretData(it.data!!).aesDecrypt(decryptedSek.decode()).fold({ "Error while getting IRN" }, { it })
        )
      }
    }
  }

  //changed doc Date to future for future date Validation.
  @Test
  fun testGenerateIrnFailure() {

    val request = generateIrnPayload().let {
      it.copy(documentDetails = it.documentDetails.copy(docDate = LocalDate.of(2022, 8, 18)))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        /* sample response content
        --------------------------
{
   "data":{
      "status":"0",
      "Data":null,
      "ErrorDetails":[
         {
            "ErrorCode":"errcode222",
            "ErrorMessage":"Invoice should not be future dated"
         }
      ],
      "InfoDtls":null
   }
}         */
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2163", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testGenerateIrnSchemaVersionValidation() {

    val request = generateIrnPayload().copy(version = EInvoiceVersion.ONE_OH)

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(content).let {
          Assertions.assertEquals("2279", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testGenerateIrnDocumentNumberValidation() {

    val request = generateIrnPayload().let {
      it.copy(documentDetails = it.documentDetails.copy(docNumber = "001"))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2281", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testGenerateIrnDocumentDateBeforeOctValidation() {

    val request = generateIrnPayload().let {
      it.copy(documentDetails = it.documentDetails.copy(docDate = LocalDate.of(2020, 8, 18)))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2284", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testGenerateIrnIGSTIntraFieldValidation() {

    val request = generateIrnPayload().let {
      it.copy(transactionDetails = it.transactionDetails.copy(igstIntra = YesOrNo.Z))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2285", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testSupplierPincodeValidation() {

    val request = generateIrnPayload().let {
      it.copy(sellerDetails = it.sellerDetails.copy(pinCode = BigDecimal("999999")))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2276", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testRecipientPincodeValidationWhenSupplyTypeB2B() {

    val request = generateIrnPayload().let {
      it.copy(buyerDetails = it.buyerDetails.copy(pinCode = BigDecimal("999999")))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2274", it.errorDetails!!.first().code)
          Assertions.assertEquals(
            "Recipient PIN code cannot be 999999 for B2B transaction.",
            it.errorDetails!!.first().msg
          )
        }
      }
    }
  }

  @Test
  fun testRecipientPincodeValidationWhenSupplyTypeDirectExp() {

    val request = generateIrnPayload().let {
      it.copy(
        transactionDetails = it.transactionDetails.copy(supplyType = SupplyType.EXPWP),
        buyerDetails = it.buyerDetails.copy(pinCode = BigDecimal("999998"))
      )
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2275", it.errorDetails!!.first().code)
          Assertions.assertEquals(
            "Recipient PIN code should be 999999 for Direct Export",
            it.errorDetails!!.first().msg
          )
        }
      }
    }
  }

  @Test
  fun testDispatchPincodeValidation() {

    val request = generateIrnPayload().let {
      it.copy(dispatchDetails = it.dispatchDetails?.copy(pinCode = BigDecimal("999999")))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2273", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  @Disabled
  fun testEmptyPayloadValidation() {
    val request = "{}"

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2255", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testItemQuantityValidation() {
    val request = generateIrnPayload().let {
      it.copy(items = listOf(it.items[0].copy(quantity = null)))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2238", it.errorDetails!!.first().code)
          Assertions.assertEquals("For Sl. No 1, Quantity is not passed", it.errorDetails!!.first().msg)
        }
      }
    }
  }

  @Test
  fun testItemUQCMissingValidation() {
    val request = generateIrnPayload().let {
      it.copy(items = listOf(it.items[0].copy(unitCode = null)))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2239", it.errorDetails!!.first().code)
          Assertions.assertEquals("For Sl. No 1, Unit Quantity Code (UQC) is not passed",
            it.errorDetails!!.first().msg)
        }
      }
    }
  }

  @Test
  @Disabled
  fun testItemUQCInvalidValidation() {

    val request = generateIrnPayload().let {
      it.copy(items = listOf(it.items[0].copy(unitCode = UnitCode.BAGS)))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          orgXUserAuthHeader()

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2177", it.errorDetails!!.first().code)
          Assertions.assertEquals("Unit Quantity Code(s)-BOXXX is/are not as per master",
            it.errorDetails!!.first().msg)
        }
      }
    }
  }

  @Test
  fun testItemGstRateValidation() {
    val request = generateIrnPayload().let {
      it.copy(items = listOf(it.items[0].copy(gstRate = BigDecimal("11"))))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          orgXUserAuthHeader()

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2240", it.errorDetails!!.first().code)
          Assertions.assertEquals(
            "For Sl. No 1, GST rate of tax is incorrect or not as notified",
            it.errorDetails!!.first().msg
          )
        }
      }
    }
  }

  @Test
  @Disabled
  fun testPortCodeValidation() {
    val request = generateIrnPayload().let {
      it.copy(exportDetails = it.exportDetails?.copy(portCode = PortCode.Dabhol_Port))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2201", it.errorDetails!!.first().code)
          Assertions.assertEquals(
            "Invalid Port Code",
            it.errorDetails!!.first().msg
          )
        }
      }
    }
  }

  @Test
  fun testItemIgstAmountValidation() {
    val request = generateIrnPayload().let {
      it.copy(items = listOf(it.items[0].copy(igstAmount = BigDecimal("1200.00"))))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2235", it.errorDetails!!.first().code)
          Assertions.assertEquals(
            "For Sl. No 1, IGST amount passed is not matching with taxable value and tax rate",
            it.errorDetails!!.first().msg
          )
        }
      }
    }
  }

  @Test
  fun testDetailsPincodeValidation() {
    val request = generateIrnPayload().let {
      it.copy(
        sellerDetails = it.sellerDetails.copy(pinCode = BigDecimal("999998")),
        // buyerDetails = it.buyerDetails.copy(pinCode = BigDecimal("999998")),
        shipDetails = it.shipDetails?.copy(pinCode = BigDecimal("999998"))
      )
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("3038", it.errorDetails!!.first().code)
//          Assertions.assertEquals(
//            "Buyer details Details:Pincode-999998 does not exists",
//            it.errorDetails!!.first().msg
//          )
        }
      }
    }
  }

  @Test
  fun testGenerateIrnDocumentDateFutureValidation() {

    val request = generateIrnPayload().let {
      it.copy(documentDetails = it.documentDetails.copy(docDate = LocalDate.of(2020, 8, 18)))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2284", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testIgstOnIntraForIntraSupplyValidation() {

    val request = generateIrnPayload().let {
      it.copy(
        transactionDetails = it.transactionDetails.copy(igstIntra = YesOrNo.Y),
        sellerDetails = it.sellerDetails.copy(stateCode = StateCode.Gujarat),
        buyerDetails = it.buyerDetails.copy(placeOfSupply = StateCode.MadhyaPradesh)
      )
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2262", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testrecipientGstinAndStateCodeValidation() {

    val request = generateIrnPayload().let {
      it.copy(
        buyerDetails = it.buyerDetails.copy(buyerGstin = "29AWGPV7107B1Z1", stateCode = StateCode.MadhyaPradesh)
      )
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2265", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testrecipientStateCodeWithSupplyTypeValidation() {

    val request = generateIrnPayload().let {
      it.copy(
        buyerDetails = it.buyerDetails.copy(buyerGstin = "29AWGPV7107B1Z1", stateCode = StateCode.OtherCountry)
      )
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        log.debug(content.toString())
        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2269", it.errorDetails!![1].code)
          Assertions.assertEquals(
            "Recipient state code is incorrect for transaction type B2B",
            it.errorDetails!![1].msg
          )
        }
      }
    }
  }

  @Test
  fun testrecipientStateCodeForExpTransactionValidation() {

    val request = generateIrnPayload().let {
      it.copy(
        buyerDetails = it.buyerDetails.copy(
          buyerGstin = "URP",
          stateCode = StateCode.MadhyaPradesh,
          pinCode = BigDecimal("999999")
        ),
        transactionDetails = it.transactionDetails.copy(supplyType = SupplyType.EXPWP)
      )
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2261", it.errorDetails!!.first().code)
          Assertions.assertEquals(
            "The recipient  state code is incorrect for EXPWP transaction",
            it.errorDetails!!.first().msg
          )
        }
      }
    }
  }

  @Test
  fun testrecipientGstinCannotBeURPValidation() {

    val request = generateIrnPayload().let {
      it.copy(
        buyerDetails = it.buyerDetails.copy(buyerGstin = "URP"),
        transactionDetails = it.transactionDetails.copy(supplyType = SupplyType.DEXP)
      )
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2212", it.errorDetails!!.first().code)
          Assertions.assertEquals(
            "The recipient GSTIN cannot be URP for supply type DEXP",
            it.errorDetails!!.first().msg
          )
        }
      }
    }
  }

  @Test
  fun testitemEmptyListValidation() {

    val request = generateIrnPayload().copy(
      items = emptyList()
    )

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        log.debug(content.toString())
        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(
          content
        ).let {
          Assertions.assertEquals("2228", it.errorDetails!!.first().code)
          Assertions.assertEquals("Item list cannot be empty", it.errorDetails!!.first().msg)
        }
      }
    }
  }

  @Test
  fun testPincodeCache() {
    runBlocking {
      (560000..560010).forEach {
        ac.terryCache.pincodeCache(PincodeRecord(it))
      }
      println(ac.terryCache.pincodeCache.cache.size)
    }

  }

  @Test
  fun testPincodeMappingCache() {
    runBlocking {
      (1..30).forEach {
        val result = ac.terryCache.pincodeMappingCache(it.toShort())
        log.debug(result.toString())
      }
      println(ac.terryCache.pincodeMappingCache.cache.size)
    }
  }

  @Test
  fun testHsnCache() {
    runBlocking {
      (1001..1009).forEach {
        val result = ac.terryCache.hsncodeCache(it)
        log.debug(result.toString())
      }
      println(ac.terryCache.hsncodeCache.cache.size)
    }
  }

  @Test
  fun testGenerateDuplicateIrnHashValidation() {
    val request = generateIrnPayload().let {
      it.copy(documentDetails = it.documentDetails.copy(docNumber = "docdedup/01"))
    }

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        log.debug(content.toString())
        Assertions.assertEquals(
          "1",
          content.get("Status").textValue(),
          "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls")}"
        )
      }

      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/$V_ONE_OH_THREE/Invoice") {

          addHeader(clientId, clientSecret, gstin, userName, token)

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        log.debug(content.toString())
        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls")}"
        )
        Assertions.assertEquals("2150", content["ErrorDetails"].first()["ErrorCode"].textValue())
      }
    }

  }

}

