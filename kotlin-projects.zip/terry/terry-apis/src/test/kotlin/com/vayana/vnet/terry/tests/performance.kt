package com.vayana.vnet.terry.tests


import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.networknt.schema.JsonSchema
import com.networknt.schema.JsonSchemaFactory
import com.networknt.schema.SchemaValidatorsConfig
import com.networknt.schema.SpecVersion
import com.vayana.vnet.terry.common.DataMapper
import com.vayana.vnet.terry.tests.utils.generateIrnPayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.jupiter.api.Test
import org.slf4j.LoggerFactory
import java.io.File
import java.time.Duration
import java.time.LocalDateTime
import java.util.*

class  Performance:ApiTestBase() {

  private val log = LoggerFactory.getLogger(Performance::class.java)
  val generateIrnSchemaStream: JsonNode = ObjectMapper().readTree(File("${ac.appConfig.appDirs.configDir}/generateirnschema.json"))
  val generateIrnJsonSchema= JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7).getSchema(generateIrnSchemaStream, SchemaValidatorsConfig().apply { this.isFailFast=true })!!

  private fun schemaValidator(endLimit: Int, jsonSchema: JsonSchema, data: String,endTimeList:MutableList<LocalDateTime>){
    for (i in 1..endLimit) {
      val result = jsonSchema.validate(DataMapper.default.readTree(data))
      // println(result)
    }
     endTimeList.add(LocalDateTime.now())
  }

  //this is an initial implementation of performance testing.To Proceed ahead we have to test API performance.

  @Test
  fun testSynchronousSchemaValidationPerformance() {
    val payload = generateIrnPayload().let {
      DataMapper.default.writeValueAsString(it)
    }

    val endLimits = listOf<Int>(100, 500, 1000)
    val startTimeList = mutableListOf<LocalDateTime>()
    val endTimeList = mutableListOf<LocalDateTime>()

    endLimits.map {
      startTimeList.add(LocalDateTime.now())
      schemaValidator(it, generateIrnJsonSchema, payload,endTimeList)
    }

    val durationList = mutableListOf<Long>()
    val fmt = Formatter()
    for (i in endLimits.indices) {
      durationList.add(Duration.between(startTimeList[i], endTimeList[i]).toMillis())
      fmt.format("%18s %32s %20s %18s\n", "start-Time", "end-Time", "Diff", "No. of Request")
      fmt.format("%14s\t %10s %8s %12s\n", startTimeList[i], endTimeList[i], durationList[i], endLimits[i]);
    }
    println(fmt)
  }

  @Test
  fun testAsynchronousSchemaValidationPerformance() {

    val payload = generateIrnPayload().let {
      DataMapper.default.writeValueAsString(it)
    }

    val endLimits = listOf<Int>(100, 500, 1000)
    val startTimeList = mutableListOf<LocalDateTime>()
    val endTimeList = mutableListOf<LocalDateTime>()

    runBlocking {
      endLimits.map {
        startTimeList.add(LocalDateTime.now())
        launch(context = Dispatchers.IO) { schemaValidator(it, generateIrnJsonSchema, payload, endTimeList) }
      }
    }

    val durationList = mutableListOf<Long>()
    val fmt = Formatter()
    for (i in endLimits.indices) {
      durationList.add(Duration.between(startTimeList[i], endTimeList[i]).toMillis())
      fmt.format("%18s %32s %20s %18s\n", "start-Time", "end-Time", "Diff", "No. of Request")
      fmt.format("%14s\t %10s %8s %12s\n", startTimeList[i], endTimeList[i], durationList[i], endLimits[i]);
    }
    println(fmt)
  }
}
