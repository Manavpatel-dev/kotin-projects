package com.vayana.vnet.terry.tests

import java.math.BigDecimal
import java.math.RoundingMode

fun main() {
  var x = BigDecimal("2")
  val o = BigDecimal("2.34")

  println(o.setScale(0, RoundingMode.CEILING).setScale(2).plus(BigDecimal.ONE))
  println(o.setScale(0, RoundingMode.CEILING).plus(BigDecimal.ONE))
  println(o.setScale(0, RoundingMode.FLOOR).setScale(2).minus(BigDecimal.ONE))
  println(o.setScale(0, RoundingMode.FLOOR).minus(BigDecimal.ONE))

  println("hello ${BigDecimal("4").compareTo(BigDecimal(4.00))}")


  val a = BigDecimal("2.98")

  val b = BigDecimal("298")
  val input = BigDecimal("298")
  val hundred = BigDecimal("100.00")
  println(x.div(hundred))
  println(x.divide(hundred))
  println(o.div(hundred))
  println(o.divide(hundred))
  println(a.div(hundred))
  println(a.divide(hundred))
  println(b.div(hundred))
  println(b.divide(hundred))
  println(input.div(hundred))
  println(input.divide(hundred))


  /*
  //      log.debug("***** find1 % ${ measureTimeMillis {
//        it.gstRate.toPercentage()
//      }}")
//      val HUNDRED = BigDecimal("100")
//      log.debug("***** find2 % ${ measureTimeMillis {
//        it.gstRate.div(HUNDRED)
//      }}")
//      val gstratepercent = it.gstRate.toPercentage()
//      log.debug("***** DIVIDE % ${ measureTimeMillis {
//        gstratepercent.divide(HUNDRED)
//      }}")
//      log.debug("***** find3 % ${ measureTimeMillis {
//        gstratepercent.multiply(it.taxableAmount)
//      }}")
//
//      println("------------")
//      log.debug("***** new1 % ${ measureTimeMillis {
//        it.gstRate.multiply(it.taxableAmount)
//      }}")
//
//      val mulres = it.gstRate.multiply(it.taxableAmount)
//
//      log.debug("***** DIVIDE1 % ${ measureTimeMillis {
//        mulres.divide(HUNDRED)
//      }}")
//
//      log.debug("***** DIVIDE2 % ${ measureTimeMillis {
//        mulres.div(HUNDRED)
//      }}")


//      log.debug("***** condition check % ${ measureTimeMillis {
//        (payloadIgstAmount.compareTo(igstValue.minusToleranceLimitNew()) == -1 || payloadIgstAmount.compareTo(igstValue.plusToleranceLimitNew()) == 1)
//      }}")

   */
}
