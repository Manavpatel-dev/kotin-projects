package com.vayana.vnet.terry.tests.utils

import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.tests.userToken
import io.ktor.http.*
import io.ktor.server.testing.*
import java.math.BigDecimal
import java.time.LocalDate

internal fun TestApplicationRequest.authHeader(userTokenIdentifier: String) =
  addHeader(HttpHeaders.Authorization, "Bearer ${userToken[userTokenIdentifier] ?: ""}")

internal fun TestApplicationRequest.vayAdminAuthHeader() = authHeader("vnspladmin")

internal fun TestApplicationRequest.orgAAdminAuthHeader() = authHeader("orgaadmin")
internal fun TestApplicationRequest.orgXUserAuthHeader() = authHeader("orgxusr")

internal fun TestApplicationRequest.addHeader(
  clientId: ClientId,
  clientSecret: String,
  gstin: Gstin,
  userName: String,
  authToken: AuthToken,
) {
  addHeader("client_id", clientId)
  addHeader("client_secret", clientSecret)
  addHeader("Gstin", gstin)
  addHeader("user_name", userName)
  addHeader("AuthToken", authToken)
}

internal fun TestApplicationRequest.jsonContent() =
  addHeader(HttpHeaders.ContentType, ContentType.Application.Json.toString())


fun generateIrnPayload(pDocNumber: String = "DOC001") = GenerateIrnRequest(
  version = EInvoiceVersion.ONE_ONE,
  irn = "cee54092fe5d1f842db9f0ea6303a12216e53585dfc3301645712926c433b0f5",
  transactionDetails = TransactionDetails(
    taxScheme = TaxScheme.GST,
    supplyType = SupplyType.B2B,
    reverseCharge = YesOrNo.Y,
    ecomGstin = "26ARZPT4384Q1MT",
    igstIntra = YesOrNo.N
  ),
  documentDetails = DocumentDetails(
    docType = DocumentType.Invoice,
    docNumber = pDocNumber,
    docDate = LocalDate.of(2020, 11, 18)
  ),
  sellerDetails = SellerDetails(
    sellerGstin = "37ARZPT4384Q1MT",
    legalName = "NIC company pvt ltd",
    tradeName = "NIC Industries",
    addressOne = "5th block, kuvempu layout",
    addressTwo = "kuvempu layout",
    location = "GANDHINAGAR",
    pinCode = BigDecimal("560025"),
    stateCode = StateCode.AndhraPradesh,
    phone = "9000000000",
    email = "abc@gmail.com"
  ),
  buyerDetails = BuyerDetails(
    buyerGstin = "29AWGPV7107B1Z1",
    legalName = "XYZ company pvt ltd",
    tradeName = "XYZ Industries",
    placeOfSupply = StateCode.ArunachalPradesh,
    addressOne = "7th block, kuvempu layout",
    addressTwo = "kuvempu layout",
    location = "GANDHINAGAR",
    pinCode = BigDecimal("562160"),
    stateCode = StateCode.Karnataka,
    phone = "91111111111",
    email = "xyz@yahoo.com"
  ),
  dispatchDetails = DispatchDetails(
    companyName = "ABC company pvt ltd",
    addressOne = "7th block, kuvempu layout",
    addressTwo = "kuvempu layout",
    location = "Banagalore",
    pinCode = BigDecimal("562160"),
    stateCode = StateCode.Karnataka
  ),
  shipDetails = ShipmentDetails(
    buyerGstin = "29AWGPV7107B1Z1",
    legalName = "CBE company pvt ltd",
    tradeName = "kuvempu layout",
    addressOne = "7th block, kuvempu layout",
    addressTwo = "kuvempu layout",
    location = "Bangalore",
    pinCode = BigDecimal("562160"),
    stateCode = StateCode.Karnataka
  ),
  items = listOf(
    Item(
      serialNumber = "1",
      productDescription = "Rice",
      service = YesOrNo.N,
      hsnCode = "1001",
      barCode = "123456",
      quantity = BigDecimal("100.345"),
      freeQuantity = BigDecimal("10"),
      unitCode = UnitCode.BAGS,
      unitPrice = BigDecimal("99.545"),
      totalAmount = BigDecimal("9988.84"),
      discountAmount = BigDecimal("10"),
      preTaxValue = BigDecimal("1"),
      taxableAmount = BigDecimal("9978.84"),
      gstRate = BigDecimal("12"),
      igstAmount = BigDecimal("1197.46"),
      cgstAmount = BigDecimal("0"),
      sgstAmount = BigDecimal("0"),
      cessRate = BigDecimal("5"),
      cessAmount = BigDecimal("498.94"),
      cessNonAdvalAmount = BigDecimal("10"),
      stateCessRate = BigDecimal("12"),
      stateCessAmount = BigDecimal("1197.46"),
      stateCessNonAdvalAmount = BigDecimal("5"),
      otherChage = BigDecimal("10"),
      totalItemAmount = BigDecimal("12897.7"),
      orderLineReference = "3256",
      originCountry = CountryCode.AntiguaAndBarbuda,
      productSerialNumber = "12345",
      batchDetails = BatchDetails(
        batchName = "123456",
        batchExpiryDate = LocalDate.of(2020, 8, 1),
        warrantyDate = LocalDate.of(2020, 9, 1),
      ),
      attributeDetails = listOf(
        AttributeDetails(
          attributeName = "Rice",
          attributeValue = "10000"
        )
      )
    )
  ),
  valueDetails = ValueDetails(
    totalAssessableValue = BigDecimal("9978.84"),
    totalCgstValue = BigDecimal("0"),
    totalSgstValue = BigDecimal("0"),
    totalIgstValue = BigDecimal("1197.46"),
    totalCessValue = BigDecimal("508.94"),
    totalStateCessValue = BigDecimal("1202.46"),
    discount = BigDecimal("10"),
    otherCharge = BigDecimal("20"),
    roundedOffAmount = BigDecimal("0.3"),
    totalInvoiceValue = BigDecimal("12908"),
    totalInvoiceValueFinal = BigDecimal("12897.7")
  ),
  payeeDetails = PayeeDetails(
    name = "ABCDE",
    bankAccountNumber = "5697389713210",
    paymentMode = PaymentMode.CASH, ifscCode = "SBIN11000",
    paymentTerms = "100",
    paymentInstructions = "Gift",
    creditTransfer = "test",
    directDebit = "test",
    creditDays = BigDecimal("100"),
    paidAmount = BigDecimal("10000"),
    dueAmount = BigDecimal("5000"),
  ),
  referenceDetails = RefDetails(
    invoiceRemarks = "TEST",
    docPerdDtsl = DocPerdDtls(
      invoiceStartDate = LocalDate.of(2020, 8, 1),
      invoiceEndDate = LocalDate.of(2020, 9, 1)
    ),
    precedingDocuments = listOf(
      PrecedingDocument(
        precedingInvoiceNumber = "DOC002",
        precedingInvoiceDate = LocalDate.of(2020, 8, 1),
        otherReferenceNumber = "123456"
      )
    ),
    contractDetails = listOf(
      ContractDetails(
        receiptAdviceNumber = "Doc003",
        receiptAdviceDate = LocalDate.of(2020, 8, 1),
        batchReferenceNumber = "Abc001",
        contractReferenceNumber = "Co123",
        otherReferenceNumber = "Yo456",
        projectReferenceNumber = "Doc-456",
        purchaseOrderReferenceNumber = "Doc-789",
        purchaseOrderReferenceDate = LocalDate.of(2020, 8, 1)
      )
    )
  ),
  additionalDocDetails = listOf(
    AdditionalDocumentDetails(
      url = "https://einv-apisandbox.nic.in",
      docs = "Test Doc",
      info = "Document Test"
    )
  ),
  exportDetails = ExportDetails(
    shipmentBillNo = "A-248",
    shipmentBillDate = LocalDate.of(2020, 8, 1),
    portCode = PortCode.Alibag,
    refund = YesOrNo.N,
    foreignCurrency = CurrencyCode.UnitedArabEmiratesDirham,
    countryCode = CountryCode.UnitedArabEmirates,
    exportDuty = BigDecimal("2")
  ),
  ewbDetails = EwayBillDetails(
    transporterGstin = "12AWGPV7107B1Z1",
    transporterName = "XYZ EXPORTS",
    transportationMode = TransportationMode.ROAD,
    distance = BigDecimal("100"),
    transportDocNumber = "DOC01",
    transportDocDate = LocalDate.of(2020, 8, 18),
    vehicleNumber = "ka123456",
    vehicleType = VehicleType.REGULAR
  )
)

