package com.vayana.vnet.terry.tests.routes

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.module.kotlin.convertValue
import com.vayana.vnet.terry.apis.*
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.tests.ApiTestBase
import com.vayana.vnet.terry.tests.utils.addHeader
import com.vayana.vnet.terry.tests.utils.generateIrnPayload
import com.vayana.vnet.terry.tests.utils.jsonContent
import com.vayana.walt.utils.getRandomString
import io.ktor.http.*
import io.ktor.server.testing.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.MethodOrderer
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestMethodOrder
import org.slf4j.LoggerFactory
import kotlin.system.measureTimeMillis

@KtorExperimentalAPI
@ObsoleteCoroutinesApi
@TestMethodOrder(MethodOrderer.Alphanumeric::class)
class TestAuth : ApiTestBase() {
  private val log = LoggerFactory.getLogger(TestAuth::class.java)

  @Test
  fun testAuthFirst() {
    val request = AuthIrnRequest(
      userName = "dummyUserName",
      password = "secret",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )
    val performanceTime = measureTimeMillis {
      withTestApplication(moduleFunction = mainModule(ac)) {
        with(
          handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

            addHeader("client_id", "dummyClientId")
            addHeader("client_secret", "dummyClientSecret")
            addHeader("Gstin", "dummyGstin")

            this.jsonContent()
            setBody(
              DataMapper.default.writeValueAsString(
                request
              ).also {
                log.debug("Request Json = ${it}")
                log.debug("Request Headers = ${this.headers}")
                log.debug("Request uri = ${this.uri}")
                log.debug("Request protocol = ${this.protocol}")
                log.debug("Request method = ${this.method}")
              }
            )
          }
        ) {
          log.debug("postResponseContent = ${response.content}")
          Assertions.assertEquals(HttpStatusCode.OK, response.status())
//        Assertions.assertEquals(HttpStatusCode.Unauthorized, response.status())
          val content = DataMapper.default.readTree(response.content)

          Assertions.assertEquals("1", content.get("Status").textValue())

          DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
            Assertions.assertNotNull(it.data?.authToken)
            Assertions.assertNotNull(it.data?.sek)
          }
        }
      }
    }
    log.debug("performance of Auth call $performanceTime")
  }

  @Test
  fun testAuthFirstandGenerateSecondwithNoToken() {
    val request = AuthIrnRequest(
      userName = "dummyUserName",
      password = "secret",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")
              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        Assertions.assertEquals("1", content.get("Status").textValue())

        DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
          Assertions.assertNotNull(it.data?.authToken)
          Assertions.assertNotNull(it.data?.sek)
        }
      }

      val request2 = generateIrnPayload()
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/$V_ONE_OH_THREE/Invoice") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")
          addHeader("user_name", "dummyUserName")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request2
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )
        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(content).also {
          Assertions.assertEquals("1005", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testAuthFirstandGenerateSecondwithCorrectToken() {
    val request = AuthIrnRequest(
      userName = "dummyUserName",
      password = "secret",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )

    var content: JsonNode
    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")
              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")

        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        content = DataMapper.default.readTree(response.content)
        Assertions.assertEquals("1", content.get("Status").textValue())
        DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
          Assertions.assertNotNull(it.data?.authToken)
          Assertions.assertNotNull(it.data?.sek)
        }
      }

      val request2 = generateIrnPayload()
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")
          addHeader("user_name", "dummyUserName")
          addHeader("AuthToken", content.get("Data").get("AuthToken").textValue())

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request2
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        log.debug(content.toString())
        Assertions.assertEquals(
          content.get("Status").textValue(), "1",
          "Failed with ErrorDetails = ${content.get("ErrorDetails")} and InfoDtls = ${content.get("InfoDtls)")}"
        )

        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(content).also {
          Assertions.assertEquals(InvoiceStatus.ACTIVE, it.data!!.status)
        }
      }
    }
  }

  @Test
  fun testAuthFirstandGenerateSecondwithIncorrectToken() {
    val request = AuthIrnRequest(
      userName = "dummyUserName",
      password = "secret",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")
              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        val content = DataMapper.default.readTree(response.content)
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        Assertions.assertEquals("1", content.get("Status").textValue())
        DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
          Assertions.assertNotNull(it.data?.authToken)
          Assertions.assertNotNull(it.data?.sek)
        }
      }

      val request2 = generateIrnPayload()
      with(
        handleRequest(HttpMethod.Post, "$EICORE_API/${V_ONE_OH_THREE}/Invoice") {

          addHeader(clientId, clientSecret, gstin, username, getRandomString(24))

          this.jsonContent()

          setBody(
            DataMapper.default.writeValueAsString(
              request2
            ).also {
              log.debug("Request Json = ${it}")

              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)
        Assertions.assertEquals(
          "0", content.get("Status").textValue(),
          "Succeeded with response = ${content}"
        )
        DataMapper.default.convertValue<TerryResponse<GenerateIrnResponse>>(content).also {
          Assertions.assertEquals("1005", it.errorDetails!!.first().code)
        }
      }
    }
  }

  @Test
  fun testAuthFailClientCredsWrong() {
    val request = AuthIrnRequest(
      userName = "dummyUserName",
      password = "secret",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "InvalidPassword")
          addHeader("Gstin", "dummyGstin")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")
              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals("0", content.get("Status").textValue())

        DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
          Assertions.assertEquals("1010", it.errorDetails?.get(0)?.code)

        }
      }
    }
  }

  @Test
  fun testAuthFailClientNOTExist() {
    val request = AuthIrnRequest(
      userName = "dummyUser",
      password = "secret",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

          addHeader("client_id", "dummyClientIdValue")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")
              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals("0", content.get("Status").textValue())

        DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
          Assertions.assertEquals("1010", it.errorDetails?.get(0)?.code)

        }
      }
    }
  }

  @Test
  fun testAuthFailUserCredsWrong() {
    val request = AuthIrnRequest(
      userName = "dummyUserName",
      password = "IncorrectPassword",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")
              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals("0", content.get("Status").textValue())

        DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
          Assertions.assertEquals("1019", it.errorDetails?.get(0)?.code)

        }
      }
    }
  }

  @Test
  fun testAuthFailUserNOTExist() {
    val request = AuthIrnRequest(
      userName = "dummyUser",
      password = "secret",
      appKey = "TV2Ak6qyHdq5SmdBQs3fnWoxiJcHFgB8t9znF2BPY6I="
    )

    withTestApplication(moduleFunction = mainModule(ac)) {
      with(
        handleRequest(HttpMethod.Post, "$EIVITAL_API/$V_ONE_OH_FOUR/auth") {

          addHeader("client_id", "dummyClientId")
          addHeader("client_secret", "dummyClientSecret")
          addHeader("Gstin", "dummyGstin")

          this.jsonContent()
          setBody(
            DataMapper.default.writeValueAsString(
              request
            ).also {
              log.debug("Request Json = ${it}")
              log.debug("Request Headers = ${this.headers}")
              log.debug("Request uri = ${this.uri}")
              log.debug("Request protocol = ${this.protocol}")
              log.debug("Request method = ${this.method}")
            }
          )
        }
      ) {
        log.debug("postResponseContent = ${response.content}")
        Assertions.assertEquals(HttpStatusCode.OK, response.status())
//        Assertions.assertEquals(HttpStatusCode.Unauthorized, response.status())
        val content = DataMapper.default.readTree(response.content)

        Assertions.assertEquals("0", content.get("Status").textValue())

        DataMapper.default.convertValue<TerryResponse<AuthIrnResponse>>(content).let {
          Assertions.assertEquals("1017", it.errorDetails?.get(0)?.code)

        }
      }
    }
  }

}





