package com.vayana.vnet.terry.tests

import com.vayana.vnet.terry.apis.utils.ApplicationContext
import com.vayana.vnet.terry.apis.utils.getHttpClientCIO
import com.vayana.vnet.terry.apis.utils.initialize
import com.vayana.vnet.terry.common.Key
import com.vayana.vnet.terry.tests.utils.authenticate
import com.vayana.vnet.terry.tests.utils.prepareApplicationDatabase
import com.vayana.vnet.terry.tests.utils.testEnvVars
import com.vayana.walt.utils.setEnvVariables
import io.ktor.client.*
import io.ktor.server.engine.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.junit.jupiter.api.BeforeAll


//Replace this mock client process with an appropriate implementation for your test setup
fun buildTheodoreMockClient(): HttpClient {
  return getHttpClientCIO()
}

open class ApiTestBase {
  companion object {
    lateinit var ac: ApplicationContext
    lateinit var token: String
    const val username = "dummyUserName"
    const val password = "secret"
    val appKey = Key.generateKey().str
    const val gstin = "dummyGstin"
    const val clientId = "dummyClientId"
    const val clientSecret = "dummyClientSecret"

    @ObsoleteCoroutinesApi
    @KtorExperimentalAPI
    @EngineAPI
    @JvmStatic
    @BeforeAll
    fun setUp() {
      setEnvVariables(testEnvVars)
      initialize("develop", buildTheodoreMockClient()).fold(
        {
          println("err-failed-setup-test-suite-${it.toLogString()}")
        },
        {
          ac = it
          prepareApplicationDatabase()
          authenticate(ac)
        }
      )
    }
  }
}
