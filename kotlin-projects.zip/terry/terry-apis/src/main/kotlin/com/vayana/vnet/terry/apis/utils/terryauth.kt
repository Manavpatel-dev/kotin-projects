package com.vayana.vnet.terry.apis.utils


import com.vayana.vnet.terry.apis.config.TerryCredentials
import com.vayana.vnet.terry.common.ErrorDetails
import com.vayana.vnet.terry.common.TerryResponse
import io.ktor.application.*
import io.ktor.auth.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import java.time.LocalDateTime


private val logger: Logger = LoggerFactory.getLogger(TerryAuthenticationProvider::class.java)


class TerryAuthenticationProvider internal constructor(config: Configuration) : AuthenticationProvider(config) {

  internal val realm: String = config.realm
  internal val authHeader: (ApplicationCall) -> String? = config.authHeader
  internal val clientIdHeader: (ApplicationCall) -> String? = config.clientIdHeader
  internal val clientSecretHeader: (ApplicationCall) -> String? = config.clientSecretHeader
  internal val gstinHeader: (ApplicationCall) -> String? = config.gstinHeader
  internal val usernameHeader: (ApplicationCall) -> String? = config.usernameHeader
  internal val authenticationFunction = config.authenticationFunction


  class Configuration internal constructor(name: String?) : AuthenticationProvider.Configuration(name) {

    internal var realm: String = "Terry Authentication"

    internal var authenticationFunction: AuthenticationFunction<TerryCredentials> = {
      throw NotImplementedError(
        "Terry auth validate function is not specified. Use terryAuth { validate { ... } } to fix."
      )
    }

    internal var authHeader: (ApplicationCall) -> String? = { call -> call.request.header("AuthToken") }

    internal var clientIdHeader: (ApplicationCall) -> String? = { call -> call.request.header("client_id") }

    internal var clientSecretHeader: (ApplicationCall) -> String? = { call -> call.request.header("client_secret") }

    internal var gstinHeader: (ApplicationCall) -> String? = { call -> call.request.header("Gstin") }

    internal var usernameHeader: (ApplicationCall) -> String? = { call -> call.request.header("user_name") }

    internal fun build() = TerryAuthenticationProvider(this)


    internal fun validate(body: AuthenticationFunction<TerryCredentials>) {
      authenticationFunction = body
    }
  }
}

/**
 * Installs Terry Authentication mechanism
 */
fun Authentication.Configuration.terryAuth(
  name: String? = null,
  configure: TerryAuthenticationProvider.Configuration.() -> Unit,
) {
  val provider = TerryAuthenticationProvider.Configuration(name).apply(configure).build()

  val realm = provider.realm

  val authenticate = provider.authenticationFunction

  provider.pipeline.intercept(AuthenticationPipeline.RequestAuthentication) { context ->

    val credentials = call.request.getAuthenticationCredentials(provider)

    val principal = credentials?.let { authenticate(call, it) }

    val cause = when {
      credentials == null -> AuthenticationFailedCause.NoCredentials
      principal == null -> AuthenticationFailedCause.InvalidCredentials
      else -> null
    }

    if (cause != null) {
      context.challenge("Invalid Credentials", cause) {
        call.respond(HttpStatusCode.OK, TerryResponse(
          status = "0",
          data = null,
          errorDetails = listOf(ErrorDetails("1005", "Invalid Token")),
          infoDetails = null)
        )
        it.complete()
      }
    }
    if (principal != null) {
      context.principal(principal)
    }
  }
  register(provider)
}

fun buildTerryUserContext(ac: ApplicationContext, creds: TerryCredentials): UserIdPrincipal? =
  //TODO validate clientID,clientSecret,and username
  ac.terryCache.tokenCache.let { tokenCache ->
    val key = Triple(creds.clientId, creds.gstin, creds.token)
    val currentTime = LocalDateTime.now()
    tokenCache(key).let {
      when {
        it == null -> null
        it.second >= currentTime -> UserIdPrincipal(it.first)
        it.second < currentTime -> {
          tokenCache.remove(key)
          null
        }
        else -> null
      }
    }
  }


fun ApplicationRequest.getAuthenticationCredentials(provider: TerryAuthenticationProvider): TerryCredentials? {

  val token = provider.authHeader(call)
  val clientId = provider.clientIdHeader(call)
  val clientSecret = provider.clientSecretHeader(call)
  val gstin = provider.gstinHeader(call)
  val username = provider.usernameHeader(call)

  return if (token == null || clientId == null || clientSecret == null || gstin == null || username == null) {
    null
  } else TerryCredentials(token, clientId, clientSecret, gstin, username)
}
