package com.vayana.vnet.terry.apis.routedef.routes

import arrow.core.computations.either
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.networknt.schema.JsonSchemaFactory
import com.networknt.schema.SchemaValidatorsConfig
import com.networknt.schema.SpecVersion
import com.vayana.vnet.terry.apis.V_ONE_OH_FOUR
import com.vayana.vnet.terry.apis.V_ONE_OH_THREE
import com.vayana.vnet.terry.apis.routedef.getUnAuthCommandContext
import com.vayana.vnet.terry.apis.routedef.handleRequest
import com.vayana.vnet.terry.apis.routedef.log
import com.vayana.vnet.terry.apis.routedef.readAndValidateJsonPayload
import com.vayana.vnet.terry.apis.utils.*
import com.vayana.vnet.terry.apis.utils.getClientId
import com.vayana.vnet.terry.apis.utils.getClientSecret
import com.vayana.vnet.terry.apis.utils.getGstin
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.processing.authIrn
import com.vayana.vnet.terry.core.processing.createIrn
import io.ktor.application.*
import io.ktor.request.*
import io.ktor.routing.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import java.io.File

@KtorExperimentalAPI
@ObsoleteCoroutinesApi
fun Route.cancel(ac: ApplicationContext) {
  val generateIrnSchemaStream: JsonNode =
    ObjectMapper().readTree(File("${ac.appConfig.appDirs.configDir}/generateirnschema.json"))
  val generateIrnJsonSchema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7)
    .getSchema(generateIrnSchemaStream, SchemaValidatorsConfig().apply { this.isFailFast = true })!!
  log.debug(">>>loading of generateIrnJsonSchema completed")
  route("/$V_ONE_OH_THREE/CInvoice") {
    delete {
      log.debug(">>>Initiated post call for generate api")
      handleRequest(ac) { cc ->
        either {
          val clientId = getClientId().bind()
          val clientSecret = getClientSecret().bind()
          val userGstin = getGstin().bind()
          val userName = getUserName().bind()
          val authToken = getAuthToken().bind()
          val jsonPayload = call.receiveText()
//        val jsonPayload = JsonPayload().bind()
          val payload = readAndValidateJsonPayload<GenerateIrnRequest>(generateIrnJsonSchema, jsonPayload).bind()
          createIrn(
            com.vayana.vnet.terry.apis.routedef.getCommandContext(ac, cc),
            clientId,
            clientSecret,
            userGstin,
            userName,
            payload
          ).bind()
        }
      }
    }


  }







}
