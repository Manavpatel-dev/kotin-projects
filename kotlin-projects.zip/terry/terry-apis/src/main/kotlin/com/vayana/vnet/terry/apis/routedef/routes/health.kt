package com.vayana.vnet.terry.apis.routedef.routes

import com.vayana.vnet.terry.apis.V_ONE_OH_FOUR
import io.ktor.application.*
import io.ktor.response.*
import io.ktor.routing.*


const val HEALTH = "heartbeat/ping"

fun Route.health() {

  get("${V_ONE_OH_FOUR}/${HEALTH}") {
    call.respondText("Thank you for checking up on me :)")
  }

}
