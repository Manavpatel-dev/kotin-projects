package com.vayana.vnet.terry.apis

import arrow.core.computations.either
import arrow.core.right
import com.vayana.vnet.terry.apis.routedef.routes.auth
import com.vayana.vnet.terry.apis.routedef.routes.core
import com.vayana.vnet.terry.apis.routedef.routes.health
import com.vayana.vnet.terry.apis.utils.*
import com.vayana.vnet.terry.common.AppFaults
import com.vayana.vnet.terry.common.DataMapper
import com.vayana.walt.errors.Fault
import com.vayana.walt.ktor.infra.initialiseServer
import io.ktor.application.*
import io.ktor.auth.*
import io.ktor.features.*
import io.ktor.http.*
import io.ktor.jackson.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.*
import io.ktor.server.engine.*
import io.ktor.server.jetty.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.jetbrains.exposed.sql.transactions.transaction
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.slf4j.event.Level
import java.util.*
import kotlin.system.exitProcess

private val log: Logger = LoggerFactory.getLogger("com.vayana.vnet.terry.apis.app")

const val EIVITAL_API = "/eivital"
const val EICORE_API = "/eicore"
const val EIEWB_API = "/eiewb"
const val V_ONE_OH_THREE = "v1.03"
const val V_ONE_OH_FOUR = "v1.04"

@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun mainModule(ac: ApplicationContext): Application.() -> Unit = {

  install(Authentication) {
    terryAuth {
      realm = "terry-apis"
      validate { creds ->
        transaction {
          buildTerryUserContext(ac,creds)
        }
      }
    }
  }




  install(AutoHeadResponse)

  install(CallId) {
    generate { UUID.randomUUID().toString() }
    verify { callId -> callId.isNotEmpty() }
    replyToHeader("X-Call-ID")
  }

  install(CallLogging) {
    level = Level.INFO
    filter { call -> call.request.path().startsWith("/") }
    callIdMdc("X-Call-ID")
  }

  install(Compression) {
    gzip {
      priority = 1.0
    }
    deflate {
      priority = 10.0
      minimumSize(1024)
    }
  }

  install(ConditionalHeaders)

  install(ContentNegotiation) {
    register(ContentType.Application.Json, JacksonConverter(DataMapper.default))
  }

  install(CORS) {
    method(HttpMethod.Options)
    method(HttpMethod.Put)
    method(HttpMethod.Delete)
    method(HttpMethod.Patch)
    method(HttpMethod.Get)
    method(HttpMethod.Post)
//    header(HttpHeaders.Authorization)
//    header(HttpHeaders.AccessControlAllowHeaders)
//    header(HttpHeaders.AccessControlAllowMethods)
//    header(HttpHeaders.AccessControlAllowOrigin)
//    header(HttpHeaders.AccessControlExposeHeaders)
//    header(HttpHeaders.AccessControlMaxAge)
    header(HttpHeaders.ContentType)
//    header(HttpHeaders.Origin)
    header("x-requested-with")
    allowCredentials = true

    anyHost() //TODO: Limit the host scope in production
    allowNonSimpleContentTypes = true
  }

  install(DataConversion)

  install(StatusPages) {
    exception<Throwable> { cause ->
      call.respondText(
        "Something went wrong, Please try again or contact Vayana support!",
        ContentType.Text.Plain,
        HttpStatusCode.InternalServerError
      )
      log.error("Unknown error!", cause)
    }
  }

  routing {
    route(EIVITAL_API) {
      health()
    }
    route(EIVITAL_API) {
      auth(ac)
    }
    authenticate {
      route(EICORE_API) {
        core(ac)
      }
    }
  }
}

object Main {
  @ObsoleteCoroutinesApi
  @KtorExperimentalAPI
  @EngineAPI
  @JvmStatic
  fun main(args: Array<String>) {
    if (args.size != 1) {
      log.error("Please provide the installation directory")
      exitProcess(1)
    } else {
      val installDir = args[0]
      either.eager<Fault<AppFaults>, Unit> {
        val ac = initialize(installDir, getHttpClientCIO()).bind()
        val server = startServer(ac)
        server.start(false)
        Runtime.getRuntime().addShutdownHook(Thread {
          ac.destroy()
          server.stop(60000, 60000)
        })
        Thread.currentThread().join()
        Unit.right()
      }.fold(
        { log.error("Failed to start Terry server -> ${it.message}") },
        {
          log.info("Terry server stopped.")
        }
      )
    }
  }
}

@KtorExperimentalAPI
@ObsoleteCoroutinesApi
@EngineAPI
private fun startServer(ac: ApplicationContext): JettyApplicationEngine =
  initialiseServer(
    host = ac.appConfig.serverEndpoint.host,
    port = ac.appConfig.serverEndpoint.port,
    module = mainModule(ac),
    stopAtShutdown = true,
    stopTimeout = 600000L,
//    accessLogbackFile = ac.appConfig.appDirs.appRoot.resolve("config").resolve("logback-access.xml").toString().some()
  )
