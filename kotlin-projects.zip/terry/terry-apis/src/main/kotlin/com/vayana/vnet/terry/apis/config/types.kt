package com.vayana.vnet.terry.apis.config

import com.vayana.vnet.terry.common.Gstin
import io.ktor.auth.*

data class TerryCredentials(
  val token: String,
  val clientId: String,
  val clientSecret: String,
  val gstin: Gstin,
  val userName: String,
) : Credential
