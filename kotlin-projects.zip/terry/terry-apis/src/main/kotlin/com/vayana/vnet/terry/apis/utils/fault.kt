package com.vayana.vnet.terry.apis.utils

import arrow.core.Either
import com.vayana.vnet.terry.common.AppFaults
import com.vayana.vnet.terry.common.TerryError
import com.vayana.vnet.terry.common.TerryFault
import com.vayana.walt.errors.Fault
import com.vayana.walt.ktor.WaltKtorFault
import io.ktor.http.*

fun WaltKtorFault.toApplicationError(): TerryError =
  TerryFault(AppFaults.ConfigurationError, message, args, cause)

fun <T> Either<WaltKtorFault, T>.toApplicationError(): Either<TerryError, T> =
  this.mapLeft { it.toApplicationError() }

fun Fault<AppFaults>.toHttpStatus() =
  when (type) {
    AppFaults.AuthenticationError,
    AppFaults.ValidationError -> HttpStatusCode.OK
    AppFaults.ClientError,
    AppFaults.CacheError,
    AppFaults.DbError -> HttpStatusCode.BadRequest
    AppFaults.ConfigurationError -> HttpStatusCode.InternalServerError
    AppFaults.RuntimeError -> HttpStatusCode.InternalServerError
    AppFaults.AuthorisationError -> HttpStatusCode.Forbidden
    AppFaults.Invalidity -> HttpStatusCode.NotFound
    AppFaults.Inconsistency -> HttpStatusCode.NotFound
    AppFaults.ForbiddenError -> HttpStatusCode.Forbidden
    AppFaults.ResourceDoesNotExist -> HttpStatusCode.NotFound
    AppFaults.ThirdPartyApiError -> HttpStatusCode.InternalServerError
  }
