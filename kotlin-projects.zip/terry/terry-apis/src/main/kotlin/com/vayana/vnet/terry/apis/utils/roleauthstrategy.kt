package com.vayana.vnet.terry.apis.utils

import arrow.core.Either
import arrow.core.computations.either
import arrow.core.left
import arrow.core.right
import arrow.core.rightIfNotNull
import com.vayana.vnet.terry.common.TerryError
import com.vayana.vnet.terry.common.AppFaults
import com.vayana.vnet.terry.common.TerryFault
import com.vayana.vnet.theodore.client.auth.UserContext
import com.vayana.walt.errors.Fault
import com.vayana.walt.ktor.Role
import io.ktor.application.*
import io.ktor.auth.*

internal suspend fun ApplicationCall.roleBasedAuthorisationStrategy(allowedRoles: Set<Role>): Either<TerryError, Unit> =
  either {
    val userContext = this@roleBasedAuthorisationStrategy.authentication.principal<UserContext>()
      .rightIfNotNull {
        TerryFault(
          AppFaults.AuthorisationError, "unauthenticated-user",
          mapOf("desc" to "unexpected-error, should have been already taken care by authentication feature")
        )
      }.bind()

    val userRoles = mutableSetOf<Role>()
    userRoles.addAll(derivedRolesByUser(this@roleBasedAuthorisationStrategy, userContext).bind())
    userRoles.addAll(derivedRolesByOrg(this@roleBasedAuthorisationStrategy, userContext).bind())

    if (userRoles.any { allowedRoles.contains(it) }) Unit.right()
    else Fault(AppFaults.AuthorisationError, "unauthorised-user").left()
  }

private fun derivedRolesByOrg(
  call: ApplicationCall,
  userContext: UserContext
): Either<TerryError, Set<Role>> =
  either.eager {
    mutableSetOf<Role>().also { userRoles ->
      call.parameters["orgid"]?.let { orgId ->
        when {
          userContext.isVayanaSuperUser -> {
            when {
              userContext.email?.let { it == System.getenv(ApplicationConfigNames.VAYANA_SYSTEM_USER_EMAIL) } ?: false -> userRoles.addAll(setOf(
                Role.VSYSUSER, Role.VUSER))
              userContext.associatedOrgs.any { it.orgId == System.getenv(ApplicationConfigNames.VAYANA_ORG_ID) && it.admin} -> userRoles.addAll(setOf(
                Role.VADMIN, Role.VUSER))
              else -> userRoles.add(Role.VUSER)
            }
          }
          userContext.associatedOrgs.any { it.orgId == orgId && it.admin } -> userRoles.addAll(setOf(Role.ORGADMIN, Role.ORGUSER))
          userContext.associatedOrgs.any { it.orgId == orgId && !it.admin } -> userRoles.add(Role.ORGUSER)
        }
      }
    }
  }

private fun derivedRolesByUser(
  call: ApplicationCall,
  userContext: UserContext
): Either<TerryError, Set<Role>> =
  either.eager {
    mutableSetOf<Role>().also { userRoles ->
      call.parameters["userid"]?.let { userId ->
        when (userContext.userId.toString()) {
          userId -> userRoles.add(Role.USER)
        }
      }
    }
  }
