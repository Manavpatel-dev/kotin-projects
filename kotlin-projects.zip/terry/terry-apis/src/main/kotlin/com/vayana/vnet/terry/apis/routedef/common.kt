package com.vayana.vnet.terry.apis.routedef

import arrow.core.Either
import arrow.core.computations.either
import arrow.core.extensions.either.applicativeError.handleError
import arrow.core.left
import arrow.core.right
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import com.networknt.schema.JsonSchema
import com.vayana.vnet.terry.apis.utils.ApplicationContext
import com.vayana.vnet.terry.apis.utils.toHttpStatus
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.processing.CommandContext
import com.vayana.vnet.theodore.client.auth.UserContext
import com.vayana.walt.errors.Fault
import com.vayana.walt.ktor.ResponseFileObject
import com.vayana.walt.ktor.respondFault
import com.vayana.walt.ktor.respondFileObject
import io.ktor.application.*
import io.ktor.auth.*
import io.ktor.features.*
import io.ktor.http.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.util.*
import io.ktor.util.pipeline.*
import org.slf4j.LoggerFactory
import updateErrorMessage
import java.time.LocalDateTime
import java.util.*

@PublishedApi internal val log = LoggerFactory.getLogger("com.vayana.vnet.terry.apis.routedef")

data class CallContext(
  val callId: UUID,
  val userContext: UserContext?,
  val clientIP: String,
  val requestUrl: String,
  val requestHeaders: MutableMap<String, Any> = mutableMapOf(),
  val requestTime: LocalDateTime = LocalDateTime.now(),
  val responseTime: LocalDateTime? = null
)

fun getCommandContext(ac: ApplicationContext, cc: CallContext) =
  CommandContext(
    ac.appConfig.key,
    ac.services.db,
    ac.terryCache,
    cc.getAuthHeader()
  )

fun getUnAuthCommandContext(ac: ApplicationContext) = CommandContext(
  ac.appConfig.key,
  ac.services.db,
  ac.terryCache,
  null
)

fun CallContext.getAuthHeader(): String? =
  (this.requestHeaders["AuthToken"] as List<String?>).first()

fun createCallContext(
  ac: ApplicationContext,
  callId: String,
  clientIP: String,
  userContext: UserContext?,
  requestUrl: String
): Either<TerryError, CallContext> =
  CallContext(UUID.fromString(callId), userContext, clientIP,requestUrl).right()

@Suppress("UNCHECKED_CAST")
private suspend fun <T> PipelineContext<*, ApplicationCall>.dispatch(
  ac: ApplicationContext,
  callId: String,
  block: suspend (CallContext) -> Either<TerryError, T>
) {
  val funcResult = createCallContext(ac, callId, call.request.origin.remoteHost, call.authentication.principal(),call.request.uri).fold(
    { it.left() },
    {
      it.requestHeaders.putAll(call.request.headers.toMap())
      log.debug("Handling request for ${it.userContext}")
      executeBlock(it, block)
    }
  )

  val newResult: Either<TerryError, T> = when (funcResult) {
    // TODO: Fix passing of infoDetails to response object
    is Either.Left -> {
      (TerryResponse(
        status = "0",
        data = null,
        errorDetails = funcResult.value.contents.map {
          ErrorDetails(it.message, updateErrorMessage(errorMessageMap.getOrDefault(it.message,it.message),
            (it.args[FAULT_RUNTIME_VALUES] ?: emptyList<String>()) as List<String>
          ))},
        infoDetails = funcResult.value.args[FAULT_RUNTIME_INFODETAILS] as InfoDetails?
      ) as T).right()   //Strictly return TerryResponse for success and fault
    }
    is Either.Right -> funcResult.value.right()
  }
  newResult.terryRespond(DataMapper.default, call, funcResult) { fault ->
    log.error("CallId: $callId -> $fault")
    fault.toHttpStatus()
  }
}

private suspend fun <T> executeBlock(
  callContext: CallContext,
  block: suspend (CallContext) -> Either<TerryError, T>
): Either<TerryError, T> =
  try {
    block(callContext).run {
      handleError { it: TerryError ->
        log.error(it.message, it.cause.orNull())
      }
      this
    }.also { log.debug(">>> Call ID :: ${callContext.callId} @@@ Request execution completed for this Url ${callContext.requestUrl}") }
  } catch (ex: Exception) {
    log.error("!!! Exception : $ex")
    TerryFault(AppFaults.RuntimeError, "err-dispatching-request").left()
  }

suspend fun <T> PipelineContext<*, ApplicationCall>.handleRequest(
  ac: ApplicationContext,
  block: suspend (CallContext) -> Either<TerryError, T>
) {
  val callId = call.callId.orEmpty()
  log.debug(">>> Call ID :: $callId >>> Handling ${this.call.request.httpMethod.value}  ${this.call.request.uri}")
  dispatch(ac, callId, block)
}

suspend inline fun PipelineContext<*, ApplicationCall>.readJsonPayload(
): Either<TerryError, String> =
  either {
    val jsonPayload = call.receiveText()
    log.debug("jsonPayload Empty ${jsonPayload.trim().length==0}")
    log.debug("empty value---$jsonPayload")
    when{
      jsonPayload.isNotEmpty() -> jsonPayload.right()
      else -> TerryFault(
      AppFaults.ClientError,"err-json-payload-validation",
      mapOf("json-parser-err" to "Requested Payload is empty"),
      contents = listOf(TerryFault(AppFaults.ValidationError,  errorSchemaCodeMap.getOrDefault("Requested Payload is empty", "2140")))
      //cause = it.some()
   ).left()
    }.bind()
  }


suspend inline fun <reified T> PipelineContext<*, ApplicationCall>.readAndValidateJsonPayload(
  schema: JsonSchema,
  jsonPayload: String,
): Either<TerryError, T> = Either.catch {
  schema.validate(DataMapper.default.readTree(jsonPayload))
}.fold(
  {
    log.debug("schema validation failed with exception ${it.message?.drop(2)} - ${it.cause}")
    TerryFault(
      AppFaults.ValidationError, "err-json-schema-validation",
      args=mapOf("schema-validation-err" to it.message?.drop(2)),
      contents = listOf(TerryFault(AppFaults.ValidationError,  errorSchemaCodeMap.getOrDefault(it.message?.drop(2), "2140")))
    ).left()
  },
  {
  Either.catch {
    DataMapper.default.readValue<T>(jsonPayload)
  }.mapLeft {
    log.debug("payload parsing failed with exception ${it.message} - ${it.cause}")
    TerryFault(
      AppFaults.ValidationError, "err-while-parsing-json-payload",
      mapOf("json-parser-err" to it.message),
      contents = listOf(TerryFault(AppFaults.ValidationError, "2140"))
    )
  }
}
)

@Suppress("NOTHING_TO_INLINE")
suspend inline fun <E : Enum<E>, T> Either<Fault<E>, T>.terryRespond(
  mapper: ObjectMapper,
  call: ApplicationCall,
  funcResult: Either<TerryError, T>,
  onErrorHttpStatusCode: (Fault<E>) -> HttpStatusCode
): Either<Fault<E>, T> =
  apply {
    fold({ fault ->
      call.respondFault(mapper, fault, onErrorHttpStatusCode(fault))
    }, { data ->
      val terryHttpStatus = if(funcResult.isLeft()) {
        (funcResult as Either.Left<TerryError>).value.toHttpStatus()
      } else HttpStatusCode.OK
      when (data) {
        is ResponseFileObject -> call.respondFileObject(data)
        is Unit -> call.respond(terryHttpStatus, "")
        else ->
          with(mapper.writeValueAsString(data)) {
            call.respondText(this, ContentType.Application.Json, terryHttpStatus)
          }
      }
    })
  }
