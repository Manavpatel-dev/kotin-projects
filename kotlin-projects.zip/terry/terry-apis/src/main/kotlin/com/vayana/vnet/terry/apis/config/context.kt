package com.vayana.vnet.terry.apis.utils

import arrow.core.Either
import arrow.core.computations.either
import arrow.core.left
import arrow.core.right
import arrow.core.some
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.data.*
import com.vayana.walt.errors.Fault
import com.zaxxer.hikari.HikariDataSource
import io.ktor.client.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.jetbrains.exposed.sql.Database
import org.slf4j.LoggerFactory
import readPemPrivateKey
import readPemPublicKey
import java.io.File
import java.nio.file.Paths

private val log = LoggerFactory.getLogger("com.vayana.vnet.terry.apis.utils.config")
const val IRN_CACHE_MAX_SIZE: Int = 100
const val IRN_CACHE_EXPIRYTIMEMILLIS = 60000L
const val HSN_CODE_CACHE_MAX_SIZE: Int = 100
const val HSN_CODE_CACHE_EXPIRYTIMEMILLIS = 60000L
const val PINCODE_MAPPING_CACHE_MAX_SIZE: Int = 100
const val PINCODE_MAPPING_EXPIRYTIMEMILLIS = 60000L
const val PINCODE_CACHE_MAX_SIZE: Int = 100
const val PINCODE_CACHE_EXPIRYTIMEMILLIS = 60000L
const val TOKEN_CACHE_MAX_SIZE: Int = 100
const val TOKEN_CACHE_EXPIRYTIMEMILLIS = 60000L
//TODO: Decide ExpiryTimeInMillis for token cache

data class VayanaSystemUserDetails(
  val handle: String,
  val password: String,
  val theodoreServerUrl: String,
)

data class CacheConfig(
  val irnCacheMaxSize: Int,
  val irnCacheExpiryTime: Long,
  val hsncodeCacheMaxSize: Int,
  val hsncodeCacheExpiryTime: Long,
  val pincodeMappingCacheMaxSize: Int,
  val pincodeMappingCacheExpiryTime: Long,
  val pincodeCacheMaxSize: Int,
  val pincodeCacheExpiryTime: Long,
  val tokenCacheMaxSize: Int,
  val tokenCacheExpiryTime: Long,
)

private fun initCache(cacheConfig: CacheConfig) = TerryCache(
  IrnCache(cacheConfig.irnCacheMaxSize, cacheConfig.irnCacheExpiryTime),
  HsncodeCache(cacheConfig.hsncodeCacheMaxSize, cacheConfig.hsncodeCacheExpiryTime),
  PincodeMappingCache(cacheConfig.pincodeMappingCacheMaxSize, cacheConfig.pincodeMappingCacheExpiryTime),
  PincodeCache(cacheConfig.pincodeCacheMaxSize, cacheConfig.pincodeCacheExpiryTime),
  TokenCache(cacheConfig.tokenCacheMaxSize, cacheConfig.tokenCacheExpiryTime)
)

data class ApplicationContext(
  val appConfig: ApplicationConfig,
  val services: Services,
  val vaySysUserDetails: VayanaSystemUserDetails,
  val terryCache: TerryCache,
) {
  fun start() {
    log.info("Starting application context....")
  }

  fun destroy() {
    log.info("Destroying application context....")
  }
}

data class ApplicationConfig(
  val serverEndpoint: ServerEndpoint,
  val appDirs: Directories,
  val dbConfig: DatabaseConfig,
  val cacheConfig: CacheConfig,
  val key: KeyConfig,
  val theodoreServerUrl: String,
  val vayanaOrgId: String,
  val sysUserEmail: String,
  val sysUserPwd: String,
)

object ServerEndpoint {
  val host: String = "0.0.0.0"
  val port: Int = System.getenv(ApplicationConfigNames.APP_SERVER_PORT)?.toInt() ?: 8997
}

data class Directories(private val rootDir: String, val configDir: String) {
  val appRoot = Paths.get(rootDir).ensureDir()
  val workDir = appRoot.resolve("work").ensureDir()
}

data class DatabaseConfig(
  val Host: String,
  val port: Short,
  val database: String,
  val username: String,
  val password: String,
  val isAutoCommit: Boolean,
  val maxConnPoolSize: Int,
)

data class Services(
  val db: Database,
)

private fun initDB(dbConfig: DatabaseConfig) =
  Database.connect(
    HikariDataSource().apply {
      jdbcUrl = "jdbc:mysql://${dbConfig.Host}:${dbConfig.port}/${dbConfig.database}?rewriteBatchedStatements=true"
      username = dbConfig.username
      password = dbConfig.password
      isAutoCommit = dbConfig.isAutoCommit
      maximumPoolSize = dbConfig.maxConnPoolSize
    }
  ).apply {
    useNestedTransactions = false
  }

object ApplicationConfigNames {
  const val LOG_HOST = "LOG_HOST"
  const val APP_SERVER_PORT = "APP_SERVER_PORT"
  const val APP_SERVER_CONFIG = "APP_SERVER_CONFIG"
  const val APP_DB_HOST = "APP_DB_HOST"
  const val APP_DB_PORT = "APP_DB_PORT"
  const val APP_DB_NAME = "APP_DB_NAME"
  const val APP_DB_USERNAME = "APP_DB_USERNAME"
  const val APP_DB_PASSWORD = "APP_DB_PASSWORD"
  const val VAYANA_ORG_ID = "VAYANA_ORG_ID"
  const val THEODORE_PUBLIC_KEY = "THEODORE_PUBLIC_KEY"
  const val VAYANA_SYSTEM_USER_EMAIL = "VAYANA_SYSTEM_USER_EMAIL"
  const val VAYANA_SYSTEM_USER_PASSWORD = "VAYANA_SYSTEM_USER_PASSWORD"
  const val THEODORE_SERVER_URL = "THEODORE_SERVER_URL"
}

private fun loadConfig(installDir: String, configDir: String): Either<Fault<AppFaults>, ApplicationConfig> =
  try {
    log.info("Loading configurations...")
    val installPath = Paths.get(installDir).ensureDir()
    val terryPrivateKey = readPemPrivateKey("$configDir/vayana_terry_private_key_v1.txt")
    val terryPublicKey = readPemPublicKey("$configDir/vayana_terry_public_key_v1.txt")
    ApplicationConfig(
      ServerEndpoint,
      Directories(installPath.toString(), configDir),
      DatabaseConfig(
        System.getenv(ApplicationConfigNames.APP_DB_HOST),
        System.getenv(ApplicationConfigNames.APP_DB_PORT).toShort(),
        System.getenv(ApplicationConfigNames.APP_DB_NAME),
        System.getenv(ApplicationConfigNames.APP_DB_USERNAME),
        System.getenv(ApplicationConfigNames.APP_DB_PASSWORD),
        false,
        5
      ),
      CacheConfig(
        IRN_CACHE_MAX_SIZE,
        IRN_CACHE_EXPIRYTIMEMILLIS,
        HSN_CODE_CACHE_MAX_SIZE,
        HSN_CODE_CACHE_EXPIRYTIMEMILLIS,
        PINCODE_MAPPING_CACHE_MAX_SIZE,
        PINCODE_MAPPING_EXPIRYTIMEMILLIS,
        PINCODE_CACHE_MAX_SIZE,
        PINCODE_CACHE_EXPIRYTIMEMILLIS,
        TOKEN_CACHE_MAX_SIZE,
        TOKEN_CACHE_EXPIRYTIMEMILLIS
      ),
      KeyConfig(terryPublicKey, terryPrivateKey,
        System.getenv(ApplicationConfigNames.THEODORE_PUBLIC_KEY),
        JWT_HEADER_X5T_FOR_SIGNING,
        JWT_HEADER_KID_FOR_SIGNING
      ),
      System.getenv(ApplicationConfigNames.THEODORE_SERVER_URL),
      System.getenv(ApplicationConfigNames.VAYANA_ORG_ID),
      System.getenv(ApplicationConfigNames.VAYANA_SYSTEM_USER_EMAIL),
      System.getenv(ApplicationConfigNames.VAYANA_SYSTEM_USER_PASSWORD)
    ).right()
  } catch (e: Exception) {
    log.error("err-loading-config", e)
    Fault(AppFaults.ConfigurationError, "error-loading-config", cause = e.some()).left()
  }

@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun initialize(
  installDir: String = "deploy",
  theodoreClient: HttpClient,
): Either<Fault<AppFaults>, ApplicationContext> =
  either.eager {
    val configDir = if (System.getenv(ApplicationConfigNames.APP_SERVER_CONFIG) == null
    ) throw IllegalArgumentException("err-config-directory-missing")
    else
      System.getenv(ApplicationConfigNames.APP_SERVER_CONFIG)
    val appConfig = File(configDir).let { it ->
      if (it.exists() && it.isDirectory) {
        loadConfig(installDir, configDir).bind().right()
      } else run {
        log.debug("err-not-able-get-config-directory")
        Fault(
          AppFaults.ConfigurationError,
          "err-not-able-get-config-directory",
          mapOf("Path" to it.absolutePath)
        )
      }.left()
    }.bind()

    val vaySysUserDetails = VayanaSystemUserDetails(
      appConfig.sysUserEmail,
      appConfig.sysUserPwd,
      appConfig.theodoreServerUrl
    )
    ApplicationContext(
      appConfig,
      Services(
        db = initDB(appConfig.dbConfig),
      ),
      vaySysUserDetails,
      initCache(appConfig.cacheConfig)
    )
  }
