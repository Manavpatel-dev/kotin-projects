package com.vayana.vnet.terry.apis.routedef.routes

import arrow.core.computations.either
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.networknt.schema.JsonSchemaFactory
import com.networknt.schema.SchemaValidatorsConfig
import com.networknt.schema.SpecVersion
import com.vayana.vnet.terry.apis.V_ONE_OH_FOUR
import com.vayana.vnet.terry.apis.routedef.getUnAuthCommandContext
import com.vayana.vnet.terry.apis.routedef.handleRequest
import com.vayana.vnet.terry.apis.routedef.log
import com.vayana.vnet.terry.apis.routedef.readAndValidateJsonPayload
import com.vayana.vnet.terry.apis.utils.ApplicationContext
import com.vayana.vnet.terry.apis.utils.getClientId
import com.vayana.vnet.terry.apis.utils.getClientSecret
import com.vayana.vnet.terry.apis.utils.getGstin
import com.vayana.vnet.terry.common.AuthIrnRequest
import com.vayana.vnet.terry.common.AuthIrnResponse
import com.vayana.vnet.terry.common.TerryError
import com.vayana.vnet.terry.common.TerryResponse
import com.vayana.vnet.terry.core.processing.authIrn
import io.ktor.application.*
import io.ktor.request.*
import io.ktor.routing.*
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import java.io.File


@KtorExperimentalAPI
@ObsoleteCoroutinesApi
fun Route.auth(ac: ApplicationContext) {

  val irnAuthSchemaStream: JsonNode = ObjectMapper().readTree(File("${ac.appConfig.appDirs.configDir}/irnauthschema.json"))
  val irnAuthJsonSchema= JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7).getSchema(irnAuthSchemaStream, SchemaValidatorsConfig().apply { this.isFailFast=true })!!
  log.debug(">>>loading of AuthSchema completed")

  route("/$V_ONE_OH_FOUR/auth") {
    post {
      log.debug(">>>>>>Initiated post call for Auth api")
      handleRequest(ac) { cc ->
        either<TerryError, TerryResponse<AuthIrnResponse>> {
          val clientId = getClientId().bind()
          val clientSecret = getClientSecret().bind()
          val userGstin = getGstin().bind()
          val jsonPayload = call.receiveText()
          val payload = readAndValidateJsonPayload<AuthIrnRequest>(irnAuthJsonSchema, jsonPayload).bind()
          val res =
            authIrn(getUnAuthCommandContext(ac), clientId, clientSecret, userGstin, payload.userName, payload).bind()
          res
        }
      }
    }
  }
}
