package com.vayana.vnet.terry.apis.utils

import arrow.core.Either
import com.vayana.vnet.terry.apis.routedef.CallContext
import com.vayana.vnet.terry.apis.routedef.getAuthHeader
import com.vayana.vnet.terry.common.TerryError
import com.vayana.vnet.terry.core.processing.CommandContext
import com.vayana.walt.ktor.getMandatoryHeader
import com.vayana.walt.ktor.getMandatoryParam
import io.ktor.application.*
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.util.*
import io.ktor.util.pipeline.*

internal fun PipelineContext<*, ApplicationCall>.getClientId(): Either<TerryError, String> =
  getMandatoryHeader("client_id").toApplicationError().map { it }

internal fun PipelineContext<*, ApplicationCall>.getClientSecret(): Either<TerryError, String> =
  getMandatoryHeader("client_secret").toApplicationError().map { it }

internal fun PipelineContext<*, ApplicationCall>.getGstin(): Either<TerryError, String> =
  getMandatoryHeader("Gstin").toApplicationError().map { it }

internal fun PipelineContext<*, ApplicationCall>.getUserName(): Either<TerryError, String> =
  getMandatoryHeader("user_name").toApplicationError().map { it }

internal fun PipelineContext<*, ApplicationCall>.getAuthToken(): Either<TerryError, String> =
  getMandatoryHeader("AuthToken").toApplicationError().map { it }

internal fun PipelineContext<*, ApplicationCall>.getIrn(): Either<TerryError, String> =
  getMandatoryParam("irn").toApplicationError().map { it }

// TODO:Introduce getHeader function in walt-ktor which gets non-mandatory header from request
//internal fun PipelineContext<*, ApplicationCall>.getSupGstin(): Either<TerryError, String> =
//  getHeader("sup_gstin").toApplicationError().map { it }

@KtorExperimentalAPI
internal fun getHttpClientCIO(connTimeout: Long = 5000L, retryAttempts: Int = 3) = HttpClient(CIO) {
  engine {
    endpoint {
      connectTimeout = connTimeout
      connectAttempts = retryAttempts
      socketTimeout = 30 * 1000L
    }
  }
}

fun getCommandContext(ac: ApplicationContext, cc: CallContext) =
  CommandContext(
    ac.appConfig.key,
    ac.services.db,
    ac.terryCache,
    cc.getAuthHeader()
  )

