import org.jetbrains.kotlin.gradle.tasks.KotlinCompile
import java.net.URI

plugins {
  kotlin("jvm") version "1.5.31"
  java
  `maven-publish`
  idea
}

group = "com.vayana.vnet"
version = "0.0.7-SNAPSHOT"

allprojects {
  val vayanaMavenUsername: String by project
  val vayanaMavenPassword: String by project
  val arrowKtVersion: String by project
  val logbackVersion: String by project
  val waltVersion: String by project
  val junitVersion: String by project
  val waltCacheVersion: String by project
  val ktorVersion: String by project

  fun AuthenticationSupported.mavenVayanaCredentials() {
    credentials {
      username = vayanaMavenUsername
      password = vayanaMavenPassword
    }
  }

  fun RepositoryHandler.mavenVayana() {
    maven {
      val repo = URI("sftp://asptools.vayana.com:4044/var/lib/maven/")
      url = if (project.version.toString().toLowerCase().endsWith("-snapshot"))
        repo.resolve("snapshots")
      else
        repo.resolve("releases")
      mavenVayanaCredentials()
    }
  }

  fun RepositoryHandler.mavenVayanaReleases() {
    maven {
      url = URI("https://maven.vayana.com/releases")
      mavenVayanaCredentials()
    }
  }

  fun RepositoryHandler.mavenVayanaSnapshots() {
    maven {
      url = URI("https://maven.vayana.com/snapshots")
      mavenVayanaCredentials()
    }
  }

  repositories {
    jcenter()
    mavenCentral()
    mavenVayanaReleases()
    mavenLocal()
    mavenVayanaSnapshots()
  }

  tasks.withType<KotlinCompile>().configureEach {
    kotlinOptions.jvmTarget = "11"
  }

  apply(plugin = "org.jetbrains.kotlin.jvm")
  apply(plugin = "kotlin-kapt")

  dependencies {
    implementation(kotlin("stdlib"))
    implementation("org.jetbrains.kotlinx", "kotlinx-coroutines-core", "1.3.5")
    implementation("com.vayana.walt", "walt", waltVersion)
      .exclude("ch.qos.logback")
      .exclude("org.hibernate", "hibernate-validator")
      .exclude("org.glassfish", "javax.el")
      .exclude("io.arrow-kt")
      .exclude("org.eclipse.jetty")
      .exclude("org.jetbrains.kotlin")
    implementation("com.vayana.walt","walt-cache",waltCacheVersion)
    //implementation("com.vayana.walt", "walt-cache", waltCacheVersion)
    testImplementation("org.apache.poi", "poi", "5.0.0")
    testImplementation("org.apache.poi", "poi-ooxml", "5.0.0")

    implementation("io.arrow-kt", "arrow-core", arrowKtVersion)
    implementation("io.ktor", "ktor-client-core", ktorVersion)
    implementation("io.ktor", "ktor-client-core-jvm", ktorVersion)
    implementation("io.ktor", "ktor-client-json-jvm", ktorVersion)
    implementation("io.ktor", "ktor-client-auth-basic", ktorVersion)
    //kapt("io.arrow-kt", "arrow-meta", arrowKtVersion)
    implementation("ch.qos.logback", "logback-classic", logbackVersion)
    implementation("ch.qos.logback", "logback-access", logbackVersion)
    testImplementation("org.junit.jupiter", "junit-jupiter", junitVersion)
    testRuntimeOnly("org.junit.jupiter", "junit-jupiter-engine", junitVersion)

    testImplementation("io.ktor", "ktor-client-core", ktorVersion)
    testImplementation("io.ktor", "ktor-client-core-jvm", ktorVersion)
    testImplementation("io.ktor", "ktor-client-mock", ktorVersion)
    testImplementation("io.ktor", "ktor-client-mock-jvm", ktorVersion)
  }
  val sourcesJar by tasks.registering(Jar::class) {
    archiveClassifier.set("sources")
    from(sourceSets.main.get().allSource)
  }

  val testJar by tasks.registering(Jar::class) {
    archiveBaseName.set("${project.name}-tests")
    archiveClassifier.set("tests")
    from(sourceSets.test.get().output)
  }

  val testSourcesJar by tasks.registering(Jar::class) {
    archiveBaseName.set("${project.name}-testsrc")
    archiveClassifier.set("testsrc")
    from(sourceSets.test.get().allSource)
  }

  configurations {
    sourcesJar.get()
    testJar.get()
    testSourcesJar.get()
  }
  configurations.forEach {
    it.exclude("org.eclipse.jetty", "jetty-alpn-java-server")
    it.exclude("org.eclipse.jetty", "jetty-alpn-server")
  }

//  tasks.test {
//    useJUnitPlatform()
//    testLogging {
//      events("passed", "skipped", "failed")
//    }
//  }


}

val testReport = tasks.register<TestReport>("testReport") {
  destinationDir = file("$buildDir/reports/tests/test")
  reportOn(subprojects.mapNotNull {
    it.tasks.findByPath("test")
  })
}
subprojects {
  tasks.withType<Test> {
    useJUnitPlatform()
    finalizedBy(testReport)
    ignoreFailures = true
    testLogging {
      events("passed", "skipped", "failed")
    }
  }
}
