# Terry - Vayana eInvoice #
Terry is an accountant whose job is to count souls who go to The Great Beyond
### How do I get set up? ###

* Database

    ```
    mysql -u root -p mysql
    create database terrydb;
    create user terry@localhost identified by 'secret';
    grant all on terrydb.* to terry@localhost;
    flush privileges;
    ```
