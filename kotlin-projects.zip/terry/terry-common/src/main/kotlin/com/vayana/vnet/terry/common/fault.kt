package com.vayana.vnet.terry.common

import arrow.core.*
import com.fasterxml.jackson.annotation.JsonProperty
import com.vayana.walt.errors.Fault
import kotlin.collections.mapOf

class TerryFault<E : Enum<E>>(
  type: E,
  message: String,
  args: Map<String, Any?> = EMPTY_MAP,
  cause: Option<Throwable> = None,
  @Suppress("UNCHECKED_CAST")
  contents: List<Fault<E>> = EMPTY_LIST as List<Fault<E>>,
  val additionalInfo: InfoDetails? = null
): Fault<E>(type, message, args, cause, contents)

data class ErrorDetails(
  @JsonProperty("ErrorCode")
  val code: String,
  @JsonProperty("ErrorMessage")
  val msg: String)

enum class AppFaults{
  AuthorisationError,
  ClientError,
  RuntimeError,
  ConfigurationError,
  ValidationError,
  CacheError,
  DbError,
  Inconsistency,
  Invalidity,
  AuthenticationError,
  ForbiddenError,
  ResourceDoesNotExist,
  ThirdPartyApiError;

}

enum class ValidationError(errDtls: ErrorDetails, data: String? = null, infoDtls: String?=null) {
  InvalidBuyerGstin(ErrorDetails("ABCD", "Invalid Buyer Gstin")),
  DateInFuture(ErrorDetails("2163", "The document date should not be future date"))
}

typealias TerryError = TerryFault<AppFaults>

fun <T> T?.toEither(ft: AppFaults, errMsg: String, args: Map<String, Any> = mapOf()) =
  this@toEither.rightIfNotNull {
    Fault(ft, errMsg, args)
  }

fun <T> Either<Fault<AppFaults>, T>.toTerryError(): Either<TerryFault<AppFaults>, T> =
  mapLeft { TerryFault(it.type, it.message, it.args, it.cause, it.contents,null) }
