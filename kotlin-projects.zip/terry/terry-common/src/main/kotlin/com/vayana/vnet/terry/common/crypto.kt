package com.vayana.vnet.terry.common


import com.vayana.walt.utils.asBase64
import org.slf4j.LoggerFactory
import javax.crypto.KeyGenerator


class Key(val raw: ByteArray) {

  companion object {

    private val log = LoggerFactory.getLogger(Key::class.java)
    private fun randomBytes(): ByteArray = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey().encoded
    fun generateKey(): Key = Key(randomBytes()).apply {
      log.debug("Generated random key is ${str}(${str.length})")
    }

  }

  val str = raw.asBase64()
}
