package com.vayana.vnet.terry.common

// TODO: Fetch from database
val errorMessageMap = mapOf(
  "errcode111" to "BuyerGstin cannot be empty string",
  "1015" to "Invalid GSTIN for this user",  //auth
  "1010" to "Invalid Client-ID/Client-Secret", //auth
  "1017" to "Incorrect user id/User does not exists", //auth
  "1019" to "Error Invalid Credentials",  //auth
  "2140" to "Error while validating invoice",
  "2150" to "Duplicate IRN",
  "2163" to "The document date should not be future date .",
  "2177" to "Unit Quantity Code(s)-{0} is/are not as per master",
  "2201" to "Invalid Port Code",
  "2202" to "Invalid Country Code",
  "2203" to "Invalid Foreign Currency",
  "2211" to "Supplier and recipient GSTIN should not be the same.",
  "2212" to "The recipient GSTIN cannot be URP for supply type {0}",
  "2213" to "The supplier GSTIN cannot be URP",
  "2228" to "Item list cannot be empty",
  "2232" to "POS is incorrect for {0} transaction",
  "2234" to "For Sl. No {0}, SGST and CGST amount passed does not match with taxable value and tax rate",
  "2235" to "For Sl. No {0}, IGST amount passed is not matching with taxable value and tax rate",
  "2238" to "For Sl. No {0}, Quantity is not passed",
  "2239" to "For Sl. No {0}, Unit Quantity Code (UQC) is not passed",
  "2240" to "For Sl. No {0}, GST rate of tax is incorrect or not as notified",
  "2242" to "Recipient POS is incorrect for transaction type {0}",
  "2243" to "POS code is invalid",
  "2244" to "Recipient pincode is not provided for the transaction - {0}",
  "2248" to "Recepient has to be URP in case of Export transactions",
  "2255" to "Requested Payload is empty",
  "2258" to "Supplier GSTIN state codedoes not match with the state code passed in supplier details",
  "2259" to "Invalid supplier state code",
  "2260" to "The recipient  state code is invalid",
  "2261" to "The recipient  state code is incorrect for {0} transaction",
  "2262" to "For Intra-state supply, IGST cannot be charged",
  "2265" to "Recipient GSTIN state code does not match with the state code passed in recipient details",
  "2266" to "For Sl. No {0}, Cess amount passed does not match with the calculated value",
  "2267" to "For Sl. No {0}, State Cess amount passed is not as per calculated value",
  "2268" to "IGST on instra state supply is not applicable to export/SEZ transactions",
  "2269" to "Recipient state code is incorrect for transaction type {0}",
  "2271" to "SHIP TO - state code is not valid statecode for B2B, SEZ and Deemed Export transactions",
  "2272" to "SHIP TO - PIN code cannot be 999999 for B2B, SEZ and Deemed Export transactions",
  "2273" to "Dispatch from PIN code cannot be 999999",
  "2274" to "Recipient PIN code cannot be 999999 for {0} transaction.",
  "2275" to "Recipient PIN code should be 999999 for Direct Export",
  "2276" to "Supplier PIN code cannot be 999999",
  "2279" to "Invalid schema version",
  "2280" to "Invalid document type",
  "2281" to "Inavalid document number",
  "2282" to "Invalid document date format", //TODO:Implementation Left
  "2284" to "IRN cannot be generated for the document date which is prior to 1st October 2020",
  "2285" to "Invalid value for IGST on intra field",
  "3038" to "{0} details Details:Pincode-{1} does not exists",
  "3040" to "Buyer or Ship Details:Pincode - {0} does not exists",
  "5001" to "Application Error in Auth, Please Contact the help desk",  //auth
)

val errorSchemaCodeMap = mapOf(
  "DocDtls.No: does not match the regex pattern ^([a-zA-Z1-9]{1}[a-zA-Z0-9/-]{0,15})$" to "2281",
  "DocDtls.Dt: does not match the regex pattern ^[0-3][0-9]/[0-1][0-9]/[2][0][1-2][0-9]$" to "2282",//TODO:Implementation Left
  "TranDtls.IgstOnIntra: may only be 1 characters long" to "2285",
  "Requested Payload is empty" to "2255"
)
