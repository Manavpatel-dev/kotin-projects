package com.vayana.vnet.terry.common


const val JWT_HEADER_X5T_FOR_SIGNING = "aShr42rDnEMX9OONxjD0SHS3gqY" // Base64 encoded string of SHA-1 fingerprint
const val JWT_HEADER_KID_FOR_SIGNING = "MJAR1OXWOFFJ526EFWZEYA6759A3Y4VRUGW89TZF" //Randomly generated string of size 40
const val FAULT_RUNTIME_VALUES = "RUNTIME"
const val FAULT_RUNTIME_INFODETAILS = "INFODETAILS"
