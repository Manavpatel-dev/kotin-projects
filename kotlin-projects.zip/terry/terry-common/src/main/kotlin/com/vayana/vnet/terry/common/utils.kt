import java.time.LocalDate
import java.time.Month
import java.time.ZoneId

val IST_ZONE = ZoneId.of("Asia/Kolkata")
val FISCAL_YEAR = LocalDate.of(LocalDate.now(IST_ZONE).year, Month.APRIL, 1)

fun updateErrorMessage(
  errorMessageMap: String,
  runTimeValues: List<String>
): String = runTimeValues.foldIndexed(errorMessageMap) { index,acc, new ->
  acc.replace("{$index}", new)
}


