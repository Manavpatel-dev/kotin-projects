package com.vayana.vnet.terry.common

import org.slf4j.LoggerFactory
import java.nio.file.Path

private val log = LoggerFactory.getLogger("com.vayana.vnet.terry.common.files")

fun Path.ensureDir() = this@ensureDir.apply {
  val node = toFile()
  if (!node.exists()) node.mkdirs().also { log.debug("Creating $node") }
}
