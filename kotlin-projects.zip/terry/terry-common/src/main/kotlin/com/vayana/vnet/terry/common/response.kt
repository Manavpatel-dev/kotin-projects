package com.vayana.vnet.terry.common

import com.fasterxml.jackson.annotation.JsonProperty
import java.math.BigDecimal
import java.time.LocalDateTime
import java.util.*

data class TerryResponse<T> (
  @JsonProperty("Status")
  val status: String,
  @JsonProperty("Data")
  val data: T?,
  @JsonProperty("ErrorDetails")
  val errorDetails: List<ErrorDetails>?,
  @JsonProperty("InfoDtls")
  val infoDetails: InfoDetails?
)

interface InfoDetails

open class InfoDetailsBase(
  @JsonProperty("InfCd")
  open val infoCode: String
): InfoDetails

data class DuplicateIrnInfoDetails(
  override val infoCode: String,
  @JsonProperty("Desc")
  val desc: IrnInfo
): InfoDetailsBase(infoCode)

data class IrnInfo(
  @JsonProperty("AckNo")
  val ackNumber: Long,
  @JsonProperty("AckDt")
  val ackDate: Date,
  @JsonProperty("Irn")
  val irn: IRN
)

data class ErrorCodeMessageInfoDetails(
  override val infoCode: String,
  @JsonProperty("Desc")
  val desc: List<ErrorInfo>
): InfoDetailsBase(infoCode)

data class ErrorInfo(
  @JsonProperty("ErrorCode")
  val errorCode: String,
  @JsonProperty("ErrorMessage")
  val errorMessage: String
)

data class StringInfoDetails(
  override val infoCode: String,
  @JsonProperty("Desc")
  val desc: String
): InfoDetailsBase(infoCode)

//TODO: Fix issue of Object Serialization and change Date to LocalDateTime
data class GenerateIrnResponse(
  @JsonProperty("AckNo") val ackNumber: BigDecimal,

  @JsonProperty("AckDt") val ackDate: LocalDateTime,

  @JsonProperty("Irn") val irn: String,

  @JsonProperty("SignedInvoice") val signedInvoice: SignedInvoice,

  @JsonProperty("SignedQRCode") val signedQRCode: SignedQR,

  @JsonProperty("Status") val status: InvoiceStatus,

  @JsonProperty("EwbNo") val ewbNumber: BigDecimal?,

  @JsonProperty("EwbDt") val ewbDate: LocalDateTime?,

  @JsonProperty("EwbValidTill") val ewbValidTill: LocalDateTime?,

  @JsonProperty("Remarks") val remarks: String?

)

/*
Sample response json in case of GenerateIRN API call ->
=====================================================
{
  "Status": 0,
  "ErrorDetails": [
    {
      "ErrorCode": "2169",
      "ErrorMessage": "Request for IRN is neither from supplier GSTIN or e-Commerce GSTIN"
    },
    {
      "ErrorCode": "3028",
      "ErrorMessage": "GSTIN -24AAADI3182M002 is invalid."
    },
    {
      "ErrorCode": "2176",
      "ErrorMessage": "HSN code(s)-33052 is invalid"
    },
    {
      "ErrorCode": "2279",
      "ErrorMessage":"Invalid schema version"
    }
  ],
  "Data": null,
  "InfoDtls": null
}

Sample Success response Json ->
============================
{
  "Status": 1,
  "ErrorDetails": null,
  "Data": {
    "ClientId": "AAAPI29GSPE7J6V",
    "UserName": "test_24_001",
    "AuthToken": "pOqAwi7dLfoEDmEQlPhNKUIE2",
    "Sek": "J530k5099fSUkqWPKC+pX17NQPjilUHVn6J7oQzgiwCOqL4GgJNdqCDLwc6Uwak1",
    "TokenExpiry": "2021-08-31 19:39:18"
  },
  "InfoDtls": null
}
 */


data class GetIrnResponse(
  @JsonProperty("AckNo") val ackNumber: BigDecimal,

  @JsonProperty("AckDt") val ackDate: LocalDateTime,

  @JsonProperty("Irn") val irn: String,

  @JsonProperty("SignedInvoice") val signedInvoice: SignedInvoice,

  @JsonProperty("SignedQRCode") val signedQRCode: SignedQR,

  @JsonProperty("Status") val status: InvoiceStatus,

  @JsonProperty("EwbNo") val ewbNumber: BigDecimal?,

  @JsonProperty("EwbDt") val ewbDate: LocalDateTime?,

  @JsonProperty("EwbValidTill") val ewbValidTill: LocalDateTime?,

  @JsonProperty("Remarks") val remarks: String?
)

data class AuthIrnResponse(
  @JsonProperty("ClientId") val clientId: String,

  @JsonProperty("UserName") val userName: String,

  @JsonProperty("AuthToken") val authToken: String,

  @JsonProperty("Sek") val sek: String,

  @JsonProperty("TokenExpiry") val tokenExpiry: LocalDateTime,

  @JsonProperty("Remarks") val remarks: String?

)
