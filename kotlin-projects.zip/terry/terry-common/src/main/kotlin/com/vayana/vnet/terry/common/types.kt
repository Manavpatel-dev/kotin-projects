package com.vayana.vnet.terry.common

import com.fasterxml.jackson.annotation.JsonProperty
import io.ktor.client.*
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.util.*

data class AssociatedOrg(
  @JsonProperty("oid")
  val orgId: String,
  @JsonProperty("prim")
  val primary: Boolean,
  @JsonProperty("adm")
  val admin: Boolean,
  @JsonProperty("serv")
  val services: List<String>
)

data class ClientService(
  val httpClient: HttpClient,
  val serverUrl: String
)

data class KeyConfig(
  val terryPublicKey: RSAPublicKey,
  val terryPrivateKey: RSAPrivateKey,
  val theodorePublicKey: String,
  val terryPublicKeyX5TSignature: String,
  val terryPublicKeyKID :String
)

typealias UserId = UUID
typealias OrgId = UUID
typealias InvoiceId=UUID
typealias IRN = String
typealias StateId = Short
typealias HsnCode = Int
typealias Gstin = String
typealias SignedInvoice=String
typealias SignedQR=String
typealias AuthToken=String
typealias ClientId=String


