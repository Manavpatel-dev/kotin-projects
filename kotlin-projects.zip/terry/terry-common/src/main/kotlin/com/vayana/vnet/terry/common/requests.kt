package com.vayana.vnet.terry.common

import com.fasterxml.jackson.annotation.JsonProperty
import java.math.BigDecimal
import java.time.LocalDate

open class TerryRequest

data class AuthIrnRequest(
  @JsonProperty("UserName")   val userName: String,
  @JsonProperty("Password")   val password: String,
  @JsonProperty("AppKey")   val appKey: String,
  @JsonProperty("ForceRefreshAccessToken")   val forceRefreshAccessToken: Boolean = false,
): TerryRequest()

data class GenerateIrnRequest(
  @JsonProperty("Version") val version: EInvoiceVersion,
  @JsonProperty("Irn") val irn: String?,
  @JsonProperty("TranDtls") val transactionDetails: TransactionDetails,
  @JsonProperty("DocDtls") val documentDetails: DocumentDetails,
  @JsonProperty("SellerDtls") val sellerDetails: SellerDetails,
  @JsonProperty("BuyerDtls") val buyerDetails: BuyerDetails,
  @JsonProperty("DispDtls") val dispatchDetails: DispatchDetails? = null,
  @JsonProperty("ShipDtls") val shipDetails: ShipmentDetails? = null,
  @JsonProperty("ItemList") val items: List<Item>,
  @JsonProperty("ValDtls") val valueDetails: ValueDetails,
  @JsonProperty("PayDtls") val payeeDetails: PayeeDetails? = null,
  @JsonProperty("RefDtls") val referenceDetails: RefDetails? = null,
  @JsonProperty("AddlDocDtls") val additionalDocDetails: List<AdditionalDocumentDetails>? = null,
  @JsonProperty("ExpDtls") val exportDetails: ExportDetails? = null,
  @JsonProperty("EwbDtls") val ewbDetails: EwayBillDetails? = null,
) : TerryRequest()

data class TransactionDetails(
  @JsonProperty("TaxSch") val taxScheme: TaxScheme,
  @JsonProperty("SupTyp") val supplyType: SupplyType,
  @JsonProperty("RegRev") val reverseCharge: YesOrNo? = null,
  @JsonProperty("EcmGstin") val ecomGstin: Gstin? = null,
  @JsonProperty("IgstOnIntra") val igstIntra: YesOrNo? = null,
)

data class DocumentDetails(
  @JsonProperty("Typ") val docType: DocumentType,
  @JsonProperty("No") val docNumber: String,
  @JsonProperty("Dt") val docDate: LocalDate,
)

data class SellerDetails(
  @JsonProperty("Gstin") val sellerGstin: Gstin,
  @JsonProperty("LglNm") val legalName: String,
  @JsonProperty("TrdNm") val tradeName: String?,
  @JsonProperty("Addr1") val addressOne: String,
  @JsonProperty("Addr2") val addressTwo: String?,
  @JsonProperty("Loc") val location: String,
  @JsonProperty("Pin") val pinCode: BigDecimal,
  @JsonProperty("Stcd") val stateCode: StateCode,
  @JsonProperty("Ph") val phone: String?,
  @JsonProperty("Em") val email: String?,
)

data class BuyerDetails(
  @JsonProperty("Gstin") val buyerGstin: Gstin,
  @JsonProperty("LglNm") val legalName: String,
  @JsonProperty("TrdNm") val tradeName: String?,
  @JsonProperty("Pos") val placeOfSupply: StateCode,
  @JsonProperty("Addr1") val addressOne: String,
  @JsonProperty("Addr2") val addressTwo: String?,
  @JsonProperty("Loc") val location: String,
  @JsonProperty("Pin") val pinCode: BigDecimal?,
  @JsonProperty("Stcd") val stateCode: StateCode,
  @JsonProperty("Ph") val phone: String?,
  @JsonProperty("Em") val email: String?,
)

data class DispatchDetails(
  @JsonProperty("Nm") val companyName: String,
  @JsonProperty("Addr1") val addressOne: String,
  @JsonProperty("Addr2") val addressTwo: String?,
  @JsonProperty("Loc") val location: String,
  @JsonProperty("Pin") val pinCode: BigDecimal,
  @JsonProperty("Stcd") val stateCode: StateCode,
)

data class ShipmentDetails(
  @JsonProperty("Gstin") val buyerGstin: Gstin?,
  @JsonProperty("LglNm") val legalName: String,
  @JsonProperty("TrdNm") val tradeName: String?,
  @JsonProperty("Addr1") val addressOne: String,
  @JsonProperty("Addr2") val addressTwo: String?,
  @JsonProperty("Loc") val location: String,
  @JsonProperty("Pin") val pinCode: BigDecimal,
  @JsonProperty("Stcd") val stateCode: StateCode,
)

data class Item(
  @JsonProperty("SlNo") val serialNumber: String,
  @JsonProperty("PrdDesc") val productDescription: String?,
  @JsonProperty("IsServc") val service: YesOrNo,
  @JsonProperty("HsnCd") val hsnCode: String,
  @JsonProperty("Barcde") val barCode: String?,
  @JsonProperty("Qty") val quantity: BigDecimal? = null,
  @JsonProperty("FreeQty") val freeQuantity: BigDecimal? = null,
  @JsonProperty("Unit") val unitCode: UnitCode? = null,
  @JsonProperty("UnitPrice") val unitPrice: BigDecimal,
  @JsonProperty("TotAmt") val totalAmount: BigDecimal,
  @JsonProperty("Discount") val discountAmount: BigDecimal? = null,
  @JsonProperty("PreTaxVal") val preTaxValue: BigDecimal? = null,
  @JsonProperty("AssAmt") val taxableAmount: BigDecimal,
  @JsonProperty("GstRt") val gstRate: BigDecimal,
  @JsonProperty("IgstAmt") val igstAmount: BigDecimal? = null,
  @JsonProperty("CgstAmt") val cgstAmount: BigDecimal? = null,
  @JsonProperty("SgstAmt") val sgstAmount: BigDecimal? = null,
  @JsonProperty("CesRt") val cessRate: BigDecimal? = null,
  @JsonProperty("CesAmt") val cessAmount: BigDecimal? = null,
  @JsonProperty("CesNonAdvlAmt") val cessNonAdvalAmount: BigDecimal? = null,
  @JsonProperty("StateCesRt") val stateCessRate: BigDecimal? = null,
  @JsonProperty("StateCesAmt") val stateCessAmount: BigDecimal? = null,
  @JsonProperty("StateCesNonAdvlAmt") val stateCessNonAdvalAmount: BigDecimal? = null,
  @JsonProperty("OthChrg") val otherChage: BigDecimal? = null,
  @JsonProperty("TotItemVal") val totalItemAmount: BigDecimal,
  @JsonProperty("OrdLineRef") val orderLineReference: String? = null,
  @JsonProperty("OrgCntry") val originCountry: CountryCode? = null,
  @JsonProperty("PrdSlNo") val productSerialNumber: String? = null,
  @JsonProperty("BchDtls") val batchDetails: BatchDetails? = null,
  @JsonProperty("AttribDtls") val attributeDetails: List<AttributeDetails>? = null,
)


data class BatchDetails(
  @JsonProperty("Nm") val batchName: String,
  @JsonProperty("ExpDt") val batchExpiryDate: LocalDate? = null,
  @JsonProperty("WrDt") val warrantyDate: LocalDate? = null,
)

data class AttributeDetails(
  @JsonProperty("Nm") val attributeName: String?,
  @JsonProperty("Val") val attributeValue: String?,
)

data class ValueDetails(
  @JsonProperty("AssVal") val totalAssessableValue: BigDecimal,
  @JsonProperty("CgstVal") val totalCgstValue: BigDecimal? = null,
  @JsonProperty("SgstVal") val totalSgstValue: BigDecimal? = null,
  @JsonProperty("IgstVal") val totalIgstValue: BigDecimal? = null,
  @JsonProperty("CesVal") val totalCessValue: BigDecimal? = null,
  @JsonProperty("StCesVal") val totalStateCessValue: BigDecimal? = null,
  @JsonProperty("Discount") val discount: BigDecimal? = null,
  @JsonProperty("OthChrg") val otherCharge: BigDecimal? = null,
  @JsonProperty("RndOffAmt") val roundedOffAmount: BigDecimal? = null,
  @JsonProperty("TotInvVal") val totalInvoiceValue: BigDecimal,
  @JsonProperty("TotInvValFc") val totalInvoiceValueFinal: BigDecimal? = null,
)

data class PayeeDetails(
  @JsonProperty("Nm") val name: String?,
  @JsonProperty("AccDet") val bankAccountNumber: String?,
  @JsonProperty("Mode") val paymentMode: PaymentMode?,
  @JsonProperty("FinInsBr") val ifscCode: String?,
  @JsonProperty("PayTerm") val paymentTerms: String?,
  @JsonProperty("PayInstr") val paymentInstructions: String?,
  @JsonProperty("CrTrn") val creditTransfer: String?,
  @JsonProperty("DirDr") val directDebit: String?,
  @JsonProperty("CrDay") val creditDays: BigDecimal?,
  @JsonProperty("PaidAmt") val paidAmount: BigDecimal?,
  @JsonProperty("PaymtDue") val dueAmount: BigDecimal?,
)

data class RefDetails(
  @JsonProperty("InvRm") val invoiceRemarks: String? = null,
  @JsonProperty("DocPerdDtls") val docPerdDtsl: DocPerdDtls? = null,
  @JsonProperty("PrecDocDtls") val precedingDocuments: List<PrecedingDocument>? = null,
  @JsonProperty("ContrDtls") val contractDetails: List<ContractDetails>? = null,
)

data class DocPerdDtls(
  @JsonProperty("InvStDt") val invoiceStartDate: LocalDate,
  @JsonProperty("InvEndDt") val invoiceEndDate: LocalDate,
)

data class PrecedingDocument(
  @JsonProperty("InvNo") val precedingInvoiceNumber: String,
  @JsonProperty("InvDt") val precedingInvoiceDate: LocalDate,
  @JsonProperty("OthRefNo") val otherReferenceNumber: String? = null,
)

data class ContractDetails(
  @JsonProperty("RecAdvRefr") val receiptAdviceNumber: String? = null,
  @JsonProperty("RecAdvDt") val receiptAdviceDate: LocalDate? = null,
  @JsonProperty("TendRefr") val batchReferenceNumber: String? = null,
  @JsonProperty("ContrRefr") val contractReferenceNumber: String? = null,
  @JsonProperty("ExtRefr") val otherReferenceNumber: String? = null,
  @JsonProperty("ProjRefr") val projectReferenceNumber: String? = null,
  @JsonProperty("PORefr") val purchaseOrderReferenceNumber: String? = null,
  @JsonProperty("PORefDt") val purchaseOrderReferenceDate: LocalDate? = null,
)

data class AdditionalDocumentDetails(
  @JsonProperty("Url") val url: String? = null,
  @JsonProperty("Docs") val docs: String? = null,
  @JsonProperty("Info") val info: String? = null,
)

data class ExportDetails(
  @JsonProperty("ShipBNo") val shipmentBillNo: String? = null,
  @JsonProperty("ShipBDt") val shipmentBillDate: LocalDate? = null,
  @JsonProperty("Port") val portCode: PortCode? = null,
  @JsonProperty("RefClm") val refund: YesOrNo?,
  @JsonProperty("ForCur") val foreignCurrency: CurrencyCode? = null,
  @JsonProperty("CntCode") val countryCode: CountryCode? = null,
  @JsonProperty("ExpDuty") val exportDuty: BigDecimal? = null,
)

data class EwayBillDetails(
  @JsonProperty("TransId") val transporterGstin: Gstin? = null,
  @JsonProperty("TransName") val transporterName: String? = null,
  @JsonProperty("TransMode") val transportationMode: TransportationMode? = null,
  @JsonProperty("Distance") val distance: BigDecimal,
  @JsonProperty("TransDocNo") val transportDocNumber: String? = null,
  @JsonProperty("TransDocDt") val transportDocDate: LocalDate? = null,
  @JsonProperty("VehNo") val vehicleNumber: String? = null,
  @JsonProperty("VehType") val vehicleType: VehicleType? = null,
)
