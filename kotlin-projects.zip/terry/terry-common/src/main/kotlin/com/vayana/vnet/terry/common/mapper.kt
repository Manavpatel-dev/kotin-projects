package com.vayana.vnet.terry.common

import arrow.core.Either
import arrow.core.Some
import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer
import com.fasterxml.jackson.module.kotlin.KotlinModule
import com.vayana.walt.json.CustomLocalDateTimeDeserializer
import com.vayana.walt.json.CustomLocalDateTimeSerializer
import com.vayana.walt.json.EitherDeserializer
import com.vayana.walt.json.EitherSerializer
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object DataMapper {
  private const val dateFormatSlashPattern = "dd/MM/yyyy"
  private val dateFormatSlash = SimpleDateFormat(dateFormatSlashPattern)

  private const val dateFormatDashTimePattern = "yyyy-MM-dd HH:mm:ss"

  private val module = KotlinModule()
    .addSerializer(LocalDateTime::class.java, CustomLocalDateTimeSerializer(false, Some(DateTimeFormatter.ofPattern(dateFormatDashTimePattern))))
    .addSerializer(LocalDate::class.java, LocalDateSerializer(DateTimeFormatter.ofPattern(dateFormatSlashPattern)))
    .addSerializer(Either.Left::class.java, EitherSerializer())
    .addSerializer(Either.Right::class.java, EitherSerializer())

    .addDeserializer(LocalDateTime::class.java, CustomLocalDateTimeDeserializer(false, Some(DateTimeFormatter.ofPattern(dateFormatDashTimePattern))))
    .addDeserializer(LocalDate::class.java, LocalDateDeserializer(DateTimeFormatter.ofPattern(dateFormatSlashPattern)))
    .addDeserializer(Either::class.java, EitherDeserializer())
    .addDeserializer(Either.Right::class.java, EitherDeserializer())
    .addDeserializer(Either.Left::class.java, EitherDeserializer())

  val default: ObjectMapper = ObjectMapper()
    .registerModule(module)
    .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
    .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
    .configure(JsonParser.Feature.STRICT_DUPLICATE_DETECTION, true)
    .configure(JsonParser.Feature.IGNORE_UNDEFINED, true)
    .setDateFormat(dateFormatSlash)

}
