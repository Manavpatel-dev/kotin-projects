plugins {
    kotlin("jvm")
}

group = "com.vayana.vnet"
version = "0.1.0-SNAPSHOT"

val jacksonVersion: String by project
val waltVersion: String by project

dependencies {
  api("com.fasterxml.jackson.datatype", "jackson-datatype-jsr310", jacksonVersion)
  api("com.vayana.walt", "walt", waltVersion)
}
