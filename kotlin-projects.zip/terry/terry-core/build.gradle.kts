plugins {
  kotlin("jvm")
}

group = "com.vayana.vnet"
version = "1.0-SNAPSHOT"

val exposedVersion: String by project
val tipoVersion: String by project
val junitVersion: String by project
val hikariVersion: String by project
val ktorVersion: String by project

val testOutput: Configuration = configurations
  .create("terryCoreTestOutput")
  .extendsFrom(configurations.testCompileOnly.get())

dependencies {
  testOutput(sourceSets.test.get().output)
  api(project(":terry-common"))
  api("com.vayana.walt", "tipo", tipoVersion)
    .exclude("org.jetbrains.exposed")
    .exclude("io.arrow-kt")

  implementation("commons-codec","commons-codec","1.11")
  implementation("org.apache.commons", "commons-text", "1.7")
  implementation("io.ktor", "ktor-auth-jwt", ktorVersion)
  api("org.jetbrains.exposed", "exposed-core", exposedVersion)
  api("org.jetbrains.exposed", "exposed-jdbc", exposedVersion)
  api("org.jetbrains.exposed", "exposed-java-time", exposedVersion)
  api("com.zaxxer", "HikariCP", hikariVersion)
  runtimeOnly("mysql", "mysql-connector-java", "8.0.23")
  implementation("net.jodah", "expiringmap", "0.5.9")

  testImplementation("io.ktor", "ktor-client-mock", ktorVersion)
  testImplementation("io.ktor", "ktor-client-mock-jvm", ktorVersion)
  testImplementation("org.junit.jupiter", "junit-jupiter-api", junitVersion)
  testRuntimeOnly("org.junit.jupiter", "junit-jupiter-engine", junitVersion)
}
