import arrow.core.Either
import arrow.core.computations.either
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.db.*
import com.vayana.vnet.terry.core.processing.AuthIrnCommand
import com.vayana.vnet.terry.core.processing.toTerryError
import org.jetbrains.exposed.sql.and
import org.slf4j.LoggerFactory
import java.time.LocalDateTime

object Repo {
  private val log = LoggerFactory.getLogger(Repo::class.java)

  fun saveInvoice(input: InvoiceRecord): Either<TerryError, InvoiceRecord> =
    either.eager<TerryError, InvoiceRecord> {
      InvoicesTable.addAndDoNotGet(input).toTerryError(AppFaults.DbError, "err-unable-to-insert-invoice").bind()
      input
    }

  fun saveInvoiceBlob(input: AdditionalInvoiceDetailRecord): Either<TerryError, AdditionalInvoiceDetailRecord> =
    either.eager<TerryError, AdditionalInvoiceDetailRecord> {
      AdditionalInvoicesDetailTable.addAndDoNotGet(input).toTerryError(AppFaults.DbError, "err-unable-to-insert-invoice-blob")
        .bind()
      input
    }

  fun saveUserSession(input: UserSessionRecord): Either<TerryError, UserSessionRecord> =
    either.eager<TerryError, UserSessionRecord> {
      UserSessionsTable.addAndDoNotGet(input).toTerryError(AppFaults.DbError, "err-unable-to-insert-user-session-record").bind()
      input
    }

  fun getUserSession(creds: Pair<ClientId, Gstin>): Either<TerryError, UserSessionRecord?> =
    either.eager<TerryError, UserSessionRecord?> {
      UserSessionsTable.findOneOrNullByOperation {
        (UserSessionsTable.clientId eq creds.first).and(UserSessionsTable.gstin eq creds.second)
          .and(UserSessionsTable.tokenExpiry greaterEq LocalDateTime.now())
      }.toTerryError(AppFaults.DbError, "err-unable-to-fetch-user-session-record").bind()
    }

  fun getUserSession(creds: Triple<ClientId, Gstin, AuthToken>): Either<TerryError, UserSessionRecord?> =
    either.eager<TerryError, UserSessionRecord?> {
      UserSessionsTable.findOneOrNullByOperation {
        (UserSessionsTable.id eq creds.third).and(UserSessionsTable.clientId eq creds.first)
          .and(UserSessionsTable.gstin eq creds.second)
          .and(UserSessionsTable.tokenExpiry greaterEq LocalDateTime.now())

      }.toTerryError(AppFaults.DbError, "err-unable-to-fetch-user-session-record-with-token").bind()
    }

  fun getUserRecord(cmd: AuthIrnCommand): Either<TerryError, UserRecord?> =
    either.eager<TerryError, UserRecord?> {
      UserCredsTable.findOneOrNullByOperation {
        (UserCredsTable.clientId eq cmd.clientId).and(UserCredsTable.gstin eq cmd.userGstin)
          .and(UserCredsTable.username eq cmd.userName)
      }.toTerryError(AppFaults.DbError, "err-while-fetching-user-record").bind()
    }

  fun saveClientRecord(input: ClientRecord): Either<TerryError, ClientRecord> =
    either.eager<TerryError, ClientRecord> {
      ClientCredsTable.add(input).toTerryError(AppFaults.DbError, "err-inserting-client-creds-record").bind()
      input
    }

  fun getClientRecord(cmd: AuthIrnCommand): Either<TerryError, ClientRecord?> =
    either.eager<TerryError, ClientRecord?> {
      ClientCredsTable.findOneOrNullById(cmd.clientId)
        .toTerryError(AppFaults.DbError, "err-while-fetching-client-record").bind()
    }
}
