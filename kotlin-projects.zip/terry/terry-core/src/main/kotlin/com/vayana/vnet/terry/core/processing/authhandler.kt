import Repo.getClientRecord
import Repo.getUserRecord
import arrow.core.Either
import arrow.core.computations.either
import arrow.core.left
import arrow.core.right
import com.vayana.tipo.transactionE
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.db.UserSessionRecord
import com.vayana.vnet.terry.core.processing.AuthIrnCommand
import com.vayana.vnet.terry.core.processing.CommandContext
import com.vayana.vnet.terry.core.processing.CommandResult
import com.vayana.vnet.terry.core.processing.toTerryError
import com.vayana.walt.errors.Fault
import com.vayana.walt.utils.aesEncrypt
import com.vayana.walt.utils.decode
import com.vayana.walt.utils.getRandomString
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.slf4j.LoggerFactory
import java.time.LocalDateTime
import java.time.ZoneOffset

val log = LoggerFactory.getLogger(AuthIrnCommand::class.java)

@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun handleAuthIrnCmd(
  cmd: AuthIrnCommand,
  cmdCtx: CommandContext,
): CommandResult<TerryResponse<AuthIrnResponse>> =
  transactionE {
    either.eager<TerryError, TerryResponse<AuthIrnResponse>> {
      validateAuthIrnCmd(cmd, cmdCtx).bind()
      processAuthIrnCmd(cmd, cmdCtx).bind()
    }
  }.toTerryError()

private fun createUserSession(
  cmd: AuthIrnCommand,
  cmdCtx: CommandContext,
): Either<TerryError, TerryResponse<AuthIrnResponse>> =
  either.eager<TerryError, TerryResponse<AuthIrnResponse>> {
    val currentTime = LocalDateTime.now()
    val token = getRandomString(24)
    val tokenExpiryTime = currentTime.plusHours(6)
    val sek = Key.generateKey().str.aesEncrypt(cmd.request.appKey.decode())
      .toTerryError(AppFaults.RuntimeError, "err-encrypting-ek-from-appkey").bind()
    val record = with(cmd) {
      UserSessionRecord(
        id = token,
        clientId = clientId,
        gstin = userGstin,
        username = userName,
        sek = sek.encodedData,
        forceRefreshToken = true,
        tokenExpiry = tokenExpiryTime,
        createdOn = currentTime,
        lastUpdated = currentTime,
      )
    }
    Repo.saveUserSession(record).bind()
    TerryResponse(
      status = "1",
      data = AuthIrnResponse(
        cmd.clientId,
        cmd.userName,
        token,
        sek.encodedData,
        LocalDateTime.ofInstant(tokenExpiryTime.toInstant(ZoneOffset.UTC), IST_ZONE),
        null
      ),
      errorDetails = null,
      infoDetails = null
    ).right().bind()
  }


private fun processAuthIrnCmd(
  cmd: AuthIrnCommand,
  cmdCtx: CommandContext,
): Either<TerryError, TerryResponse<AuthIrnResponse>> =
  either.eager<TerryError, TerryResponse<AuthIrnResponse>> {

    //business logic goes here
    log.debug("process auth IRN")

    val existingSession = Repo.getUserSession(Pair(cmd.clientId, cmd.userGstin)).bind()
    if (existingSession == null) {
      createUserSession(cmd, cmdCtx).bind()
    } else {
      TerryResponse(
        status = "1",
        data = with(existingSession) {
          AuthIrnResponse(
            clientId = cmd.clientId,
            userName = cmd.userName,
            authToken = id,
            sek = sek,
            tokenExpiry = LocalDateTime.ofInstant(tokenExpiry.toInstant(ZoneOffset.UTC), IST_ZONE),
            remarks = null
          )
        },
        errorDetails = null,
        infoDetails = null
      ).right().bind()
    }
  }


private fun validateAuthIrnCmd(
  cmd: AuthIrnCommand,
  cmdCtx: CommandContext,
): Either<TerryError, Unit> =
  either.eager<TerryError, Unit> {
    authenticateClient(cmd, cmdCtx).bind()
    authenticateUser(cmd, cmdCtx).bind()
  }

fun authenticateUser(
  cmd: AuthIrnCommand,
  cmdCtx: CommandContext,
): Either<TerryError, Unit> =
  either.eager<TerryError, Unit> {
    val userRecord = getUserRecord(cmd).bind()
    log.debug(">>>> userRecord form Auth $userRecord")

    (userRecord?.let {
      if (Passwords.verify(cmd.request.password, it.password)) Unit.right()
      else TerryFault(
        AppFaults.AuthenticationError, "err-authentication-invalid-creds",
        contents = listOf(Fault(AppFaults.AuthenticationError, "1019"))
      ).left()
    } ?: TerryFault(
      AppFaults.AuthenticationError, "Incorrect user id/User does not exists",
      contents = listOf(Fault(AppFaults.AuthenticationError, "1017"))
    ).left()).bind()
  }


fun authenticateClient(
  cmd: AuthIrnCommand,
  cmdCtx: CommandContext,
): Either<TerryError, Unit> =
  either.eager<TerryError, Unit> {
    val clientRecord = getClientRecord(cmd).bind()
    log.debug(">>>> clientRecord form Auth $clientRecord")

    val terryFault = TerryFault(
      AppFaults.AuthenticationError, "Invalid Client-ID/Client-Secret",
      contents = listOf(Fault(AppFaults.AuthenticationError, "1010"))
    )

    (clientRecord?.let {
      if (Passwords.verify(cmd.clientSecret, it.clientSecret)) Unit.right()
      else terryFault.left()
    } ?: terryFault.left()).bind()
  }
