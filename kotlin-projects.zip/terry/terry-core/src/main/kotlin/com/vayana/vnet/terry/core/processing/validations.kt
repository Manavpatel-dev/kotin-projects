package com.vayana.vnet.terry.core.processing

import IST_ZONE
import arrow.core.Either
import arrow.core.flatten
import arrow.core.left
import arrow.core.right
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.db.PincodeRecord
import io.ktor.http.*
import minusToleranceLimit
import org.slf4j.LoggerFactory
import plusToleranceLimit
import toPercentage
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime

private val log = LoggerFactory.getLogger("com.vayana.vnet.terry.core.processing.validations")

fun HttpStatusCode.toFaultType(): AppFaults =
  when (value) {
    400 -> AppFaults.ClientError
    401 -> AppFaults.AuthenticationError
    403 -> AppFaults.ForbiddenError
    404 -> AppFaults.ResourceDoesNotExist
    500 -> AppFaults.ThirdPartyApiError
    else -> AppFaults.RuntimeError
  }

fun validate1(validations: List<Pair<ValidationError, () -> Boolean>>): Either<List<ValidationError>, Unit> =
  validations.map { (err: ValidationError, block) ->
    if (!block()) err else null
  }.filterNotNull().run {
    if (this.isEmpty()) Unit.right() else this.left()
  }

fun <C : Command> validateAndAbortOnFailure(
  validations: List<(C, CommandContext) -> TerryFault<AppFaults>?>,
  cmd: C,
  cmdCtx: CommandContext,
): Either<TerryFault<AppFaults>, Unit> {
  validations.forEach { block ->
    block(cmd, cmdCtx)?.let {
      return  TerryFault(
      AppFaults.ValidationError,
      "err-validation-errors",
      contents = listOf(it)
    ).left() }
  }
  return Unit.right()
}

fun <C : Command> validateAndContinueOnFailure(
  validations: List<(C, CommandContext) -> TerryFault<AppFaults>?>,
  cmd: C,
  cmdCtx: CommandContext,
): Either<TerryFault<AppFaults>, Unit> =
  validations.map { block ->
    block(cmd, cmdCtx)
  }.filterNotNull().run {
    if (this.isEmpty()) Unit.right() else TerryFault(
      AppFaults.ValidationError,
      "err-validation-errors",
      contents = this
    ).left()
  }

fun <C : Command> validateMulitpleAndContinueOnFailure(
  validations: List<(C, CommandContext) -> List<TerryFault<AppFaults>>?>,
  cmd: C,
  cmdCtx: CommandContext,
): Either<TerryFault<AppFaults>, Unit> =
  validations.map { block ->
    block(cmd, cmdCtx)
  }.filterNotNull().run {
    if (this.isEmpty()) Unit.right()
    else
      TerryFault(
      AppFaults.ValidationError,
      "err-validation-errors",
      contents = this.flatten()
    ).left()
  }

fun buyerGstinNotBlank(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.buyerGstin.isBlank()) TerryFault(AppFaults.ValidationError, "errcode111") else null

fun documentDateNotInFuture(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.documentDetails.docDate > LocalDate.now(IST_ZONE)) TerryFault(
    AppFaults.ValidationError,
    "2163"
  ) else null

fun notBlank(value: String, errorCode: String): TerryFault<AppFaults>? =
  if (value.isBlank()) TerryFault(AppFaults.ValidationError, errorCode) else null

fun dateNotInFuture(iDate: LocalDateTime, errorCode: String): TerryFault<AppFaults>? =
  if (iDate > LocalDateTime.now()) TerryFault(AppFaults.ValidationError, errorCode) else null

fun versionValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.version != EInvoiceVersion.ONE_ONE) TerryFault(AppFaults.ValidationError, "2279") else null

fun documentDateValidationBeforeOct2020(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.documentDetails.docDate < LocalDate.of(2020, 10, 1)) TerryFault(
    AppFaults.ValidationError,
    "2284"
  ) else null

fun supplierPincodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.sellerDetails.pinCode == BigDecimal("999999")) TerryFault(
    AppFaults.ValidationError,
    "2276"
  ) else null

fun recipientPincodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  when(cmd.request.transactionDetails.supplyType) {
    SupplyType.EXPWP,SupplyType.EXPWOP -> if(cmd.request.buyerDetails.pinCode != BigDecimal("999999")) TerryFault(
      AppFaults.ValidationError,
      "2275",
    ) else null
    else -> if(cmd.request.buyerDetails.pinCode == BigDecimal("999999")) TerryFault(
      AppFaults.ValidationError,
      "2274",
      mapOf(FAULT_RUNTIME_VALUES to listOf(cmd.request.transactionDetails.supplyType.str))
    ) else null
  }

fun dispatchPincodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.dispatchDetails?.pinCode == BigDecimal("999999")) TerryFault(
    AppFaults.ValidationError,
    "2273",
  ) else null

fun documentTypeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!DocumentType.valueMap.contains(cmd.request.documentDetails.docType.str)) TerryFault(
    AppFaults.ValidationError,
    "2280",
  ) else null


fun itemQuantityValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): List<TerryFault<AppFaults>>? =
  cmd.request.items.map {
    if (it.quantity == null)
      TerryFault(
        AppFaults.ValidationError, "2238",
        mapOf(FAULT_RUNTIME_VALUES to listOf(it.serialNumber)))
    else
      null
  }.filterNotNull().ifEmpty { null }

fun itemGstRateValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): List<TerryFault<AppFaults>>? =
  cmd.request.items.map {
    if (!TaxRates.valueMap.contains(it.gstRate.toDouble()))
      TerryFault(
        AppFaults.ValidationError, "2240",
        mapOf(FAULT_RUNTIME_VALUES to listOf(it.serialNumber)))
    else
      null
  }.filterNotNull().ifEmpty { null }

fun itemUQCInvalidValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): List<TerryFault<AppFaults>>? =
  cmd.request.items.map {
    when (it.unitCode) {
      null -> {
        TerryFault(
          AppFaults.ValidationError, "2239",
          mapOf(FAULT_RUNTIME_VALUES to listOf(it.serialNumber))
        )
      }
      else -> {
        if (UnitCode.valueMap.contains(it.unitCode!!.code))
          null
        else
          TerryFault(
            AppFaults.ValidationError, "2177",
            mapOf(FAULT_RUNTIME_VALUES to listOf(it.unitCode?.code))
          )
      }
    }
  }.filterNotNull().ifEmpty { null }

val EXPORT_SUPPLY_TYPES = setOf(SupplyType.EXPWP, SupplyType.DEXP, SupplyType.SEZWP)

fun itemIgstAmountValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): List<TerryFault<AppFaults>>? =
    if (cmd.request.sellerDetails.stateCode != cmd.request.buyerDetails.placeOfSupply
      || cmd.request.transactionDetails.supplyType in EXPORT_SUPPLY_TYPES) {
      cmd.request.items.map {
        // TODO: Add validation for null igst amount in case of exports
        val igstValue = it.igstAmount ?: BigDecimal.ZERO
        val payloadIgstAmount = it.gstRate.toPercentage().multiply(it.taxableAmount)
        if (payloadIgstAmount.compareTo(igstValue.minusToleranceLimit()) == -1 ||
          payloadIgstAmount.compareTo(igstValue.plusToleranceLimit()) == 1) {
          TerryFault(
            AppFaults.ValidationError, "2235",
            mapOf(FAULT_RUNTIME_VALUES to listOf(it.serialNumber))
          )
        } else {
          null
        }
      }.filterNotNull()
        .ifEmpty { null }
    } else
      null

fun itemSgstAndCgstAmountValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): List<TerryFault<AppFaults>>? =
  if (cmd.request.sellerDetails.stateCode == cmd.request.buyerDetails.placeOfSupply) {
    cmd.request.items.map {
      val payloadSgstandCgstAmount =
        it.gstRate.toPercentage().multiply(it.taxableAmount).divide(BigDecimal.ONE.plus(BigDecimal.ONE))
      if ((payloadSgstandCgstAmount < it.sgstAmount?.minusToleranceLimit()
            || payloadSgstandCgstAmount > it.sgstAmount?.plusToleranceLimit())
        && (payloadSgstandCgstAmount < it.cgstAmount?.minusToleranceLimit()
            || payloadSgstandCgstAmount > it.cgstAmount?.plusToleranceLimit())) {
        TerryFault(
          AppFaults.ValidationError, "2234",
          mapOf(FAULT_RUNTIME_VALUES to listOf(it.serialNumber))
        )
      } else null
    }.filterNotNull().ifEmpty { null }
  }
  else null


fun itemCessAmountValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): List<TerryFault<AppFaults>>? =
  cmd.request.items.map {
    it.cessRate?.toPercentage()?.multiply(it.taxableAmount)?.let { cessAmnt ->
      if (cessAmnt < it.cessAmount?.minusToleranceLimit()
        || cessAmnt > it.cessAmount?.plusToleranceLimit()
      ) {
        TerryFault(
          AppFaults.ValidationError, "2266",
          mapOf(FAULT_RUNTIME_VALUES to listOf(it.serialNumber))
        )
      } else null
    }
  }.filterNotNull().ifEmpty { null }

fun itemStateCessAmountValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): List<TerryFault<AppFaults>>? =
  cmd.request.items.map {
    it.stateCessRate?.toPercentage()?.multiply(it.taxableAmount) ?. let { cessAmnt ->
      if (cessAmnt < it.stateCessAmount?.minusToleranceLimit()
        || cessAmnt > it.stateCessAmount?.plusToleranceLimit()) {
        TerryFault(
          AppFaults.ValidationError, "2267",
          mapOf(FAULT_RUNTIME_VALUES to listOf(it.serialNumber))
        )
      } else null
    }
  }.filterNotNull().ifEmpty { null }

fun igstOnIntraForSezandExportValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? {
  cmd.request.transactionDetails.apply {
    if (this.igstIntra == YesOrNo.Y
      && this.supplyType in setOf(SupplyType.EXPWP, SupplyType.EXPWOP, SupplyType.SEZWOP, SupplyType.SEZWP)
    )
      return TerryFault(AppFaults.ValidationError, "2268")
  }
  return null
}

fun shipToStateCodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!StateCode.valueMap.contains(cmd.request.shipDetails?.stateCode?.code)
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.B2B,
      SupplyType.SEZWP,
      SupplyType.SEZWOP,
      SupplyType.DEXP)
  ) TerryFault(
    AppFaults.ValidationError,
    "2271",
  ) else null

fun shipToPincodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.shipDetails?.pinCode == BigDecimal("999999")
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.B2B,
      SupplyType.SEZWP,
      SupplyType.SEZWOP,
      SupplyType.DEXP)
  )
    TerryFault(AppFaults.ValidationError, "2272")
  else null

fun igstOnIntraForIntraSupplyValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.transactionDetails.igstIntra == YesOrNo.Y
    && (cmd.request.sellerDetails.stateCode != cmd.request.buyerDetails.placeOfSupply)
  )
    TerryFault(AppFaults.ValidationError, "2262")
  else null

fun recipientGstinAndStateCodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.buyerGstin != "URP" && cmd.request.buyerDetails.buyerGstin.take(2) != cmd.request.buyerDetails.stateCode.code)
    TerryFault(AppFaults.ValidationError, "2265")
  else null

fun recipientStateCodeWithSupplyTypeValidation(
  cmd: GenerateIrnCommand,
  cmdCtx: CommandContext,
): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.buyerGstin != "URP"
    && cmd.request.buyerDetails.stateCode == StateCode.OtherCountry
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.B2B,
      SupplyType.SEZWOP,
      SupplyType.SEZWP,
      SupplyType.DEXP)
  )
    TerryFault(AppFaults.ValidationError, "2269",
      mapOf(FAULT_RUNTIME_VALUES to listOf(cmd.request.transactionDetails.supplyType.str)))
  else null

fun recipientStateCodeForExpTransactionValidation(
  cmd: GenerateIrnCommand,
  cmdCtx: CommandContext,
): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.buyerGstin == "URP"
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.EXPWP, SupplyType.EXPWOP)
    && cmd.request.buyerDetails.stateCode != StateCode.OtherCountry
  )
    TerryFault(AppFaults.ValidationError, "2261",
      mapOf(FAULT_RUNTIME_VALUES to listOf(cmd.request.transactionDetails.supplyType.str)))
  else null

fun recipientGstinCannotBeURPValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.buyerGstin == "URP"
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.B2B,
      SupplyType.SEZWOP,
      SupplyType.SEZWP,
      SupplyType.DEXP)
  )
    TerryFault(AppFaults.ValidationError, "2212",
      mapOf(FAULT_RUNTIME_VALUES to listOf(cmd.request.transactionDetails.supplyType.str)))
  else null

fun itemEmptyListValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.items.isEmpty())
    TerryFault(AppFaults.ValidationError, "2228")
  else null

fun recipientStateCodeInvalid(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!StateCode.valueMap.contains(cmd.request.buyerDetails.stateCode.code))
    TerryFault(AppFaults.ValidationError, "2260")
  else null

fun supplierGstinAndStateCodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.sellerDetails.sellerGstin.take(2) != cmd.request.sellerDetails.stateCode.code)
    TerryFault(AppFaults.ValidationError, "2258")
  else null

fun supplierStateCodeInvalid(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!StateCode.valueMap.contains(cmd.request.sellerDetails.stateCode.code))
    TerryFault(AppFaults.ValidationError, "2259")
  else null

fun invalidPortCodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!PortCode.valueMap.contains(cmd.request.exportDetails?.portCode?.code))
    TerryFault(AppFaults.ValidationError, "2201")
  else null


fun invalidCountryCodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!CountryCode.valueMap.contains(cmd.request.exportDetails?.countryCode?.code))
    TerryFault(AppFaults.ValidationError, "2202")
  else null

fun invalidForeignCodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!CurrencyCode.valueMap.contains(cmd.request.exportDetails?.foreignCurrency?.code))
    TerryFault(AppFaults.ValidationError, "2203")
  else null

fun recipientAndSupplierGstinValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.sellerDetails.sellerGstin == cmd.request.buyerDetails.buyerGstin)
    TerryFault(AppFaults.ValidationError, "2211")
  else null

fun invalidPosStateCodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (!StateCode.valueMap.contains(cmd.request.buyerDetails.placeOfSupply.code))
    TerryFault(AppFaults.ValidationError, "2243")
  else null

fun supplierGstinURPValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.sellerDetails.sellerGstin == "URP")
    TerryFault(AppFaults.ValidationError, "2213")
  else null

fun recipientPincodeWithSupplyTypeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.pinCode == null
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.B2B,
      SupplyType.SEZWOP,
      SupplyType.SEZWP,
      SupplyType.DEXP)
  )
    TerryFault(AppFaults.ValidationError, "2244",
      mapOf(FAULT_RUNTIME_VALUES to listOf(cmd.request.transactionDetails.supplyType.str)))
  else null

fun recipientGstinShouldBeURPForExpValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.buyerGstin != "URP"
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.EXPWP, SupplyType.EXPWOP)
  )
    TerryFault(AppFaults.ValidationError, "2248")
  else null


//TODO : For DEXP,SEZWP SEZWOP accept POS all Statecode inculding 96
fun recipientPosWithB2bSupplyValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.placeOfSupply == StateCode.OtherCountry
    && cmd.request.transactionDetails.supplyType == SupplyType.B2B
  )
    TerryFault(AppFaults.ValidationError, "2242",
      mapOf(FAULT_RUNTIME_VALUES to listOf(cmd.request.transactionDetails.supplyType.str)))
  else null

fun recipientPosWithExpSupplyTypeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  if (cmd.request.buyerDetails.placeOfSupply != StateCode.OtherCountry
    && cmd.request.transactionDetails.supplyType in setOf(SupplyType.EXPWOP,SupplyType.EXPWP)
  )
    TerryFault(AppFaults.ValidationError, "2232",
      mapOf(FAULT_RUNTIME_VALUES to listOf(cmd.request.transactionDetails.supplyType.str)))
  else null

//TODO : remove Duplication of code from sellerDetailsPincodeValidation,buyerDetailsPincodeValidation, and shipDetailsPincodeValidation
fun sellerDetailsPincodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  cmd.request.let {
    it.sellerDetails.pinCode.let { pincode ->
      if (pincode.intValueExact() != cmdCtx.cache.pincodeCache(PincodeRecord(pincode.intValueExact()))) {
        TerryFault(
          AppFaults.ValidationError, "3038",
          mapOf(FAULT_RUNTIME_VALUES to listOf("Seller", pincode.toString()))
        )
      } else null
    }
  }

fun buyerDetailsPincodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  cmd.request.let {
    it.buyerDetails.pinCode?.let { pincode ->
      if (pincode.intValueExact() != cmdCtx.cache.pincodeCache(PincodeRecord(pincode.intValueExact()))) {
        TerryFault(
          AppFaults.ValidationError, "3038",
          mapOf(FAULT_RUNTIME_VALUES to listOf("Buyer", pincode.toString()))
        )
      } else null
    }
  }

fun shipDetailsPincodeValidation(cmd: GenerateIrnCommand, cmdCtx: CommandContext): TerryFault<AppFaults>? =
  cmd.request.let {
    it.shipDetails?.pinCode?.let { pincode ->
      if (pincode.intValueExact() != cmdCtx.cache.pincodeCache(PincodeRecord(pincode.intValueExact()))) {
        TerryFault(
          AppFaults.ValidationError, "3038",
          mapOf(FAULT_RUNTIME_VALUES to listOf("Ship", pincode.toString()))
        )
      } else null
    }
  }




