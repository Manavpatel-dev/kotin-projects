package com.vayana.vnet.terry.core.db

import arrow.core.Either
import com.vayana.tipo.*
import com.vayana.tipo.table.BaseTable
import com.vayana.tipo.table.VersionableBaseTable
import com.vayana.vnet.terry.common.*
import com.vayana.walt.utils.catchT
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.`java-time`.date
import org.jetbrains.exposed.sql.`java-time`.datetime
import org.jetbrains.exposed.sql.statements.UpdateBuilder
import org.jetbrains.exposed.sql.statements.api.ExposedBlob
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime


data class InvoiceRecord(
  override val id: IRN,
  val ackNumber: Long,
  val ackDate: LocalDateTime,
  val irnstatus: InvoiceStatus,
  val originatorGstin: Gstin,
  val sellerGstin: Gstin,
  val ecomGstin: Gstin?,
  val buyerGstin: Gstin,
  val docType: DocumentType,
  val docNumber: String,
  val docDate: LocalDate,
  val totalInvoiceValue: BigDecimal,
  val itemCount: Short,
  val mainHsnCode: String,
  val irnDate: LocalDateTime,
  val infoDetails: String?,
  val remarks: String?,
  val cancelDate: LocalDate?,
  val irnCancellationReason: CancelIrnReasonCode?,
  val irnCancellationRemark: String?,
  val ewbNo: Long?,
  val ewbDate: LocalDateTime?,
  val ewbValidTill: LocalDateTime?,
  val ewbCancellationReason: CancelEwbReasonCode?,
  val ewbCancellationRemark: String?,
  val ewbStatus: InvoiceStatus?,
  override val createdOn: LocalDateTime,
  override val version: Int,
) : TerryVersionedRecord<IRN> {

//  fun toInvoice() =
  // TODO: Implement fetch of both IRN tables
}


object InvoicesTable : VersionableBaseTable<IRN, InvoiceRecord, InvoiceSerializer>("terry_invoices") {
  override val id: Column<EntityID<IRN>> = char("irn", 64).entityId()
  val ackNumber = long("ack_number")
  val ackDate = datetime("ack_date")
  val irnstatus = char("irn_status", 3)
  val originatorGstin = char("originator_gstin", 15)
  val sellerGstin = char("seller_gstin", 15)
  val ecomGstin = char("ecom_gstin", 15).nullable()
  val buyerGstin = char("buyer_gstin", 15)
  val docType = char("doc_type", 3)
  val docNumber = varchar("doc_number", 16)
  val docDate = date("doc_date")
  val totalInvoiceValue = decimal("total_invoice_value", 12, 2)
  val itemCount = short("item_count")
  val mainHsnCode = varchar("main_hsn_code", 8)
  val irnDate = datetime("irn_date")
  val infoDetails = varchar("info_details", 512).nullable()
  val remarks = varchar("remarks", 512).nullable()
  val cancelDate = date("cancel_date").nullable() //todo
  val irnCancellationReason = char("irn_cancellation_reason", 1).nullable()
  val irnCancellationRemark = varchar("irn_cancellation_remark", 100).nullable()
  val ewbNo = long("ewb_no").nullable()
  val ewbDate = datetime("ewb_date").nullable()
  val ewbValidTill = datetime("ewb_valid_till").nullable()
  val ewbCancellationReason = char("ewb_cancellation_reason", 1).nullable()
  val ewbCancellationRemark = varchar("ewb_cancellation_remark", 50).nullable()
  val ewbStatus = char("ewb_status", 3).nullable()
  val createdOn = datetime("created_on").clientDefault { LocalDateTime.now() }

  override val defaultSerializer: InvoiceSerializer = InvoiceSerializer()

  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }

}

class InvoiceSerializer : BaseSerialiser<String, InvoiceRecord>() {

  override fun recordToRow(statement: UpdateBuilder<Number>, record: InvoiceRecord) {
    statement[InvoicesTable.id] = EntityID(record.id, InvoicesTable)
    statement[InvoicesTable.ackNumber] = record.ackNumber
    statement[InvoicesTable.ackDate] = record.ackDate
    statement[InvoicesTable.irnstatus] = record.irnstatus.str
    statement[InvoicesTable.originatorGstin] = record.originatorGstin
    statement[InvoicesTable.sellerGstin] = record.sellerGstin
    statement[InvoicesTable.ecomGstin] = record.ecomGstin
    statement[InvoicesTable.buyerGstin] = record.buyerGstin
    statement[InvoicesTable.docType] = record.docType.str
    statement[InvoicesTable.docNumber] = record.docNumber
    statement[InvoicesTable.docDate] = record.docDate
    statement[InvoicesTable.totalInvoiceValue] = record.totalInvoiceValue
    statement[InvoicesTable.itemCount] = record.itemCount
    statement[InvoicesTable.mainHsnCode] = record.mainHsnCode
    statement[InvoicesTable.irnDate] = record.irnDate
    statement[InvoicesTable.infoDetails] = record.infoDetails
    statement[InvoicesTable.remarks] = record.remarks
    statement[InvoicesTable.cancelDate] = record.cancelDate
    statement[InvoicesTable.irnCancellationReason] = record.irnCancellationReason?.code
    statement[InvoicesTable.irnCancellationRemark] = record.irnCancellationRemark
    statement[InvoicesTable.ewbNo] = record.ewbNo
    statement[InvoicesTable.ewbDate] = record.ewbDate
    statement[InvoicesTable.ewbValidTill] = record.ewbValidTill
    statement[InvoicesTable.ewbCancellationReason] = record.ewbCancellationReason?.code
    statement[InvoicesTable.ewbCancellationRemark] = record.ewbCancellationRemark
    statement[InvoicesTable.ewbStatus] = record.ewbStatus?.str
    statement[InvoicesTable.createdOn] = record.createdOn
  }

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, InvoiceRecord> =
    catchT(TipoFaultType.FetchError, "err-invoice-serialisation") {
      InvoiceRecord(
        r[InvoicesTable.id].value,
        r[InvoicesTable.ackNumber],
        r[InvoicesTable.ackDate],
        InvoiceStatus(r[InvoicesTable.irnstatus])!!,
        r[InvoicesTable.originatorGstin],
        r[InvoicesTable.sellerGstin],
        r[InvoicesTable.ecomGstin],
        r[InvoicesTable.buyerGstin],
        DocumentType(r[InvoicesTable.docType])!!,
        r[InvoicesTable.docNumber],
        r[InvoicesTable.docDate],
        r[InvoicesTable.totalInvoiceValue],
        r[InvoicesTable.itemCount],
        r[InvoicesTable.mainHsnCode],
        r[InvoicesTable.irnDate],
        r[InvoicesTable.infoDetails],
        r[InvoicesTable.remarks],
        r[InvoicesTable.cancelDate],
        r[InvoicesTable.irnCancellationReason]?.let { CancelIrnReasonCode(it) },
        r[InvoicesTable.irnCancellationRemark],
        r[InvoicesTable.ewbNo],
        r[InvoicesTable.ewbDate],
        r[InvoicesTable.ewbValidTill],
        r[InvoicesTable.ewbCancellationReason]?.let { CancelEwbReasonCode(it) },
        r[InvoicesTable.ewbCancellationRemark],
        r[InvoicesTable.ewbStatus]?.let { InvoiceStatus(it) },
        r[InvoicesTable.createdOn],
        r[InvoicesTable.version]
      )
    }
}

data class ClientRecord(
  override val id: ClientId,
  override val version: Int,
  val clientSecret: String,
  val status: ClientCredsStatus,
  override val createdOn: LocalDateTime,
  val lastUpdated: LocalDateTime,
) : TerryVersionedRecord<String>

object ClientCredsTable : VersionableBaseTable<String, ClientRecord, ClientSerializer>("client_creds") {

  override val id: Column<EntityID<ClientId>> = char("client_id", 36).entityId()
  val clientSecret = varchar("client_secret", 128) //TODO: Change length when encrypting with internal key
  val status = enumeration("status", ClientCredsStatus::class)
  val createdOn = datetime("created_on").clientDefault { LocalDateTime.now() }
  val lastUpdated = datetime("last_updated").clientDefault { LocalDateTime.now() }
  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }
  override val defaultSerializer: ClientSerializer = ClientSerializer()
}

class ClientSerializer : BaseSerialiser<String, ClientRecord>() {

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, ClientRecord> =
    catchT(TipoFaultType.FetchError, "err-client-credential-serialisation") {
      ClientRecord(
        r[ClientCredsTable.id].value,
        r[ClientCredsTable.version],
        r[ClientCredsTable.clientSecret],
        r[ClientCredsTable.status],
        r[ClientCredsTable.createdOn],
        r[ClientCredsTable.lastUpdated],
      )
    }

  override fun recordToRow(statement: UpdateBuilder<Number>, record: ClientRecord) {
    statement[ClientCredsTable.id] = EntityID(record.id, ClientCredsTable)
    statement[ClientCredsTable.clientSecret] = record.clientSecret
    statement[ClientCredsTable.status] = record.status
    statement[ClientCredsTable.createdOn] = record.createdOn
    statement[ClientCredsTable.lastUpdated] = record.lastUpdated
  }
}


data class UserRecord(
  override val id: Long,
  override val version: Int,
  val username: String,
  val password: String,
  val clientId: String,
  val gstin: Gstin,
  val status: UserCredsStatus,
  val passwordLastModified: LocalDateTime?,
  override val createdOn: LocalDateTime,
  val lastUpdated: LocalDateTime,
) : TerryVersionedRecord<Long>

object UserCredsTable : VersionableBaseTable<Long, UserRecord, UserSerializer>("user_creds") {

  override val id: Column<EntityID<Long>> = long("id").entityId()//.autoIncrement()
  val username = varchar("username", 20)
  val password = varchar("password", 128) //TODO: Change length when encrypting with internal key
  val clientId = reference("client_id", ClientCredsTable)
  val gstin = char("gstin", 15)
  val status = enumeration("status", UserCredsStatus::class)
  val passwordLastModified = datetime("password_last_modified").nullable()
  val createdOn = datetime("created_on").clientDefault { LocalDateTime.now() }
  val lastUpdated = datetime("last_updated").clientDefault { LocalDateTime.now() }
  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(username, clientId, gstin) }
  override val defaultSerializer: UserSerializer = UserSerializer()
}

class UserSerializer : BaseSerialiser<Long, UserRecord>() {

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, UserRecord> =
    catchT(TipoFaultType.FetchError, "err-user-credentials-serialisation") {
      UserRecord(
        r[UserCredsTable.id].value,
        r[UserCredsTable.version],
        r[UserCredsTable.username],
        r[UserCredsTable.password],
        r[UserCredsTable.clientId].value,
        r[UserCredsTable.gstin],
        r[UserCredsTable.status],
        r[UserCredsTable.passwordLastModified],
        r[UserCredsTable.createdOn],
        r[UserCredsTable.lastUpdated],

        )
    }

  override fun recordToRow(statement: UpdateBuilder<Number>, record: UserRecord) {
    statement[UserCredsTable.id] = EntityID(record.id, UserCredsTable)
    statement[UserCredsTable.username] = record.username
    statement[UserCredsTable.password] = record.password
    statement[UserCredsTable.clientId] = record.clientId
    statement[UserCredsTable.gstin] = record.gstin
    statement[UserCredsTable.status] = record.status
    statement[UserCredsTable.passwordLastModified] = record.passwordLastModified
    statement[UserCredsTable.createdOn] = record.createdOn
    statement[UserCredsTable.lastUpdated] = record.lastUpdated
  }
}

data class UserSessionRecord(
  override val id: AuthToken,
  val clientId: String,
  val gstin: Gstin,
  val username: String,
  val sek: String,
  val forceRefreshToken: Boolean,
  val tokenExpiry: LocalDateTime,
  override val createdOn: LocalDateTime,
  val lastUpdated: LocalDateTime,
) : TerryRecord<AuthToken> {

  object Criteria {

    val SearchByExpired = SimpleCriterion<LocalDateTime> {
      UserSessionsTable.tokenExpiry.less(it)
    }

  }
}

object UserSessionsTable : BaseTable<AuthToken, UserSessionRecord, UserSessionSerializer>("user_sessions") {

  override val id: Column<EntityID<AuthToken>> = char("token", 25).entityId()
  val clientId = reference("client_id", ClientCredsTable)
  val gstin = char("gstin", 15)
  val username = varchar("username", 20)
  val sek = char("sek", 64) //TODO: Change length when encrypting with internal key
  val forceRefreshToken = bool("force_refresh_token")
  val tokenExpiry = datetime("token_expiry")
  val createdOn = datetime("created_on").clientDefault { LocalDateTime.now() }
  val lastUpdated = datetime("last_updated").clientDefault { LocalDateTime.now() }
  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }
  override val defaultSerializer: UserSessionSerializer = UserSessionSerializer()

  init {
    index(isUnique = false, clientId, gstin)
  }

}

class UserSessionSerializer : BaseSerialiser<AuthToken, UserSessionRecord>() {

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, UserSessionRecord> =
    catchT(TipoFaultType.FetchError, "err-user-session-serialisation") {
      UserSessionRecord(
        r[UserSessionsTable.id].value,
        r[UserSessionsTable.clientId].value,
        r[UserSessionsTable.gstin],
        r[UserSessionsTable.username],
        r[UserSessionsTable.sek],
        r[UserSessionsTable.forceRefreshToken],
        r[UserSessionsTable.tokenExpiry],
        r[UserSessionsTable.createdOn],
        r[UserSessionsTable.lastUpdated]
      )
    }

  override fun recordToRow(statement: UpdateBuilder<Number>, record: UserSessionRecord) {
    statement[UserSessionsTable.id] = EntityID(record.id, UserSessionsTable)
    statement[UserSessionsTable.clientId] = record.clientId
    statement[UserSessionsTable.gstin] = record.gstin
    statement[UserSessionsTable.username] = record.username
    statement[UserSessionsTable.sek] = record.sek
    statement[UserSessionsTable.forceRefreshToken] = record.forceRefreshToken
    statement[UserSessionsTable.tokenExpiry] = record.tokenExpiry
    statement[UserSessionsTable.createdOn] = record.createdOn
    statement[UserSessionsTable.lastUpdated] = record.lastUpdated
  }
}

data class PincodeRecord(
  override val id: Int,
) : Record<Int> {
  // fun fromPincode() =
}

object PincodesTable : BaseTable<Int, PincodeRecord, PincodeSerializer>("pincodes") {
  override val defaultSerializer: PincodeSerializer = PincodeSerializer()
  override val id: Column<EntityID<Int>> = integer("pincode").entityId()
  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }
}

class PincodeSerializer : BaseSerialiser<Int, PincodeRecord>() {

  override fun recordToRow(statement: UpdateBuilder<Number>, record: PincodeRecord) {
    statement[PincodesTable.id] = record.id
  }

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, PincodeRecord> =
    catchT(TipoFaultType.FetchError, "err-pincode-serialisation") {
      PincodeRecord(
        r[PincodesTable.id].value
      )
    }
}


data class PincodeMappingRecord(
  override val id: StateId,
  val stateName: String,
  val beginRange: Int,
  val endRange: Int,
) : Record<Short>

object PincodeMappingTable : BaseTable<Short, PincodeMappingRecord, PincodeMappingSerializer>("pincode_mapping") {
  override val defaultSerializer: PincodeMappingSerializer = PincodeMappingSerializer()
  override val id: Column<EntityID<Short>> = short("state_code").entityId()
  val stateName = varchar("state_name", 60)
  val beginRange = integer("pincode_begin")
  val endRange = integer("pincode_end")

  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }

}

class PincodeMappingSerializer : BaseSerialiser<Short, PincodeMappingRecord>() {

  override fun recordToRow(statement: UpdateBuilder<Number>, record: PincodeMappingRecord) {
    statement[PincodeMappingTable.id] = record.id
    statement[PincodeMappingTable.stateName] = record.stateName
    statement[PincodeMappingTable.beginRange] = record.beginRange
    statement[PincodeMappingTable.endRange] = record.endRange
  }

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, PincodeMappingRecord> =
    catchT(TipoFaultType.FetchError, "err-pincode-mapping-serialisation") {
      PincodeMappingRecord(
        r[PincodeMappingTable.id].value,
        r[PincodeMappingTable.stateName],
        r[PincodeMappingTable.beginRange],
        r[PincodeMappingTable.endRange],
      )
    }
}

data class HsnCodeRecord(
  override val id: HsnCode,
  val hsnDesc: String,
) : Record<Int>

object HsnCodeTable : BaseTable<Int, HsnCodeRecord, HsnCodeSerializer>("hsn_codes") {
  override val defaultSerializer: HsnCodeSerializer = HsnCodeSerializer()
  override val id: Column<EntityID<Int>> = integer("hsn_code").entityId()
  val hsnDesc = varchar("hsn_desc", 1000)


  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }

}

class HsnCodeSerializer : BaseSerialiser<Int, HsnCodeRecord>() {

  override fun recordToRow(statement: UpdateBuilder<Number>, record: HsnCodeRecord) {
    statement[HsnCodeTable.id] = record.id
    statement[HsnCodeTable.hsnDesc] = record.hsnDesc

  }

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, HsnCodeRecord> =
    catchT(TipoFaultType.FetchError, "err-hsn-code-serialisation") {
      HsnCodeRecord(
        r[HsnCodeTable.id].value,
        r[HsnCodeTable.hsnDesc],
      )
    }
}

data class AdditionalInvoiceDetailRecord(
  override val id: IRN,
  override val version: Int,
  val unsignedInvoice: String,
  val unsignedQR: String,
  val signedInvoice: SignedInvoice,
  val signedQR: SignedQR,
  override val createdOn: LocalDateTime,
  val lastUpdated: LocalDateTime,
) : TerryVersionedRecord<IRN>

object AdditionalInvoicesDetailTable :
  VersionableBaseTable<IRN, AdditionalInvoiceDetailRecord, AdditionalInvoiceSerializer>("terry_additional_irn_details") {

  override val id: Column<EntityID<IRN>> = char("irn", 64).entityId()
  val unsignedInvoice = blob("unsigned_invoice")
  val unsignedQR = blob("unsigned_qr")
  val signedInvoice = blob("signed_invoice")
  val signedQR = blob("signed_qr")
  val createdOn = datetime("created_on").clientDefault { LocalDateTime.now() }
  val lastUpdated = datetime("last_updated").clientDefault { LocalDateTime.now() }

  override val defaultSerializer: AdditionalInvoiceSerializer = AdditionalInvoiceSerializer()
  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }

}

class AdditionalInvoiceSerializer : BaseSerialiser<String, AdditionalInvoiceDetailRecord>() {

  override fun recordToRow(statement: UpdateBuilder<Number>, record: AdditionalInvoiceDetailRecord) {
    statement[AdditionalInvoicesDetailTable.id] = EntityID(record.id, AdditionalInvoicesDetailTable)
    statement[AdditionalInvoicesDetailTable.unsignedInvoice] = ExposedBlob(record.unsignedInvoice.toByteArray())
    statement[AdditionalInvoicesDetailTable.unsignedQR] = ExposedBlob(record.unsignedQR.toByteArray())
    statement[AdditionalInvoicesDetailTable.signedInvoice] = ExposedBlob(record.signedInvoice.toByteArray())
    statement[AdditionalInvoicesDetailTable.signedQR] = ExposedBlob(record.signedQR.toByteArray())
    statement[AdditionalInvoicesDetailTable.createdOn] = record.createdOn
    statement[AdditionalInvoicesDetailTable.lastUpdated] = record.lastUpdated

  }

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, AdditionalInvoiceDetailRecord> =
    catchT(TipoFaultType.FetchError, "err-additional-invoice-detail-serialisation") {
      AdditionalInvoiceDetailRecord(
        r[AdditionalInvoicesDetailTable.id].value,
        r[AdditionalInvoicesDetailTable.version],
        String(r[AdditionalInvoicesDetailTable.unsignedInvoice].bytes),
        String(r[AdditionalInvoicesDetailTable.unsignedQR].bytes),
        String(r[AdditionalInvoicesDetailTable.signedInvoice].bytes),
        String(r[AdditionalInvoicesDetailTable.signedQR].bytes),
        r[AdditionalInvoicesDetailTable.createdOn],
        r[AdditionalInvoicesDetailTable.lastUpdated]
      )
    }
}

data class UserSessionLogRecord(
  override val id: AuthToken,
  val clientId: String,
  val gstin: Gstin,
  val username: String,
  val sek: String,
  val forceRefreshToken: Boolean,
  val tokenExpiry: LocalDateTime,
  override val createdOn: LocalDateTime,
) : TerryRecord<AuthToken>

object UserSessionLogsTable :
  BaseTable<AuthToken, UserSessionLogRecord, UserSessionLogSerializer>("user_session_logs") {

  override val id: Column<EntityID<AuthToken>> = char("token", 25).entityId()
  val clientId = reference("client_id", ClientCredsTable)
  val gstin = char("gstin", 15)
  val username = varchar("username", 20)
  val sek = char("sek", 64) //TODO: Change length when encrypting with internal key
  val forceRefreshToken = bool("force_refresh_token")
  val tokenExpiry = datetime("token_expiry")
  val createdOn = datetime("created_on").clientDefault { LocalDateTime.now() }

  override val primaryKey by lazy { super.primaryKey ?: PrimaryKey(id) }
  override val defaultSerializer: UserSessionLogSerializer = UserSessionLogSerializer()

}

class UserSessionLogSerializer : BaseSerialiser<AuthToken, UserSessionLogRecord>() {

  override fun rowToRecord(r: ResultRow): Either<DatabaseError, UserSessionLogRecord> =
    catchT(TipoFaultType.FetchError, "err-user-session-log-serialisation") {
      UserSessionLogRecord(
        r[UserSessionLogsTable.id].value,
        r[UserSessionLogsTable.clientId].value,
        r[UserSessionLogsTable.gstin],
        r[UserSessionLogsTable.username],
        r[UserSessionLogsTable.sek],
        r[UserSessionLogsTable.forceRefreshToken],
        r[UserSessionLogsTable.tokenExpiry],
        r[UserSessionLogsTable.createdOn],
      )
    }

  override fun recordToRow(statement: UpdateBuilder<Number>, record: UserSessionLogRecord) {
    statement[UserSessionLogsTable.id] = EntityID(record.id, UserSessionLogsTable)
    statement[UserSessionLogsTable.clientId] = record.clientId
    statement[UserSessionLogsTable.gstin] = record.gstin
    statement[UserSessionLogsTable.username] = record.username
    statement[UserSessionLogsTable.sek] = record.sek
    statement[UserSessionLogsTable.forceRefreshToken] = record.forceRefreshToken
    statement[UserSessionLogsTable.tokenExpiry] = record.tokenExpiry
    statement[UserSessionLogsTable.createdOn] = record.createdOn
  }
}
