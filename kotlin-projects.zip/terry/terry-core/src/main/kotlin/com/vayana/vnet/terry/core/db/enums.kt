package com.vayana.vnet.terry.core.db

import com.fasterxml.jackson.annotation.JsonValue
import com.vayana.walt.utils.EnumCompanion


enum class ClientCredsStatus(@JsonValue val str: String) {
  CANCELLED("CNL"),
  ACTIVE("ACT");


  companion object : EnumCompanion<String, ClientCredsStatus>(values().associateBy(ClientCredsStatus::str))
}

enum class UserCredsStatus(@JsonValue val str: String) {
  CANCELLED("CNL"),
  ACTIVE("ACT");

  companion object : EnumCompanion<String, UserCredsStatus>(values().associateBy(UserCredsStatus::str))
}
