package com.vayana.vnet.terry.core.processing

import arrow.core.Either
import arrow.core.computations.either
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.data.TerryCache
import com.vayana.vnet.terry.core.db.TerryVersionedRecord
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.jetbrains.exposed.sql.Database
import org.slf4j.LoggerFactory
import java.time.LocalDateTime

val LOG = LoggerFactory.getLogger(CommandContext::class.java.packageName)

data class CommandContext(
  val key: KeyConfig,
  val db: Database,
  val cache: TerryCache,
  val authHeader: String?
)

typealias auditRecordsFn = (Database, String, Set<TerryVersionedRecord<Long>>) -> Either<TerryError, Unit>

typealias CommandResult<T> = Either<TerryError, T>
typealias CommandHandler<CMD, RES> = (CMD, CommandContext) -> CommandResult<RES>

@KtorExperimentalAPI
@ObsoleteCoroutinesApi
fun <C : Command, R> handleCommand(
  cmd: C,
  ctx: CommandContext,
  handler: CommandHandler<C, R>
): CommandResult<R> =
  either.eager {
    LOG.info(">>>>> Executing $cmd")
    //ensure user
    //ensure org
    //do any validations if required
    handler(cmd, ctx).bind()
  }

sealed class Command(
//  open val user: UserId,
//  open val entity: OrgId,
  open val cmdCtx: CommandContext,
  open val clientId: String,
  open val clientSecret: String,
  open val userGstin: Gstin,
  open val userName: String,
) {
  val actionPerformedAt: LocalDateTime = LocalDateTime.now()
}

open class RequestCommand<R: TerryRequest>(
  override val cmdCtx: CommandContext,
  override val clientId: String,
  override val clientSecret: String,
  override val userGstin: Gstin,
  override val userName: String,
  open val request: R
): Command(cmdCtx, clientId, clientSecret, userGstin, userName)

data class GenerateIrnCommand(
  override val cmdCtx: CommandContext,
  override val clientId: String,
  override val clientSecret: String,
  override val userGstin: Gstin,
  override val userName: String,
  override val request: GenerateIrnRequest
): RequestCommand<GenerateIrnRequest>(cmdCtx, clientId, clientSecret, userGstin, userName, request)

data class GetIrnCommand(
  override val cmdCtx: CommandContext,
  override val clientId: String,
  override val clientSecret: String,
  override val userGstin: Gstin,
  override val userName: String,
  val irn: String
): Command(cmdCtx, clientId, clientSecret, userGstin, userName )

data class AuthIrnCommand(
  override val cmdCtx: CommandContext,
  override val clientId: String,
  override val clientSecret: String,
  override val userGstin: Gstin,
  override val userName: String,
  override val request: AuthIrnRequest
): RequestCommand<AuthIrnRequest>(cmdCtx, clientId, clientSecret, userGstin, userName, request)
