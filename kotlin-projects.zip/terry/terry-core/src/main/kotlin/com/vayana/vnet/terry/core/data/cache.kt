package com.vayana.vnet.terry.core.data

import Repo
import arrow.core.computations.either
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.db.*
import com.vayana.vnet.terry.core.processing.toTerryError
import com.vayana.walt.cache.expiring.ComputeFnContext
import com.vayana.walt.cache.expiring.ExpiringCache
import kotlinx.coroutines.runBlocking
import net.jodah.expiringmap.ExpirationPolicy
import org.jetbrains.exposed.sql.transactions.transaction
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import java.time.LocalDateTime

interface Cache<K, R> {
  companion object {
    val log: Logger = LoggerFactory.getLogger(Cache::class.java)
  }

  val cache: ExpiringCache<K, R?>
  operator fun invoke(key: K, computeFnContext: ComputeFnContext? = null): R? =
    runBlocking { cache.get(key, computeFnContext) }

  fun remove(key: K) = cache.remove(key)
}

//Todo -> Check expiryTime and maxSize for every cache and change if required
class PincodeCache(
  maxSize: Int, expiryTimeMillis: Long,
) : Cache<PincodeRecord, Int?> {
  private val log: Logger = LoggerFactory.getLogger(PincodeCache::class.java)
  override val cache: ExpiringCache<PincodeRecord, Int?> =
    ExpiringCache(maxSize, expiryTimeMillis, ExpirationPolicy.ACCESSED) { key, _ ->
      transaction {
        either.eager<TerryError, Int?> {
          val record: PincodeRecord =
            PincodesTable.findById(key.id).toTerryError(AppFaults.CacheError, "err-fetching-pincode-cache").bind()
          record.id
        }.fold({ null }, { it })
      }
    }
}

class PincodeMappingCache(
  maxSize: Int, expiryTimeMillis: Long,
) : Cache<Short, Pair<Int, Int>> {
  private val log: Logger = LoggerFactory.getLogger(PincodeMappingCache::class.java)
  override val cache: ExpiringCache<Short, Pair<Int, Int>?> =
    ExpiringCache(maxSize, expiryTimeMillis, ExpirationPolicy.ACCESSED) { key, _ ->
      transaction {
        either.eager<TerryError, Pair<Int, Int>> {
          val record: PincodeMappingRecord =
            PincodeMappingTable.findById(key).toTerryError(AppFaults.CacheError, "err-fetching-pincode-mapping-cache")
              .bind()
          Pair(record.beginRange, record.endRange)
        }.fold({ null }, { it })
      }
    }
}

class HsncodeCache(
  maxSize: Int, expiryTimeMillis: Long,
) : Cache<Int, Int> {
  private val log: Logger = LoggerFactory.getLogger(HsncodeCache::class.java)
  override val cache: ExpiringCache<Int, Int?> =
    ExpiringCache(maxSize, expiryTimeMillis, ExpirationPolicy.ACCESSED) { key, _ ->
      transaction {
        either.eager<TerryError, Int> {
          val record: HsnCodeRecord =
            HsnCodeTable.findById(key).toTerryError(AppFaults.CacheError, "err-fetching-hsn-code-cache").bind()
          record.id
        }.fold({ null }, { it })
      }
    }
}


class IrnCache(
  maxSize: Int, private val expiryTimeMillis: Long,
) : Cache<String, String> {
  private val log: Logger = LoggerFactory.getLogger(IrnCache::class.java)

  override val cache: ExpiringCache<String, String?> =
    ExpiringCache(maxSize, expiryTimeMillis, ExpirationPolicy.ACCESSED) { key, _ ->
      transaction {
        either.eager<TerryError, String> {
          val record: InvoiceRecord =
            InvoicesTable.findById(key).toTerryError(AppFaults.CacheError, "err-fetching-irn-cache").bind()
          record.id
        }.fold({ null }, { it })
      }
    }
}

class TokenCache(
  maxSize: Int,
  expiryTimeMillis: Long,
) : Cache<Triple<ClientId, Gstin, AuthToken>, Pair<AuthToken, LocalDateTime>?> {

  override val cache: ExpiringCache<Triple<ClientId, Gstin, AuthToken>, Pair<AuthToken, LocalDateTime>?> =
    ExpiringCache(maxSize, expiryTimeMillis, ExpirationPolicy.CREATED) { key, _ ->
      transaction {
        either.eager<TerryError, Pair<AuthToken, LocalDateTime>?> {
          val record: UserSessionRecord? = Repo.getUserSession(Triple(key.first, key.second, key.third)).bind()
          record?.let { Pair(it.id, it.tokenExpiry) }
        }.fold({ null }, { it })
      }
    }
}
