package com.vayana.vnet.terry.core.processing

import FISCAL_YEAR
import IST_ZONE
import Repo
import arrow.core.Either
import arrow.core.computations.either
import arrow.core.left
import arrow.core.right
import com.vayana.tipo.transactionE
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.data.UnsignedInvoice
import com.vayana.vnet.terry.core.data.UnsignedQR
import com.vayana.vnet.terry.core.db.AdditionalInvoiceDetailRecord
import com.vayana.vnet.terry.core.db.AdditionalInvoicesDetailTable
import com.vayana.vnet.terry.core.db.InvoiceRecord
import com.vayana.vnet.terry.core.db.InvoicesTable
import com.vayana.walt.utils.SecretData
import com.vayana.walt.utils.aesEncrypt
import com.vayana.walt.utils.decode
import getContentSigned
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi
import org.apache.commons.codec.digest.DigestUtils
import org.jetbrains.exposed.sql.transactions.transaction
import org.slf4j.LoggerFactory
import java.math.BigDecimal
import java.sql.Timestamp
import java.time.LocalDateTime
import java.time.ZoneOffset

private val log = LoggerFactory.getLogger("com.vayana.vnet.terry.core.processing.handlers")

@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun handleCreateIrnCmd(
  cmd: GenerateIrnCommand,
  cmdCtx: CommandContext,
): CommandResult<TerryResponse<GenerateIrnResponse>> =
  transactionE {
    either.eager<TerryError, TerryResponse<GenerateIrnResponse>> {

      //business logic goes here

      log.debug("validating generate IRN request")
      // TODO: Remove this time measuring once perf testing is done
      validateCreateIrnCmd(cmd, cmdCtx).bind()
      log.debug("validations completed")

      // TODO: Set info details conditionally eg. duplicate irn
      processCreateIrnCmd(cmd, cmdCtx).bind()
    }
  }.toTerryError()

private fun processCreateIrnCmd(
  cmd: GenerateIrnCommand,
  cmdCtx: CommandContext,
): Either<TerryError, TerryResponse<GenerateIrnResponse>> =
  either.eager<TerryError, TerryResponse<GenerateIrnResponse>> {
    val currentTime = LocalDateTime.now()
    // TODO: Add all processing here and follow it by db insert / updates

    val irnHash: String = cmd.request.let {
      it.sellerDetails.sellerGstin +
          it.documentDetails.docDate.let { Date ->
            "${Date.year.minus(1)}-${Date.year % 100}".takeIf { Date.isBefore(FISCAL_YEAR) }
              ?: "${Date.year}-${Date.year.plus(1) % 100}"
          } +
          it.documentDetails.docType.str +
          it.documentDetails.docNumber
    }.run { DigestUtils.sha256Hex(this) }
    log.debug("IRN Hash generation completed")

    //TODO: additionalInfo not set for IRN depulicate validation, have to refactor
    transaction {
      either.eager<TerryError, String?> {
        val cacheIrn = cmdCtx.cache.irnCache(irnHash)
        LOG.debug("----cachevalue from handler-${cacheIrn}------")
        val record: InvoiceRecord? = cacheIrn?.let { irn ->
          InvoicesTable.findById(irn).toTerryError(AppFaults.DbError, "err-fetching-dedup-irn-data").bind()
        }
        LOG.debug("----Invoice record from handler-${record}-----")
        when (cacheIrn != null) {
          true -> TerryFault(
            AppFaults.ValidationError,
            "err-dedup-irn",
            contents = listOf(TerryFault(AppFaults.ValidationError, "2150")),
            args = mapOf(FAULT_RUNTIME_INFODETAILS to record?.let { record ->
              val irnInfo: IrnInfo = IrnInfo(
                ackNumber = record.ackNumber,
                ackDate = Timestamp.valueOf(record.ackDate),
                irnHash
              )
              val infoDetails: InfoDetails = DuplicateIrnInfoDetails(
                "DUPIRN",
                irnInfo
              )
              LOG.debug("----infoDetail----${infoDetails}-----")
              infoDetails
            }
            )).left()
          false -> cacheIrn.right()
        }.bind()
      }
    }.bind()


    val rec = InvoiceRecord(
      id = irnHash,
      ackNumber = 122110060976809,
      ackDate = currentTime,
      irnstatus = InvoiceStatus.ACTIVE,
      originatorGstin = cmd.userGstin,
      sellerGstin = cmd.request.sellerDetails.sellerGstin,
      ecomGstin = cmd.request.transactionDetails.ecomGstin,
      buyerGstin = cmd.request.buyerDetails.buyerGstin,
      docType = cmd.request.documentDetails.docType,
      docNumber = cmd.request.documentDetails.docNumber,
      docDate = cmd.request.documentDetails.docDate,
      totalInvoiceValue = cmd.request.valueDetails.totalInvoiceValue,
      itemCount = cmd.request.items.size.toShort(),
      mainHsnCode = cmd.request.items[0].hsnCode, // TODO: QUERY#9
      irnDate = currentTime, //TODO: QUERY#10
      infoDetails = null,
      remarks = null,
      cancelDate = null,
      irnCancellationReason = null,
      irnCancellationRemark = null,
      ewbNo = null,
      ewbDate = currentTime,
      ewbValidTill = null,
      ewbCancellationReason = null,
      ewbCancellationRemark = null,
      ewbStatus = null,
      createdOn = currentTime,
      version = 1
    )

    val unsignedInvoice = UnsignedInvoice(
      rec.ackNumber,
      rec.ackDate,
      irnHash,
      cmd.request.version,
      cmd.request.transactionDetails,
      cmd.request.documentDetails,
      cmd.request.sellerDetails,
      cmd.request.buyerDetails,
      cmd.request.dispatchDetails,
      cmd.request.shipDetails,
      cmd.request.items,
      cmd.request.valueDetails,
      cmd.request.payeeDetails,
      cmd.request.referenceDetails,
      cmd.request.additionalDocDetails,
      cmd.request.exportDetails,
      cmd.request.ewbDetails,
    )

    val unsignedQRCode = UnsignedQR(
      cmd.request.sellerDetails.sellerGstin,
      cmd.request.buyerDetails.buyerGstin,
      cmd.request.documentDetails.docNumber,
      cmd.request.documentDetails.docType,
      cmd.request.documentDetails.docDate,
      cmd.request.valueDetails.totalInvoiceValue,
      cmd.request.items.size.toShort(),
      cmd.request.items[0].hsnCode,
      irnHash,
      rec.irnDate,
    )

    val signedInvoice = unsignedInvoice.getContentSigned(cmdCtx)
    val signedQRCode = unsignedQRCode.getContentSigned(cmdCtx)
    log.debug("signing of Invoice and QRCode completed")

    val invoiceRec = AdditionalInvoiceDetailRecord(
      id = irnHash,
      version = 1,
      unsignedInvoice = DataMapper.default.writeValueAsString(unsignedInvoice),
      unsignedQR = DataMapper.default.writeValueAsString(unsignedQRCode),
      signedInvoice = signedInvoice,
      signedQR = signedQRCode,
      createdOn = currentTime,
      lastUpdated = currentTime
    )

    Repo.saveInvoice(rec).bind()
    log.debug("Insertion of IRN in Table completed")

    Repo.saveInvoiceBlob(invoiceRec).bind()
    LOG.debug("Insertion of IRN in Addtional Invoice Table completed")

    TerryResponse(
      status = "1",
      data = GenerateIrnResponse(
        BigDecimal(122110060976809),
        LocalDateTime.ofInstant(currentTime.toInstant(ZoneOffset.UTC), IST_ZONE),
        irnHash,
        signedInvoice,
        signedQRCode,
        InvoiceStatus.ACTIVE,
        null,
        null,
        null,
        null
      ),
      errorDetails = null,
      infoDetails = null
    )
  }


private fun validateCreateIrnCmd(
  cmd: GenerateIrnCommand,
  cmdCtx: CommandContext,
) =
  either.eager<TerryError, Unit> {
    validateAndContinueOnFailure(listOf(
      ::versionValidation,
      ::documentDateValidationBeforeOct2020,
      ::documentDateNotInFuture,
      ::supplierPincodeValidation,
      ::recipientPincodeValidation,
      ::dispatchPincodeValidation,
      ::documentTypeValidation), cmd, cmdCtx).bind()
    validateMulitpleAndContinueOnFailure(listOf(
      ::itemQuantityValidation,
      ::itemUQCInvalidValidation,
      ::itemGstRateValidation,
      ::itemIgstAmountValidation,
      ::itemSgstAndCgstAmountValidation
    ), cmd, cmdCtx).bind()
    validateAndContinueOnFailure(listOf(
      ::igstOnIntraForSezandExportValidation,
      ::shipToPincodeValidation,
      ::igstOnIntraForIntraSupplyValidation,
      ::recipientGstinAndStateCodeValidation,
      ::recipientStateCodeWithSupplyTypeValidation,
      ::recipientStateCodeInvalid,
      ::supplierStateCodeInvalid,
      ::supplierGstinAndStateCodeValidation,
      ::shipToStateCodeValidation,
      ::recipientStateCodeForExpTransactionValidation,
      ::recipientGstinCannotBeURPValidation,
      ::itemEmptyListValidation,
      ::invalidPortCodeValidation,
      ::invalidCountryCodeValidation,
      ::invalidForeignCodeValidation,
      ::recipientAndSupplierGstinValidation,
      ::invalidPosStateCodeValidation,
      ::supplierGstinURPValidation,
      ::recipientPincodeWithSupplyTypeValidation,
      ::recipientGstinShouldBeURPForExpValidation,
      ::recipientPosWithB2bSupplyValidation,
      ::recipientPosWithExpSupplyTypeValidation), cmd, cmdCtx).bind()
    validateAndContinueOnFailure(listOf(
      ::sellerDetailsPincodeValidation,
      ::buyerDetailsPincodeValidation,
      ::shipDetailsPincodeValidation,
    ), cmd, cmdCtx).bind()
  }

@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun handleGetIrnCmd(
  cmd: GetIrnCommand,
  cmdCtx: CommandContext,
): CommandResult<TerryResponse<String>> =
  transactionE {
    either.eager<TerryError, TerryResponse<String>> {

      //business logic goes here

      log.debug("process get IRN")

      // TODO: Recheck if validation is required. Client id - secret and gstin - username along with authtoken ( part of authentication check ) shd be done by now

      // TODO: Set info details conditionally eg. duplicate irn
      processGetIrnCmd(cmd, cmdCtx).bind()
    }
  }.toTerryError()

private fun processGetIrnCmd(
  cmd: GetIrnCommand,
  cmdCtx: CommandContext,
): Either<TerryError, TerryResponse<String>> =
  transactionE {
    either.eager<TerryError, TerryResponse<String>> {
      // fetch irn
      // TODO: handle db error similar to validation error
      val rec = InvoicesTable.findOneOrNullById(cmd.irn).toTerryError(AppFaults.DbError, "3020").bind()
      (if (rec == null) {
        // TODO: Confirm the correct error code - 3005 - Requested data not found
        TerryFault(AppFaults.ValidationError, "3005").left()
      } else {
        val currentTime = LocalDateTime.now()
        // TODO: Check who can fetch irn - only seller ? ecom? buyer?
        // check if irn belongs to the logged in user

        // TODO: check if irn is not stale

        val additionalInvoiceRecord =
          AdditionalInvoicesDetailTable.findById(cmd.irn)
            .toTerryError(AppFaults.DbError, "err-unable-to-fetch-additional-invoice-record").bind()

        val unEncryptedResponse = with(rec) {
          GetIrnResponse(
            BigDecimal.valueOf(ackNumber),
            LocalDateTime.ofInstant(ackDate.toInstant(ZoneOffset.UTC), IST_ZONE),
            id,
            additionalInvoiceRecord.signedInvoice,
            additionalInvoiceRecord.signedQR,
            irnstatus,
            ewbNo?.let { BigDecimal.valueOf(it) },
            null,
            null,
            remarks
          )
        }

        val unEncryptedJson = DataMapper.default.writeValueAsString(unEncryptedResponse)

        //TODO : Get sek from database and decrypt it using internal key
        val decryptedsek = "laqyxgFHnFnxmjFTnm7qt4ph3jECyEPYRyV6iq6hhkk="

        val encryptedJson = either.eager<TerryError, SecretData> {
          unEncryptedJson.aesEncrypt(decryptedsek.decode())
            .toTerryError(AppFaults.RuntimeError, "err-unable-to-encrypt-json-with-sek").bind()
        }

        TerryResponse(
          status = "1",
          data = encryptedJson.bind().encodedData,
          errorDetails = null,
          infoDetails = null
        ).right()
      }).bind()
    }
  }.toTerryError()
