package com.vayana.vnet.terry.core.db

import com.vayana.tipo.VersionedRecord
import com.vayana.tipo.Record
import java.time.LocalDateTime
import java.time.ZoneId

interface TerryVersionedRecord<I: Comparable<I>>: VersionedRecord<I> {
  val createdOn: LocalDateTime
  fun createdOnMillis() = createdOn.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()
}

interface TerryRecord<I: Comparable<I>>: Record<I> {
  val createdOn: LocalDateTime
  fun createdOnMillis() = createdOn.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()
}
