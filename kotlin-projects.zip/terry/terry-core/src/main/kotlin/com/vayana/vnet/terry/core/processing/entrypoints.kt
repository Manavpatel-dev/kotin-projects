package com.vayana.vnet.terry.core.processing

import arrow.core.Either
import arrow.core.computations.either
import com.vayana.vnet.terry.common.*
import handleAuthIrnCmd
import io.ktor.util.*
import kotlinx.coroutines.ObsoleteCoroutinesApi

@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun authIrn(
  cmdCtx: CommandContext,
  clientId: String,
  clientSecret: String,
  userGstin: Gstin,
  userName: String,
  request: AuthIrnRequest): Either<TerryError, TerryResponse<AuthIrnResponse>> =
  either.eager <TerryError, TerryResponse<AuthIrnResponse>> {
    val cmd = AuthIrnCommand(cmdCtx, clientId, clientSecret, userGstin, userName, request)
    handleCommand(cmd, cmdCtx, ::handleAuthIrnCmd).bind()
  }


@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun createIrn(
  cmdCtx: CommandContext,
  clientId: String,
  clientSecret: String,
  userGstin: Gstin,
  userName: String,
  request: GenerateIrnRequest): Either<TerryError, TerryResponse<GenerateIrnResponse>> =
  either.eager <TerryError, TerryResponse<GenerateIrnResponse>> {
    val cmd = GenerateIrnCommand(cmdCtx, clientId, clientSecret, userGstin, userName, request)
    handleCommand(cmd, cmdCtx, ::handleCreateIrnCmd).bind()
  }

@ObsoleteCoroutinesApi
@KtorExperimentalAPI
fun readInvoiceByIrn(
  cmdCtx: CommandContext,
  clientId: String,
  clientSecret: String,
  userGstin: Gstin,
  userName: String,
  irn: String): Either<TerryError, TerryResponse<String>> =
  either.eager <TerryError, TerryResponse<String>> {
    val cmd = GetIrnCommand(cmdCtx, clientId, clientSecret, userGstin, userName, irn)
    handleCommand(cmd, cmdCtx, ::handleGetIrnCmd).bind()
  }


