package com.vayana.vnet.terry.core.processing

import arrow.core.Either
import com.vayana.vnet.terry.common.AppFaults
import com.vayana.vnet.terry.common.TerryError
import com.vayana.vnet.terry.common.TerryFault
import com.vayana.walt.errors.Fault

fun <E : Enum<E>> Fault<E>.toTerryError(ft: AppFaults, msg: String, args: Map<String, Any?> = mapOf()): TerryError =
  TerryFault(ft, msg, (args + mapOf("err" to message, "err-type" to type)), cause)

fun <T, E : Enum<E>> Either<Fault<E>, T>.toTerryError(
  ft: AppFaults,
  msg: String,
  args: Map<String, Any?> = mapOf(),
): Either<TerryError, T> =
  mapLeft { it.toTerryError(ft, msg, args) }
