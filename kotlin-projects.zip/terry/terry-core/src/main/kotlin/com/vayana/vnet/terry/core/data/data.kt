package com.vayana.vnet.terry.core.data

import com.fasterxml.jackson.annotation.JsonProperty
import com.vayana.vnet.terry.common.*
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime

sealed class UnsignedContent

data class UnsignedInvoice(
  @JsonProperty("AckNo") val ackNumber: Long,
  @JsonProperty("AckDt") val ackDate: LocalDateTime,
  @JsonProperty("Irn") val irn: IRN,
  @JsonProperty("Version") val version: EInvoiceVersion,
  @JsonProperty("TranDtls") val transactionDetails: TransactionDetails,
  @JsonProperty("DocDtls") val documentDetails: DocumentDetails,
  @JsonProperty("SellerDtls") val sellerDetails: SellerDetails,
  @JsonProperty("BuyerDtls") val buyerDetails: BuyerDetails,
  @JsonProperty("DispDtls") val dispatchDetails: DispatchDetails? = null,
  @JsonProperty("ShipDtls") val shipDetails: ShipmentDetails? = null,
  @JsonProperty("ItemList") val items: List<Item>,
  @JsonProperty("ValDtls") val valueDetails: ValueDetails,
  @JsonProperty("PayDtls") val payeeDetails: PayeeDetails? = null,
  @JsonProperty("RefDtls") val referenceDetails: RefDetails? = null,
  @JsonProperty("AddlDocDtls") val additionalDocDetails: List<AdditionalDocumentDetails>? = null,
  @JsonProperty("ExpDtls") val exportDetails: ExportDetails? = null,
  @JsonProperty("EwbDtls") val ewbDetails: EwayBillDetails? = null,
) : UnsignedContent()

data class UnsignedQR(
  @JsonProperty("SellerGstin") val sellerGstin: Gstin,
  @JsonProperty("BuyerGstin") val buyerGstin: Gstin,
  @JsonProperty("DocNo") val docNo: String,
  @JsonProperty("DocTyp") val docTyp: DocumentType,
  @JsonProperty("DocDt") val docDt: LocalDate,
  @JsonProperty("TotInvVal") val totInvVal: BigDecimal,
  @JsonProperty("ItemCnt") val itemCnt: Short,
  @JsonProperty("MainHsnCode") val mainHsnCode: String,
  @JsonProperty("Irn") val irn: IRN,
  @JsonProperty("IrnDt") val irnDt: LocalDateTime,
) : UnsignedContent()

data class TerryCache(
  val irnCache: IrnCache,
  val hsncodeCache: HsncodeCache,
  val pincodeMappingCache: PincodeMappingCache,
  val pincodeCache: PincodeCache,
  val tokenCache: TokenCache
)
