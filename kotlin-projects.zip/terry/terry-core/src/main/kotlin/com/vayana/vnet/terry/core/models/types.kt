package com.vayana.vnet.terry.core.models

import java.util.*

// A Principal is an entity who can be granted privileges
interface Principal {
  val id: UUID
  val identifier: String
}

