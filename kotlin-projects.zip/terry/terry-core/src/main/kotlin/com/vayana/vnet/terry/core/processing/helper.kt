import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import org.apache.commons.text.RandomStringGenerator
import com.vayana.vnet.terry.common.*
import com.vayana.vnet.terry.core.data.UnsignedContent
import com.vayana.vnet.terry.core.processing.CommandContext
import org.apache.commons.codec.digest.DigestUtils
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.math.BigDecimal
import java.math.RoundingMode
import java.security.*
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.*

object Passwords {
   private val generator = RandomStringGenerator.Builder().withinRange("a".codePointAt(0),"z".codePointAt(0)).build()

  fun hash(password: String): String = generator.generate(6).let { salt -> salt + DigestUtils.sha256Hex(salt + password) }

  fun verify(password: String,hash: String): Boolean =
     hash.substring(0,6).let { salt -> salt + DigestUtils.sha256Hex(salt + password) } == hash
}

fun readPemPrivateKey(privateKeyPath: String) = Security.addProvider(BouncyCastleProvider()).let {
  File(privateKeyPath).let { file ->
    val keyBytes = DataInputStream(FileInputStream(file)).use { inputStream ->
      ByteArray(file.length().toInt()).apply {
        inputStream.readFully(this)
      }
    }
    val privKeyTxt = String(keyBytes).replace("-----BEGIN RSA PRIVATE KEY-----", "").replace(
      "-----END RSA PRIVATE KEY-----", ""
    ).replace("\n", "")

    val spec = PKCS8EncodedKeySpec(Base64.getDecoder().decode(privKeyTxt.toByteArray(Charsets.UTF_8)))
    KeyFactory.getInstance("RSA").generatePrivate(spec)
  } as RSAPrivateKey
}

fun readPemPublicKey(publicKeyPath: String) = File(publicKeyPath).let { file ->
  val keyBytes = DataInputStream(FileInputStream(file)).use { inputStream ->
    ByteArray(file.length().toInt()).apply {
      inputStream.readFully(this)
    }
  }
  val pubKeyTxt = String(keyBytes).replace("-----BEGIN PUBLIC KEY-----", "").replace(
    "-----END PUBLIC KEY-----", ""
  ).replace("\n", "")

  val spec = X509EncodedKeySpec(Base64.getDecoder().decode(pubKeyTxt.toByteArray(Charsets.UTF_8)))
  KeyFactory.getInstance("RSA").generatePublic(spec)
} as RSAPublicKey

fun UnsignedContent.getContentSigned(cmdCtx: CommandContext): String = JWT.create()
  .withIssuer("NIC") //TODO
  .withKeyId(cmdCtx.key.terryPublicKeyKID)
  .withHeader(mapOf("x5t" to cmdCtx.key.terryPublicKeyX5TSignature))
  .withClaim("data", DataMapper.default.writeValueAsString(this))
  .sign(
    Algorithm.RSA256(
      cmdCtx.key.terryPublicKey,
      cmdCtx.key.terryPrivateKey
    )
  )

fun BigDecimal.plusToleranceLimit(): BigDecimal = this.setScale(0, RoundingMode.CEILING).plus(BigDecimal.ONE)
fun BigDecimal.minusToleranceLimit(): BigDecimal = this.setScale(0, RoundingMode.FLOOR).minus(BigDecimal.ONE)
val BIG_DECIMAL_HUNDRED = BigDecimal("100")
fun BigDecimal.toPercentage(): BigDecimal = this.divide(BIG_DECIMAL_HUNDRED)
